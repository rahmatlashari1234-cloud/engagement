import React, { useState } from 'react';
import { COUPLE_DATA, HOME_DATE } from './homeData';
import { MonogramCrest } from '../../components/common/MonogramCrest';
import { Sparkles, Heart, MailOpen, RotateCcw } from 'lucide-react';

interface InvitationEnvelopeProps {
  onOpenRsvp?: () => void;
}

export const InvitationEnvelope: React.FC<InvitationEnvelopeProps> = ({ onOpenRsvp }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isPressingSeal, setIsPressingSeal] = useState(false);

  const handleSealClick = () => {
    setIsPressingSeal(true);
    setTimeout(() => {
      setIsPressingSeal(false);
      setIsOpen(!isOpen);
    }, 220);
  };

  return (
    <section id="invitation-suite" className="py-24 md:py-32 px-6 md:px-12 bg-[#F2ECE4] border-t border-[#E5DFD5] relative overflow-hidden select-none">
      <div className="max-w-4xl mx-auto">
        {/* Section Header */}
        <div className="text-center space-y-3 mb-14">
          <div className="inline-flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-[#B98F91]" />
            <span className="text-[11px] uppercase tracking-[0.28em] text-[#6F6A63] font-semibold">
              3D Interactive Stationery Suite
            </span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl text-[#20201E] font-normal tracking-tight">
            The Formal Invitation
          </h2>
          <p className="text-xs sm:text-sm text-[#6F6A63] font-light max-w-md mx-auto">
            Tap the handcrafted wax seal to open the letterpress keepsake in 3D perspective.
          </p>
        </div>

        {/* 3D Perspective Stage Container */}
        <div className="max-w-2xl mx-auto perspective-1200 relative min-h-[520px] sm:min-h-[580px] flex items-center justify-center">
          
          {/* 3D Envelope Base Pocket & Card Stack */}
          <div
            className={`w-full relative transition-all duration-700 ease-out ${
              isOpen ? 'translate-y-4' : 'translate-y-0'
            }`}
            style={{ transformStyle: 'preserve-3d' }}
          >
            {/* The Letterpress Card that physically slides out upwards */}
            <div
              className={`w-full bg-[#FFFDF9] border border-[#D8C5A5] p-6 sm:p-12 shadow-[0_25px_60px_rgba(32,32,30,0.12)] text-center transition-all duration-700 ease-out z-20 relative ${
                isOpen
                  ? 'translate-y-0 opacity-100 scale-100 pointer-events-auto'
                  : 'translate-y-24 opacity-0 scale-95 pointer-events-none'
              }`}
              style={{
                transformStyle: 'preserve-3d',
                transform: isOpen ? 'translateY(0) translateZ(30px)' : 'translateY(80px) translateZ(-20px)',
              }}
            >
              {/* Card Fold Control */}
              <div className="absolute top-4 right-4 z-30">
                <button
                  onClick={() => setIsOpen(false)}
                  className="inline-flex items-center gap-1 text-[10px] uppercase tracking-wider text-[#8C867E] hover:text-[#20201E] border border-[#E5DFD5] px-2.5 py-1 transition-colors cursor-pointer bg-[#FAF8F5]"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Fold Back</span>
                </button>
              </div>

              <MonogramCrest size="md" variant="gold" className="mx-auto" />

              <div className="space-y-2 pt-2">
                <span className="text-[11px] uppercase tracking-[0.28em] text-[#8C867E] block font-medium">
                  Together With Their Families
                </span>
                <h3 className="font-serif text-3xl sm:text-5xl text-[#20201E] font-normal tracking-tight py-2 leading-tight">
                  {COUPLE_DATA.brideFull} <br />
                  <span className="italic font-serif text-[#B98F91] text-2xl sm:text-3xl">&</span> <br />
                  {COUPLE_DATA.groomFull}
                </h3>
                <p className="text-xs sm:text-sm text-[#6F6A63] tracking-wide font-light max-w-md mx-auto pt-1">
                  request the pleasure of your company to celebrate their engagement
                </p>
              </div>

              <div className="w-16 h-[1px] bg-[#D8C5A5] mx-auto my-4" />

              <div className="space-y-1 font-serif text-lg sm:text-xl text-[#20201E]">
                <p className="font-medium tracking-wide">
                  {HOME_DATE.display}
                </p>
                <p className="text-sm font-sans uppercase tracking-[0.18em] text-[#8C867E]">
                  {HOME_DATE.time}
                </p>
              </div>

              <div className="text-sm text-[#6F6A63] font-light space-y-0.5 pt-1">
                <p className="font-serif italic text-base text-[#20201E]">
                  The Glasshouse Conservatory
                </p>
                <p>Stone Hill Estate & Gardens</p>
                <p className="text-xs text-[#8C867E]">Hudson Valley, New York</p>
              </div>

              <div className="pt-6 flex flex-wrap items-center justify-center gap-4">
                <button
                  onClick={onOpenRsvp}
                  className="px-6 py-2.5 bg-[#20201E] text-[#F8F5F0] text-xs uppercase tracking-[0.2em] font-medium hover:bg-[#383733] transition-colors inline-flex items-center gap-2 cursor-pointer shadow-sm hover:scale-102"
                >
                  <span>Accept With Joy (RSVP)</span>
                  <Heart className="w-3.5 h-3.5 text-[#B98F91] fill-[#B98F91]" />
                </button>

                <button
                  onClick={() => setIsOpen(false)}
                  className="px-4 py-2.5 border border-[#D8C5A5] text-[#20201E] text-xs uppercase tracking-[0.16em] font-medium hover:bg-[#F2ECE4] transition-colors inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <MailOpen className="w-3.5 h-3.5 text-[#8C867E]" />
                  <span>Re-Seal Envelope</span>
                </button>
              </div>

              <p className="text-[10px] uppercase tracking-widest text-[#8C867E] pt-3">
                Kindly respond by October 20, 2026 • Formal Cocktail Attire
              </p>
            </div>

            {/* The Closed Envelope Exterior Shell (Visible when closed) */}
            <div
              className={`w-full bg-[#FAF8F5] border border-[#E5DFD5] p-8 sm:p-14 shadow-[0_20px_50px_rgba(32,32,30,0.08)] flex flex-col items-center text-center transition-all duration-700 ease-out cursor-pointer ${
                isOpen ? 'opacity-0 pointer-events-none scale-95' : 'opacity-100 scale-100 relative z-10'
              }`}
              onClick={handleSealClick}
            >
              {/* Top Flap Decorative Fold lines */}
              <div className="absolute top-0 left-0 right-0 h-20 pointer-events-none opacity-20">
                <svg viewBox="0 0 100 24" preserveAspectRatio="none" className="w-full h-full fill-none stroke-[#20201E]" strokeWidth="0.6">
                  <path d="M 0 0 L 50 24 L 100 0" />
                </svg>
              </div>

              <MonogramCrest size="sm" variant="gold" className="mb-3" />

              <span className="text-[11px] uppercase tracking-[0.26em] text-[#8C867E] mb-2 font-sans">
                Cordially Invited
              </span>
              <p className="font-serif italic text-2xl sm:text-3xl text-[#20201E] font-light mb-8">
                To Celebrate the Engagement of <br />
                <span className="not-italic font-normal">{COUPLE_DATA.brideFirst} & {COUPLE_DATA.groomFirst}</span>
              </p>

              {/* 3D Wax Seal Stamp with Press Physics */}
              <div
                className={`relative group/seal my-2 transition-transform duration-200 ${
                  isPressingSeal ? 'scale-90' : 'hover:scale-110'
                }`}
              >
                <div className="w-18 h-18 rounded-full wax-seal flex items-center justify-center cursor-pointer shadow-xl">
                  <span className="font-serif italic text-white text-xl font-semibold tracking-wider drop-shadow-sm">
                    {COUPLE_DATA.monogram}
                  </span>
                </div>
                <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 whitespace-nowrap text-[10px] uppercase tracking-widest text-[#B98F91] font-semibold animate-pulse">
                  Click Seal to Unfold
                </div>
              </div>

              <div className="mt-12 text-[11px] uppercase tracking-[0.2em] text-[#8C867E]">
                {HOME_DATE.locationBadge}
              </div>
            </div>

          </div>
        </div>
      </div>
    </section>
  );
};
