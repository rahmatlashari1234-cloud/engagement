import React, { useState } from 'react';

interface OptimizedImageProps {
  src: string;
  alt: string;
  className?: string;
  priority?: boolean;
  aspectRatio?: string;
  objectFit?: 'cover' | 'contain' | 'scale-down';
  objectPosition?: string;
  fallbackText?: string;
  animation?: 'none' | 'ken-burns' | 'float' | 'zoom-hover';
  sheenOnHover?: boolean;
  curtainReveal?: boolean;
  cornerAccents?: boolean;
}

export const OptimizedImage: React.FC<OptimizedImageProps> = ({
  src,
  alt,
  className = '',
  priority = false,
  aspectRatio,
  objectFit = 'cover',
  objectPosition = 'center',
  fallbackText = 'Amelia & Daniel',
  animation = 'none',
  sheenOnHover = true,
  curtainReveal = false,
  cornerAccents = false,
}) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [hasError, setHasError] = useState(false);

  // Dynamic animation classes
  let animationClass = '';
  if (animation === 'ken-burns') {
    animationClass = 'animate-ken-burns';
  } else if (animation === 'float') {
    animationClass = 'animate-photo-float';
  } else if (animation === 'zoom-hover') {
    animationClass = 'group-hover:scale-105 transition-transform duration-700 ease-out';
  }

  return (
    <div
      className={`relative overflow-hidden bg-[#EFEAE2] ${
        sheenOnHover ? 'photo-sheen-effect' : ''
      } ${className}`}
      style={aspectRatio ? { aspectRatio } : undefined}
    >
      {/* Editorial Loading Skeleton */}
      {!isLoaded && !hasError && (
        <div className="absolute inset-0 bg-[#E8E1D5] animate-pulse flex items-center justify-center z-10">
          <div className="flex flex-col items-center gap-2">
            <span className="w-6 h-[1px] bg-[#B98F91] animate-pulse" />
            <span className="font-serif italic text-xs text-[#8C867E] tracking-widest uppercase">
              Developing...
            </span>
          </div>
        </div>
      )}

      {/* Luxury Curtain / Darkroom Reveal Swipe */}
      {curtainReveal && isLoaded && (
        <div className="absolute inset-0 bg-[#F2ECE4] z-10 pointer-events-none transition-transform duration-1000 ease-out -translate-y-full" />
      )}

      {/* Fallback state if image fails */}
      {hasError ? (
        <div className="absolute inset-0 bg-gradient-to-br from-[#EFEAE2] to-[#E3DCD1] flex flex-col items-center justify-center p-6 text-center">
          <span className="font-serif text-2xl text-[#6F6A63] tracking-wider mb-1">
            {fallbackText}
          </span>
          <span className="text-xs text-[#8C867E] tracking-widest uppercase font-sans">
            Editorial Photograph
          </span>
        </div>
      ) : (
        <img
          src={src}
          alt={alt}
          loading={priority ? 'eager' : 'lazy'}
          decoding="async"
          onLoad={() => setIsLoaded(true)}
          onError={() => setHasError(true)}
          className={`w-full h-full transition-all duration-1000 ease-out ${
            isLoaded ? 'opacity-100 scale-100 blur-0' : 'opacity-0 scale-105 blur-[2px]'
          } ${animationClass}`}
          style={{
            objectFit,
            objectPosition,
          }}
        />
      )}

      {/* Subtle Analog 35mm Grain Texture Overlay */}
      <div className="absolute inset-0 pointer-events-none opacity-[0.03] mix-blend-overlay bg-[radial-gradient(#20201E_1px,transparent_1px)] [background-size:12px_12px]" />

      {/* Optional Editorial Corner Framing Accents */}
      {cornerAccents && (
        <>
          <div className="absolute top-2 left-2 w-3 h-3 border-t border-l border-[#D8C5A5]/80 pointer-events-none z-10 transition-transform duration-500 group-hover:-translate-x-0.5 group-hover:-translate-y-0.5" />
          <div className="absolute top-2 right-2 w-3 h-3 border-t border-r border-[#D8C5A5]/80 pointer-events-none z-10 transition-transform duration-500 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          <div className="absolute bottom-2 left-2 w-3 h-3 border-b border-l border-[#D8C5A5]/80 pointer-events-none z-10 transition-transform duration-500 group-hover:-translate-x-0.5 group-hover:translate-y-0.5" />
          <div className="absolute bottom-2 right-2 w-3 h-3 border-b border-r border-[#D8C5A5]/80 pointer-events-none z-10 transition-transform duration-500 group-hover:translate-x-0.5 group-hover:translate-y-0.5" />
        </>
      )}
    </div>
  );
};
