import React from 'react';
import { SITE_CONFIG } from '../../data/engagementContent';
import { OptimizedImage } from '../common/OptimizedImage';

export const FinalPhoto: React.FC = () => {
  return (
    <section className="relative w-full h-[70vh] sm:h-[80vh] md:h-[90vh] overflow-hidden bg-[#1F1E1C]">
      {/* Cinematic Full-bleed Photograph */}
      <OptimizedImage
        src="https://images.unsplash.com/photo-1470240731273-7821a6eeb6bd?auto=format&fit=crop&w=2200&q=85"
        alt="Amelia and Daniel sunset horizon portrait"
        className="w-full h-full"
        objectFit="cover"
        objectPosition="center 60%"
      />

      {/* Gentle Editorial Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-[#1F1E1C]/80 via-transparent to-[#1F1E1C]/30 pointer-events-none" />

      {/* Minimal Centered Overlay Text */}
      <div className="absolute inset-0 flex flex-col items-center justify-end pb-16 md:pb-24 px-6 text-center text-white pointer-events-none">
        <span className="text-[11px] sm:text-xs uppercase tracking-[0.3em] text-[#D8C5A5] mb-3 font-sans">
          Forever Begins
        </span>
        <h2 className="font-serif text-4xl sm:text-6xl md:text-7xl font-normal tracking-tight text-[#F8F5F0]">
          {SITE_CONFIG.couple.brideFirst}{' '}
          <span className="font-serif italic text-[#B98F91]">&</span>{' '}
          {SITE_CONFIG.couple.groomFirst}
        </h2>
        <p className="mt-3 text-xs sm:text-sm uppercase tracking-[0.2em] text-white/80 font-sans font-light">
          {SITE_CONFIG.celebrationDate.display}
        </p>
      </div>
    </section>
  );
};
