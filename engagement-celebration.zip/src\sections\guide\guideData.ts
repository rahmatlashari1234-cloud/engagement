export interface GuidePlace {
  id: string;
  category: string;
  name: string;
  town: string;
  address: string;
  note: string;
  imageUrl: string;
  tip: string;
}

export const GUIDE_META = {
  sectionNumber: "Travel & Leisure",
  heading: "A Weekend in Hudson Valley",
  subheading: "For our traveling loved ones: a curated journal of our most cherished coffee houses, pastoral walks, and historic hearths across the valley.",
};

export const HUDSON_VALLEY_GUIDE: GuidePlace[] = [
  {
    id: "place-1",
    category: "Morning Espresso",
    name: "Little King Bakery & Café",
    town: "Beacon, NY",
    address: "199 Main Street, Beacon",
    note: "Our favorite Saturday sanctuary for cortados, cardamom morning buns, and design publications.",
    imageUrl: "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=800&q=80",
    tip: "Order the wild lavender latte and sit by the back courtyard window."
  },
  {
    id: "place-2",
    category: "Scenic Nature Trail",
    name: "Poet’s Walk Romantic Landscape",
    town: "Red Hook, NY",
    address: "Route 199, Red Hook",
    note: "Winding pastoral trails celebrated by 19th-century poets, overlooking the rolling Hudson River.",
    imageUrl: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80",
    tip: "Arrive at 4:30 PM for breathtaking golden hour light across the ridge."
  },
  {
    id: "place-3",
    category: "Antiques & Books",
    name: "Warren Street Heritage Quarter",
    town: "Hudson, NY",
    address: "Warren Street, Historic District",
    note: "A mile of mid-century architectural galleries, rare books, and curated ceramic workshops.",
    imageUrl: "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80",
    tip: "Don't miss the tucked-away garden atrium at Spotty Dog Books."
  },
  {
    id: "place-4",
    category: "Evening Fireside Drinks",
    name: "The Tavern at Beekman Arms",
    town: "Rhinebeck, NY",
    address: "6387 Mill Street, Rhinebeck",
    note: "America's oldest continuously operating inn (est. 1766) with roaring stone hearths and spiced bourbon cider.",
    imageUrl: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80",
    tip: "Try the smoky Hudson Maple Manhattan beside the library fireplace."
  }
];
