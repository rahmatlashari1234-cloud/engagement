export interface ToastItem {
  id: string;
  author: string;
  relationship: string;
  message: string;
  date: string;
}

export const TOAST_META = {
  sectionNumber: "Words of Love & Wisdom",
  heading: "The Digital Toast Book",
  subheading: "Read heartfelt toasts and memories from our loved ones, or leave your own blessing for our journey ahead.",
};

export const INITIAL_TOASTS: ToastItem[] = [
  {
    id: "t1",
    author: "Charlotte Montgomery",
    relationship: "Maid of Honor & Sister",
    message: "From the very first day Amelia told me about that coffee in Greenwich Village, her eyes had a light I had never seen before. Daniel, you are the easiest brother to love. May your years together be filled with laughter and endless adventures.",
    date: "September 12, 2026"
  },
  {
    id: "t2",
    author: "Julian Vance",
    relationship: "Best Man & Lifelong Friend",
    message: "I have known Daniel since university dorm days. He has always been steady and thoughtful, but with Amelia, he became the happiest version of himself. Here’s to the couple that makes true love look as effortless as breathing.",
    date: "September 18, 2026"
  },
  {
    id: "t3",
    author: "Eleanor & Arthur",
    relationship: "The Parents",
    message: "Watching our children grow, find one another, and build a partnership rooted in mutual respect and kindness is the greatest gift of our lives. You have our blessing today, tomorrow, and for all the days of your lives.",
    date: "September 24, 2026"
  },
  {
    id: "t4",
    author: "Dr. Marcus & Vivienne Leigh",
    relationship: "Close Friends",
    message: "Raising a toast from afar until November 14th! The way you look at each other across crowded rooms is pure poetry. We cannot wait to dance under the conservatory stars with you two!",
    date: "October 2, 2026"
  }
];
