import React, { useState, useRef } from 'react';

interface GoldFoilGlareProps {
  children: React.ReactNode;
  className?: string;
  intensity?: number;
  embossed?: boolean;
}

export const GoldFoilGlare: React.FC<GoldFoilGlareProps> = ({
  children,
  className = '',
  intensity = 1,
  embossed = true,
}) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [glarePos, setGlarePos] = useState({ x: 50, y: 50, opacity: 0 });

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const card = cardRef.current;
    if (!card) return;
    const rect = card.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    setGlarePos({ x, y, opacity: 1 });
  };

  const handleMouseLeave = () => {
    setGlarePos((prev) => ({ ...prev, opacity: 0 }));
  };

  return (
    <div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className={`relative overflow-hidden group ${className}`}
      style={{
        transformStyle: 'preserve-3d',
      }}
    >
      {children}

      {/* 3D Specular Gold Foil Refraction Layer */}
      <div
        className="absolute inset-0 pointer-events-none transition-opacity duration-300 z-30"
        style={{
          opacity: glarePos.opacity * intensity,
          background: `radial-gradient(circle 240px at ${glarePos.x}% ${glarePos.y}%, rgba(255, 235, 179, 0.45) 0%, rgba(216, 197, 165, 0.25) 35%, rgba(185, 143, 145, 0.12) 60%, transparent 80%)`,
          mixBlendMode: 'overlay',
        }}
      />

      {/* Prismatic Metallic Sheen Line */}
      <div
        className="absolute inset-0 pointer-events-none transition-opacity duration-500 z-30"
        style={{
          opacity: glarePos.opacity * 0.4,
          background: `linear-gradient(${glarePos.x * 2.5}deg, transparent 40%, rgba(255, 245, 210, 0.6) 50%, transparent 60%)`,
          mixBlendMode: 'color-dodge',
        }}
      />

      {/* Embossed Paper Texture Overlay */}
      {embossed && (
        <div
          className="absolute inset-0 pointer-events-none opacity-20 mix-blend-multiply z-10"
          style={{
            backgroundImage: `radial-gradient(#D8C5A5 0.5px, transparent 0.5px)`,
            backgroundSize: '8px 8px',
          }}
        />
      )}
    </div>
  );
};
