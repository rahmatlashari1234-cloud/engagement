export const COUPLE_DATA = {
  brideFirst: "Amelia",
  brideFull: "Amelia Montgomery",
  groomFirst: "Daniel",
  groomFull: "Daniel Sterling",
  monogram: "A & D",
  hashtag: "#AmeliaAndDaniel2026",
};

export const HOME_DATE = {
  display: "Saturday, November 14, 2026",
  time: "5:00 PM Eastern Standard Time",
  locationBadge: "Stone Hill Estate • Hudson Valley, NY",
  isoDate: "2026-11-14T17:00:00-05:00",
  engagementDate: "August 29, 2026",
  engagementLocation: "Positano, Amalfi Coast, Italy",
};

export const HOME_EDITORIAL = {
  eyebrow: "THE BEGINNING OF FOREVER",
  heroSupporting: "Together with their families, they are delighted to celebrate their engagement.",
  introHeading: "Two Stories. One Beginning.",
  introText1: "It was never about grand theatrical gestures; it was the quiet realization that every road before this was leading to the exact same place. Over morning coffees, quiet train rides, shared laughter, and five years of learning each other's cadence, we found home.",
  introText2: "On a sunlit evening overlooking the Mediterranean in Positano, a simple question was asked, and an eternal promise was spoken. Now, we gather our closest loved ones to celebrate the beginning of the rest of our lives.",
  coupleQuote: "“Some moments become memories. Some moments become the foundation of everything that follows.”",
  engagementHeading: "WE SAID YES",
  engagementNarrative: "With the Mediterranean shimmering beneath the August twilight and the faint melody of church bells echoing across the cliffs, Daniel asked Amelia to walk through every chapter of life together. With tears, laughter, and an absolute certainty in our hearts, forever began right there.",
  loveNote: {
    heading: "A New Chapter Begins",
    paragraph1: "To our dearest family and lifelong friends: each of you has shaped who we are individually, and who we are together. You have cheered for us through beginnings, supported us through quiet moments, and brought boundless joy to our journey.",
    paragraph2: "As we step into this next chapter, having you by our side to toast our engagement means more to us than words can convey. We cannot wait to dance, laugh, and celebrate together under the autumn stars.",
    signoff: "With all our love,",
    signatures: "Amelia & Daniel"
  }
};

export interface SectionPortal {
  id: string;
  sectionKey: string;
  number: string;
  title: string;
  tagline: string;
  previewImage: string;
  buttonText: string;
}

export const SECTION_PORTALS: SectionPortal[] = [
  {
    id: "portal-story",
    sectionKey: "story",
    number: "01",
    title: "Our Story & Journey",
    tagline: "From a rainy Tuesday in Greenwich Village to cliffside sunsets in Positano.",
    previewImage: "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=800&q=80",
    buttonText: "Read Our Story"
  },
  {
    id: "portal-gallery",
    sectionKey: "gallery",
    number: "02",
    title: "Visual Poetry Gallery",
    tagline: "Curated collection of editorial portraits, heirloom details, and candid moments.",
    previewImage: "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=800&q=80",
    buttonText: "Explore Gallery"
  },
  {
    id: "portal-event",
    sectionKey: "event",
    number: "03",
    title: "Celebration & Logistics",
    tagline: "Ceremony timeline, dinner schedule, dress code palette, and venue directions.",
    previewImage: "https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=800&q=80",
    buttonText: "View Event Details"
  },
  {
    id: "portal-guide",
    sectionKey: "guide",
    number: "04",
    title: "A Weekend in Hudson Valley",
    tagline: "Our favorite coffee houses, romantic nature trails, and historic hearths.",
    previewImage: "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=800&q=80",
    buttonText: "Open Travel Journal"
  },
  {
    id: "portal-soundtrack",
    sectionKey: "soundtrack",
    number: "05",
    title: "The Vinyl Soundtrack",
    tagline: "Listen to the acoustic records that shaped our quiet Sunday mornings.",
    previewImage: "https://images.unsplash.com/photo-1537633552985-df8429e8048b?auto=format&fit=crop&w=800&q=80",
    buttonText: "Listen to Mixtape"
  },
  {
    id: "portal-toasts",
    sectionKey: "toasts",
    number: "06",
    title: "The Digital Toast Book",
    tagline: "Read warm wishes from friends and family, or leave your own blessing.",
    previewImage: "https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&w=800&q=80",
    buttonText: "Leave a Toast"
  }
];
