import React, { useState, useRef } from 'react';

interface LensPrismEffectProps {
  children: React.ReactNode;
  className?: string;
  intensity?: number;
  flareColor?: 'golden-hour' | 'champagne' | 'rose-sunset';
}

export const LensPrismEffect: React.FC<LensPrismEffectProps> = ({
  children,
  className = '',
  intensity = 0.85,
  flareColor = 'golden-hour',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [coords, setCoords] = useState({ x: 50, y: 35 });
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const el = containerRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    setCoords({ x, y });
  };

  // Color profiles
  let flareGradient = 'radial-gradient(circle 280px at var(--fx) var(--fy), rgba(255, 235, 175, 0.42) 0%, rgba(245, 210, 150, 0.2) 30%, rgba(220, 180, 140, 0.08) 60%, transparent 80%)';
  let beamGradient = 'linear-gradient(105deg, transparent 35%, rgba(255, 248, 220, 0.3) 48%, rgba(255, 235, 180, 0.45) 50%, rgba(255, 220, 160, 0.25) 52%, transparent 65%)';

  if (flareColor === 'rose-sunset') {
    flareGradient = 'radial-gradient(circle 280px at var(--fx) var(--fy), rgba(255, 210, 215, 0.45) 0%, rgba(235, 170, 180, 0.2) 30%, rgba(210, 140, 160, 0.08) 60%, transparent 80%)';
    beamGradient = 'linear-gradient(105deg, transparent 35%, rgba(255, 230, 235, 0.3) 48%, rgba(255, 195, 205, 0.45) 50%, rgba(235, 160, 180, 0.25) 52%, transparent 65%)';
  }

  return (
    <div
      ref={containerRef}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onMouseMove={handleMouseMove}
      className={`relative overflow-hidden group ${className}`}
      style={
        {
          '--fx': `${coords.x}%`,
          '--fy': `${coords.y}%`,
        } as React.CSSProperties
      }
    >
      {children}

      {/* 35mm OPTICAL LENS FLARE RADIAL BLOOM */}
      <div
        className="absolute inset-0 pointer-events-none transition-opacity duration-500 z-20"
        style={{
          opacity: isHovered ? intensity : 0,
          background: flareGradient,
          mixBlendMode: 'screen',
        }}
      />

      {/* ANAMORPHIC HORIZONTAL SUNBEAM STREAK */}
      <div
        className="absolute inset-0 pointer-events-none transition-all duration-700 z-20"
        style={{
          opacity: isHovered ? intensity * 0.75 : 0,
          background: beamGradient,
          transform: `translate(${coords.x * 0.2 - 10}%, ${coords.y * 0.1 - 5}%)`,
          mixBlendMode: 'screen',
        }}
      />

      {/* COMPLEMENTARY OPTICAL RING HALO */}
      <div
        className="absolute w-28 h-28 rounded-full pointer-events-none transition-opacity duration-500 z-20 -translate-x-1/2 -translate-y-1/2 border border-[#FFF8E7]/35 shadow-[0_0_20px_rgba(255,235,180,0.3)]"
        style={{
          left: `${100 - coords.x * 0.8}%`,
          top: `${100 - coords.y * 0.8}%`,
          opacity: isHovered ? intensity * 0.6 : 0,
          mixBlendMode: 'screen',
        }}
      />
    </div>
  );
};
