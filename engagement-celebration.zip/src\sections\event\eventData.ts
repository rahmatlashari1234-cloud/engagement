export interface ScheduleEvent {
  time: string;
  title: string;
  description: string;
  location: string;
}

export const EVENT_META = {
  sectionNumber: "05 / Celebration Details",
  heading: "The Celebration",
  subheading: "All the essential information to join us for an evening of warmth, celebration, and gratitude.",
  displayDate: "Saturday, November 14, 2026",
  displayTime: "5:00 PM Eastern Standard Time",
  isoDate: "2026-11-14T17:00:00-05:00",
};

export const EVENT_VENUE = {
  name: "The Glasshouse Conservatory",
  estate: "Stone Hill Estate & Gardens",
  address: "842 Hilltop Ridge Road",
  cityStateZip: "Hudson Valley, NY 12538",
  googleMapsUrl: "https://maps.google.com/?q=Hudson+Valley+New+York",
  phone: "+1 (845) 555-0192",
  email: "celebration@ameliaanddaniel.com",
  valetNote: "Complimentary valet parking will be available at the estate entrance.",
  shuttleNote: "Shuttle transportation provided from The Beekman Arms Hotel starting at 4:15 PM.",
};

export const EVENT_SCHEDULE: ScheduleEvent[] = [
  {
    time: "5:00 PM",
    title: "Welcome Drinks & Passed Canapés",
    description: "Arrival at the Stone Hill Estate. Guests are welcomed to the conservatory garden terrace with champagne and seasonal small plates.",
    location: "Garden Terrace"
  },
  {
    time: "6:00 PM",
    title: "Engagement Ceremony & Ring Blessing",
    description: "An intimate ceremony celebrating our commitment, accompanied by live acoustic strings and personal blessings.",
    location: "The Glasshouse Conservatory"
  },
  {
    time: "7:15 PM",
    title: "Candlelit Dinner & Heartfelt Toasts",
    description: "A seasonal three-course farm-to-table dinner featuring local Hudson Valley harvests and toasts from our families.",
    location: "The Grand Atrium"
  },
  {
    time: "9:00 PM",
    title: "Dessert, Cocktails & Dancing",
    description: "Cutting the celebration cake, artisanal espresso bar, and dancing under the stars until midnight.",
    location: "The Conservatory Pavilion"
  }
];

export const DRESS_CODE_DATA = {
  title: "DRESS CODE",
  subtitle: "Formal Cocktail • Warm Earth & Muted Tones",
  description: "We invite you to dress in elegant formal cocktail attire. To complement the natural botanical aesthetic of the Glasshouse Conservatory, we encourage soft, muted shades such as warm ivory, champagne, dusty rose, muted sage, and deep charcoal.",
  palette: [
    { name: "Warm Ivory", hex: "#F8F5F0", border: "#E5DFD5" },
    { name: "Champagne", hex: "#D8C5A5", border: "#C8B492" },
    { name: "Dusty Rose", hex: "#B98F91", border: "#A77A7C" },
    { name: "Muted Sage", hex: "#9BA595", border: "#889481" },
    { name: "Muted Taupe", hex: "#6F6A63", border: "#5C5750" },
    { name: "Deep Charcoal", hex: "#20201E", border: "#0F0F0E" },
  ],
  footwearNote: "The ceremony and cocktail reception will take place across paved stone pathways and the conservatory lawn. Stiletto heels are welcome, though block heels or wedges may offer greater comfort."
};
