import React, { useState } from 'react';
import { HOME_EDITORIAL, HOME_DATE } from './homeData';
import { OptimizedImage } from '../../components/common/OptimizedImage';
import { Sparkles, Heart, Maximize2, Rotate3d, Image as ImageIcon } from 'lucide-react';
import { TiltCard } from '../../components/common/TiltCard';
import { BotanicalVine, RosePetal, PhotoFloralFlourish } from '../../components/common/FloralDecorations';
import { DiamondRingCanvas } from '../../components/3d/DiamondRingCanvas';
import { SpatialParallaxContainer } from '../../components/3d/SpatialParallaxContainer';
import { LensPrismEffect } from '../../components/animations/LensPrismEffect';

interface TheEngagementProps {
  onImageClick?: (imageUrl: string, title: string) => void;
}

export const TheEngagement: React.FC<TheEngagementProps> = ({ onImageClick }) => {
  const [centerpieceMode, setCenterpieceMode] = useState<'photo' | 'ring3d'>('photo');

  return (
    <section className="py-24 md:py-36 px-6 md:px-12 bg-[#F8F5F0] relative overflow-hidden border-t border-[#E5DFD5]/60">
      {/* Botanical Corner Vines & Drifting Petals */}
      <BotanicalVine position="top-left" size="lg" opacity={0.65} />
      <BotanicalVine position="top-right" size="lg" opacity={0.6} />
      <BotanicalVine position="bottom-left" size="md" opacity={0.5} />
      <BotanicalVine position="bottom-right" size="md" opacity={0.5} />

      <div className="absolute top-28 left-8 sm:left-14 pointer-events-none">
        <RosePetal variant={1} rotate={-10} scale={1} />
      </div>
      <div className="absolute top-48 right-10 pointer-events-none">
        <RosePetal variant={2} rotate={35} scale={0.9} />
      </div>
      <div className="absolute bottom-32 left-12 pointer-events-none">
        <RosePetal variant={3} rotate={15} scale={0.85} />
      </div>
      <div className="absolute bottom-20 right-14 pointer-events-none">
        <RosePetal variant={1} rotate={-25} scale={0.9} />
      </div>

      <SpatialParallaxContainer depthFactor={0.8}>
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-center gap-2 mb-6 text-[#B98F91]">
            <span className="w-8 h-[1px] bg-[#E5DFD5]" />
            <Sparkles className="w-3.5 h-3.5 text-[#B98F91]" />
            <span className="w-8 h-[1px] bg-[#E5DFD5]" />
          </div>

          {/* Section Heading */}
          <div className="text-center space-y-4 max-w-3xl mx-auto mb-10 md:mb-14">
            <span className="text-xs uppercase tracking-[0.28em] text-[#8C867E] font-medium">
              The Moment That Changed Everything
            </span>
            <h2 className="font-serif text-5xl sm:text-6xl md:text-7xl text-[#20201E] font-normal tracking-tight">
              {HOME_EDITORIAL.engagementHeading}
            </h2>
            
            <div className="py-2 inline-flex items-center gap-3 px-5 py-1.5 border border-[#D8C5A5] bg-[#FAF8F5]">
              <Heart className="w-3 h-3 text-[#B98F91] fill-[#B98F91]" />
              <span className="font-serif text-lg md:text-xl text-[#20201E] tracking-wide">
                {HOME_DATE.engagementDate}
              </span>
              <span className="text-[#8C867E] text-xs uppercase tracking-widest font-sans">
                • {HOME_DATE.engagementLocation}
              </span>
            </div>

            <p className="text-[#6F6A63] text-base md:text-lg font-light leading-relaxed pt-2">
              {HOME_EDITORIAL.engagementNarrative}
            </p>
          </div>

          {/* 3D Model vs Photograph Mode Switcher */}
          <div className="flex items-center justify-center gap-2 mb-8 z-20 relative">
            <div className="p-1 bg-[#FAF8F5] border border-[#D8C5A5] rounded-full shadow-xs inline-flex items-center gap-1">
              <button
                onClick={() => setCenterpieceMode('photo')}
                className={`px-4 py-1.5 rounded-full text-[11px] uppercase tracking-widest font-sans transition-all cursor-pointer flex items-center gap-1.5 ${
                  centerpieceMode === 'photo'
                    ? 'bg-[#20201E] text-white shadow-xs font-medium'
                    : 'text-[#6F6A63] hover:text-[#20201E]'
                }`}
              >
                <ImageIcon className="w-3.5 h-3.5" />
                <span>Proposal Photograph</span>
              </button>
              <button
                onClick={() => setCenterpieceMode('ring3d')}
                className={`px-4 py-1.5 rounded-full text-[11px] uppercase tracking-widest font-sans transition-all cursor-pointer flex items-center gap-1.5 ${
                  centerpieceMode === 'ring3d'
                    ? 'bg-[#20201E] text-white shadow-xs font-medium'
                    : 'text-[#6F6A63] hover:text-[#20201E]'
                }`}
              >
                <Rotate3d className="w-3.5 h-3.5 text-[#D8C5A5]" />
                <span>Interactive 3D Ring</span>
              </button>
            </div>
          </div>

          {/* Asymmetric 3-Photo Editorial Composition with 3D Tilt & Light Reflections */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-stretch">
            {/* Main Centerpiece (Switches between Photograph and 3D Ring) */}
            <div className="md:col-span-7">
              <TiltCard maxTilt={4} scale={1.015} glare={true} className="h-full">
                {centerpieceMode === 'photo' ? (
                  <LensPrismEffect className="h-full">
                    <div
                      onClick={() =>
                        onImageClick &&
                        onImageClick(
                          '/images/engagement-ring-reveal.png',
                          'The Proposal — She Said Yes'
                        )
                      }
                      className="relative h-full group cursor-pointer overflow-hidden bg-[#EDE6DC] border border-[#E5DFD5] shadow-[0_16px_40px_rgba(32,32,30,0.06)] min-h-[420px]"
                    >
                      <PhotoFloralFlourish position="top-left" className="opacity-95 z-20" />
                      <PhotoFloralFlourish position="bottom-right" className="opacity-95 z-20" />
                      <OptimizedImage
                        src="/images/engagement-ring-reveal.png"
                        alt="Amelia and Daniel engagement ring reveal kiss in sunlit meadow"
                        aspectRatio="4/3"
                        animation="zoom-hover"
                        cornerAccents={true}
                        curtainReveal={true}
                        className="w-full h-full"
                        objectFit="cover"
                        objectPosition="center 30%"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#20201E]/75 via-[#20201E]/15 to-transparent opacity-80 group-hover:opacity-90 transition-opacity duration-500" />
                      
                      {/* Floating Inspection Trigger */}
                      <div className="absolute top-4 right-4 z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#20201E]/60 backdrop-blur-sm text-white/90 text-[10px] tracking-widest uppercase font-sans rounded-full border border-white/20">
                          <Maximize2 className="w-3 h-3" />
                          <span>Expand</span>
                        </span>
                      </div>

                      <div className="absolute bottom-6 left-6 text-white transform transition-transform duration-500 group-hover:translate-x-1">
                        <span className="text-[10px] uppercase tracking-[0.2em] text-[#D8C5A5] font-sans block mb-1">
                          The Vow
                        </span>
                        <p className="font-serif text-2xl md:text-3xl font-light">
                          “With every breath, yes.”
                        </p>
                      </div>
                    </div>
                  </LensPrismEffect>
                ) : (
                  <div className="relative h-full bg-[#FAF8F5] border border-[#D8C5A5] shadow-[0_16px_40px_rgba(32,32,30,0.08)] overflow-hidden flex flex-col justify-between p-4 min-h-[420px]">
                    <PhotoFloralFlourish position="top-left" className="opacity-95 z-20" />
                    <PhotoFloralFlourish position="bottom-right" className="opacity-95 z-20" />
                    <DiamondRingCanvas height={430} autoRotate={true} interactive={true} />
                  </div>
                )}
              </TiltCard>
            </div>

          {/* Right Column: 2 Stacked Curated Editorial Prints */}
          <div className="md:col-span-5 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-1 gap-6">
            <TiltCard maxTilt={6} scale={1.02} glare={true}>
              <div
                onClick={() =>
                  onImageClick &&
                  onImageClick(
                    'https://images.unsplash.com/photo-1605100804763-247f67b3557e?auto=format&fit=crop&w=1200&q=85',
                    'The Antique Oval Diamond Ring'
                  )
                }
                className="relative group cursor-pointer overflow-hidden bg-[#EDE6DC] border border-[#E5DFD5] shadow-[0_10px_25px_rgba(32,32,30,0.05)]"
              >
                <PhotoFloralFlourish position="top-right" className="opacity-90 z-20" />
                <OptimizedImage
                  src="https://images.unsplash.com/photo-1605100804763-247f67b3557e?auto=format&fit=crop&w=1200&q=85"
                  alt="Heirloom antique diamond ring"
                  aspectRatio="16/10"
                  animation="zoom-hover"
                  cornerAccents={true}
                  className="w-full"
                  objectFit="cover"
                />
                
                {/* Micro Sparkle Indicator */}
                <div className="absolute top-3 right-3 z-10 flex items-center justify-center w-7 h-7 rounded-full bg-[#FAF8F5]/80 backdrop-blur-sm border border-[#E5DFD5] shadow-xs">
                  <Sparkles className="w-3.5 h-3.5 text-[#B98F91] animate-spin-slow" />
                </div>

                <div className="p-4 bg-[#FAF8F5] border-t border-[#E5DFD5] flex items-center justify-between">
                  <div>
                    <span className="text-[10px] uppercase tracking-widest text-[#8C867E] block">
                      The Ring
                    </span>
                    <span className="font-serif text-base text-[#20201E]">
                      Antique Oval Diamond
                    </span>
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    <span className="text-xs text-[#B98F91] font-serif italic">
                      Crafted 1948
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setCenterpieceMode('ring3d');
                      }}
                      className="inline-flex items-center gap-1 text-[10px] uppercase tracking-wider text-[#B98F91] hover:text-[#20201E] font-medium transition-colors cursor-pointer"
                      title="Inspect 3D Diamond Ring"
                    >
                      <Rotate3d className="w-3 h-3" />
                      <span>3D Model</span>
                    </button>
                  </div>
                </div>
              </div>
            </TiltCard>

            <TiltCard maxTilt={6} scale={1.02} glare={true}>
              <div
                onClick={() =>
                  onImageClick &&
                  onImageClick(
                    'https://images.unsplash.com/photo-1583939003579-730e3918a45a?auto=format&fit=crop&w=1200&q=85',
                    'Quiet embrace at dusk'
                  )
                }
                className="relative group cursor-pointer overflow-hidden bg-[#EDE6DC] border border-[#E5DFD5] shadow-[0_10px_25px_rgba(32,32,30,0.05)]"
              >
                <PhotoFloralFlourish position="bottom-left" className="opacity-90 z-20" />
                <OptimizedImage
                  src="/images/engagement-ring-reveal.png"
                  alt="Intimate tender couple portrait"
                  aspectRatio="16/10"
                  animation="zoom-hover"
                  cornerAccents={true}
                  className="w-full"
                  objectFit="cover"
                />
                <div className="p-4 bg-[#FAF8F5] border-t border-[#E5DFD5] flex items-center justify-between">
                  <div>
                    <span className="text-[10px] uppercase tracking-widest text-[#8C867E] block">
                      The Atmosphere
                    </span>
                    <span className="font-serif text-base text-[#20201E]">
                      Cliffside Twilight
                    </span>
                  </div>
                  <span className="text-xs text-[#9BA595] font-serif italic">
                    Positano
                  </span>
                </div>
              </div>
            </TiltCard>
          </div>
        </div>
      </div>
      </SpatialParallaxContainer>
    </section>
  );
};
