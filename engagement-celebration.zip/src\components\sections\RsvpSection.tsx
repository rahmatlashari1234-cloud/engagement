import React, { useState } from 'react';
import { SITE_CONFIG } from '../../data/engagementContent';
import { Check, Send } from 'lucide-react';

interface RsvpFormData {
  fullName: string;
  email: string;
  phone: string;
  attendance: 'accept' | 'decline' | null;
  guestCount: number;
  guestNames: string;
  dietaryRestrictions: string[];
  dietaryOther: string;
  message: string;
}

export const RsvpSection: React.FC = () => {
  const [formData, setFormData] = useState<RsvpFormData>({
    fullName: '',
    email: '',
    phone: '',
    attendance: 'accept',
    guestCount: 1,
    guestNames: '',
    dietaryRestrictions: [],
    dietaryOther: '',
    message: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const dietaryOptions = [
    'None / No restrictions',
    'Vegetarian',
    'Vegan',
    'Gluten-Free',
    'Dairy-Free',
    'Nut Allergy',
  ];

  const handleDietaryToggle = (option: string) => {
    setFormData((prev) => {
      const exists = prev.dietaryRestrictions.includes(option);
      if (option === 'None / No restrictions') {
        return {
          ...prev,
          dietaryRestrictions: exists ? [] : ['None / No restrictions'],
        };
      }
      const filtered = prev.dietaryRestrictions.filter(
        (item) => item !== 'None / No restrictions'
      );
      return {
        ...prev,
        dietaryRestrictions: exists
          ? filtered.filter((item) => item !== option)
          : [...filtered, option],
      };
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!formData.fullName.trim()) {
      setErrorMessage('Please enter your full name.');
      return;
    }
    if (!formData.email.trim() || !formData.email.includes('@')) {
      setErrorMessage('Please enter a valid email address.');
      return;
    }
    if (!formData.attendance) {
      setErrorMessage('Please specify your attendance.');
      return;
    }

    setIsSubmitting(true);

    // Simulate reliable smooth API response
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 800);
  };

  const handleReset = () => {
    setIsSubmitted(false);
    setFormData({
      fullName: '',
      email: '',
      phone: '',
      attendance: 'accept',
      guestCount: 1,
      guestNames: '',
      dietaryRestrictions: [],
      dietaryOther: '',
      message: '',
    });
  };

  return (
    <section id="rsvp" className="py-24 md:py-36 px-6 md:px-12 bg-[#F8F5F0] border-t border-[#E5DFD5]/60">
      <div className="max-w-3xl mx-auto">
        {/* Section Header */}
        <div className="text-center space-y-4 mb-14 md:mb-18">
          <span className="text-[11px] tracking-[0.26em] uppercase text-[#B98F91] font-semibold">
            07 / Kindly Respond
          </span>
          <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl text-[#20201E] font-normal tracking-tight">
            We’d Love to Celebrate With You
          </h2>
          <p className="text-sm md:text-base text-[#6F6A63] font-light leading-relaxed max-w-lg mx-auto">
            Please let us know if you can join us by{' '}
            <strong className="font-medium text-[#20201E]">
              {SITE_CONFIG.celebrationDate.rsvpDeadline}
            </strong>
            .
          </p>
          <div className="w-12 h-[1px] bg-[#D8C5A5] mx-auto mt-4" />
        </div>

        {/* Confirmation Success View */}
        {isSubmitted ? (
          <div className="p-8 md:p-14 bg-[#FAF8F5] border border-[#D8C5A5] shadow-lg text-center space-y-6 animate-fade-in">
            <div className="w-14 h-14 rounded-full bg-[#9BA595]/15 border border-[#9BA595] text-[#9BA595] flex items-center justify-center mx-auto">
              <Check className="w-7 h-7" />
            </div>

            <div className="space-y-2">
              <span className="text-xs uppercase tracking-[0.2em] text-[#8C867E]">
                Response Received
              </span>
              <h3 className="font-serif text-3xl md:text-4xl text-[#20201E]">
                {formData.attendance === 'accept'
                  ? 'We Can’t Wait to Celebrate!'
                  : 'We Will Miss You Dearly'}
              </h3>
              <p className="text-sm text-[#6F6A63] font-light max-w-md mx-auto pt-1">
                Thank you, <strong className="text-[#20201E]">{formData.fullName}</strong>. A confirmation has been recorded for{' '}
                <strong className="text-[#20201E]">{formData.email}</strong>.
              </p>
            </div>

            {/* Receipt Summary Card */}
            <div className="p-4 bg-[#F2ECE4] border border-[#E5DFD5] text-left text-xs space-y-2 max-w-md mx-auto">
              <div className="flex justify-between">
                <span className="text-[#8C867E]">Attendance:</span>
                <span className="font-medium text-[#20201E]">
                  {formData.attendance === 'accept' ? 'Joyfully Attending' : 'Regretfully Declining'}
                </span>
              </div>
              {formData.attendance === 'accept' && (
                <div className="flex justify-between">
                  <span className="text-[#8C867E]">Total Guests:</span>
                  <span className="font-medium text-[#20201E]">{formData.guestCount}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-[#8C867E]">Celebration Date:</span>
                <span className="font-medium text-[#20201E]">
                  {SITE_CONFIG.celebrationDate.display}
                </span>
              </div>
            </div>

            <div className="pt-4 flex flex-wrap justify-center gap-4">
              <button
                onClick={handleReset}
                className="px-6 py-2.5 bg-[#20201E] text-[#F8F5F0] text-xs uppercase tracking-[0.16em] font-medium hover:bg-[#3A3935] transition-colors"
              >
                Submit Another Response
              </button>
            </div>
          </div>
        ) : (
          /* Form Card */
          <form
            onSubmit={handleSubmit}
            className="p-8 md:p-12 bg-[#FAF8F5] border border-[#E5DFD5] shadow-[0_8px_30px_rgba(32,32,30,0.03)] space-y-8"
          >
            {errorMessage && (
              <div className="p-3 bg-[#B98F91]/15 border border-[#B98F91] text-xs text-[#20201E] font-medium">
                {errorMessage}
              </div>
            )}

            {/* Attendance Choice Buttons */}
            <div className="space-y-3">
              <label className="block text-xs uppercase tracking-[0.18em] text-[#20201E] font-medium">
                Will you be attending? *
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, attendance: 'accept' })}
                  className={`p-4 border text-left flex items-center justify-between transition-all duration-200 ${
                    formData.attendance === 'accept'
                      ? 'border-[#20201E] bg-[#F2ECE4] shadow-sm'
                      : 'border-[#E5DFD5] bg-[#F8F5F0] hover:border-[#D8C5A5]'
                  }`}
                >
                  <div>
                    <span className="font-serif text-lg text-[#20201E] block">
                      Joyfully Accept
                    </span>
                    <span className="text-xs text-[#6F6A63] font-light">
                      I will attend with joy
                    </span>
                  </div>
                  <div
                    className={`w-5 h-5 rounded-full border flex items-center justify-center ${
                      formData.attendance === 'accept'
                        ? 'border-[#20201E] bg-[#20201E] text-white'
                        : 'border-[#E5DFD5]'
                    }`}
                  >
                    {formData.attendance === 'accept' && <Check className="w-3 h-3" />}
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, attendance: 'decline' })}
                  className={`p-4 border text-left flex items-center justify-between transition-all duration-200 ${
                    formData.attendance === 'decline'
                      ? 'border-[#20201E] bg-[#F2ECE4] shadow-sm'
                      : 'border-[#E5DFD5] bg-[#F8F5F0] hover:border-[#D8C5A5]'
                  }`}
                >
                  <div>
                    <span className="font-serif text-lg text-[#20201E] block">
                      Regretfully Decline
                    </span>
                    <span className="text-xs text-[#6F6A63] font-light">
                      Celebrating from afar
                    </span>
                  </div>
                  <div
                    className={`w-5 h-5 rounded-full border flex items-center justify-center ${
                      formData.attendance === 'decline'
                        ? 'border-[#20201E] bg-[#20201E] text-white'
                        : 'border-[#E5DFD5]'
                    }`}
                  >
                    {formData.attendance === 'decline' && <Check className="w-3 h-3" />}
                  </div>
                </button>
              </div>
            </div>

            {/* Name, Email, Phone */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="space-y-1.5 sm:col-span-2">
                <label className="block text-xs uppercase tracking-[0.16em] text-[#6F6A63]">
                  Your Full Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Clara Harrington"
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  className="w-full px-4 py-3 bg-[#F8F5F0] border border-[#E5DFD5] text-[#20201E] text-sm focus:outline-none focus:border-[#20201E] transition-colors"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs uppercase tracking-[0.16em] text-[#6F6A63]">
                  Email Address *
                </label>
                <input
                  type="email"
                  required
                  placeholder="clara@example.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-4 py-3 bg-[#F8F5F0] border border-[#E5DFD5] text-[#20201E] text-sm focus:outline-none focus:border-[#20201E] transition-colors"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs uppercase tracking-[0.16em] text-[#6F6A63]">
                  Phone Number
                </label>
                <input
                  type="tel"
                  placeholder="+1 (555) 000-0000"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full px-4 py-3 bg-[#F8F5F0] border border-[#E5DFD5] text-[#20201E] text-sm focus:outline-none focus:border-[#20201E] transition-colors"
                />
              </div>
            </div>

            {/* Guest Count (if attending) */}
            {formData.attendance === 'accept' && (
              <div className="space-y-6 pt-2 border-t border-[#E5DFD5]">
                <div className="space-y-2">
                  <label className="block text-xs uppercase tracking-[0.16em] text-[#6F6A63]">
                    Number of Guests Attending (including yourself)
                  </label>
                  <div className="flex items-center gap-3">
                    {[1, 2, 3, 4].map((count) => (
                      <button
                        key={count}
                        type="button"
                        onClick={() => setFormData({ ...formData, guestCount: count })}
                        className={`w-12 h-11 border text-sm font-medium transition-all ${
                          formData.guestCount === count
                            ? 'bg-[#20201E] text-[#F8F5F0] border-[#20201E]'
                            : 'bg-[#F8F5F0] text-[#6F6A63] border-[#E5DFD5] hover:border-[#D8C5A5]'
                        }`}
                      >
                        {count}
                      </button>
                    ))}
                  </div>
                </div>

                {formData.guestCount > 1 && (
                  <div className="space-y-1.5 animate-fade-in">
                    <label className="block text-xs uppercase tracking-[0.16em] text-[#6F6A63]">
                      Accompanying Guest Name(s)
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Julian Vance"
                      value={formData.guestNames}
                      onChange={(e) =>
                        setFormData({ ...formData, guestNames: e.target.value })
                      }
                      className="w-full px-4 py-3 bg-[#F8F5F0] border border-[#E5DFD5] text-[#20201E] text-sm focus:outline-none focus:border-[#20201E] transition-colors"
                    />
                  </div>
                )}

                {/* Dietary Requirements */}
                <div className="space-y-2 pt-2">
                  <label className="block text-xs uppercase tracking-[0.16em] text-[#6F6A63]">
                    Dietary Preferences
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                    {dietaryOptions.map((option) => {
                      const isSelected = formData.dietaryRestrictions.includes(option);
                      return (
                        <button
                          key={option}
                          type="button"
                          onClick={() => handleDietaryToggle(option)}
                          className={`p-2.5 text-xs text-left border flex items-center justify-between transition-colors ${
                            isSelected
                              ? 'border-[#20201E] bg-[#F2ECE4] text-[#20201E] font-medium'
                              : 'border-[#E5DFD5] bg-[#F8F5F0] text-[#6F6A63] hover:border-[#D8C5A5]'
                          }`}
                        >
                          <span className="truncate">{option}</span>
                          {isSelected && <Check className="w-3 h-3 text-[#B98F91] shrink-0" />}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* Message / Well Wishes */}
            <div className="space-y-1.5 pt-2 border-t border-[#E5DFD5]">
              <label className="block text-xs uppercase tracking-[0.16em] text-[#6F6A63]">
                Warm Wishes or Song Request
              </label>
              <textarea
                rows={3}
                placeholder="Share a heartfelt message, memory, or song to play on the dance floor..."
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                className="w-full px-4 py-3 bg-[#F8F5F0] border border-[#E5DFD5] text-[#20201E] text-sm focus:outline-none focus:border-[#20201E] transition-colors resize-none"
              />
            </div>

            {/* Submit Button */}
            <div className="pt-4">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-4 bg-[#20201E] text-[#F8F5F0] uppercase text-xs tracking-[0.24em] font-medium hover:bg-[#383733] transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-70 shadow-sm"
              >
                {isSubmitting ? (
                  <span>Submitting RSVP...</span>
                ) : (
                  <>
                    <span>Confirm Response</span>
                    <Send className="w-3.5 h-3.5 text-[#D8C5A5]" />
                  </>
                )}
              </button>

              <p className="text-center text-[11px] text-[#8C867E] font-light mt-3">
                Need to amend an existing RSVP later? Reach out to{' '}
                <a
                  href={`mailto:${SITE_CONFIG.venue.email}`}
                  className="underline hover:text-[#20201E]"
                >
                  {SITE_CONFIG.venue.email}
                </a>
              </p>
            </div>
          </form>
        )}
      </div>
    </section>
  );
};
