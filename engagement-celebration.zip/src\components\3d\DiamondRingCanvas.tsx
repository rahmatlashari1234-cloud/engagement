import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { Rotate3d, Sparkles, Maximize2, Minimize2 } from 'lucide-react';

interface DiamondRingCanvasProps {
  className?: string;
  autoRotate?: boolean;
  interactive?: boolean;
  height?: number | string;
}

export const DiamondRingCanvas: React.FC<DiamondRingCanvasProps> = ({
  className = '',
  autoRotate = true,
  interactive = true,
  height = 380,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const isDraggingRef = useRef(false);
  const previousMousePositionRef = useRef({ x: 0, y: 0 });
  const rotationVelocityRef = useRef({ x: 0, y: 0.006 });
  const [isHovered, setIsHovered] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // SCENE, CAMERA, RENDERER
    const scene = new THREE.Scene();
    const width = container.clientWidth || 400;
    const heightNum = typeof height === 'number' ? height : container.clientHeight || 380;

    const camera = new THREE.PerspectiveCamera(38, width / heightNum, 0.1, 1000);
    camera.position.set(0, 1.2, 7.5);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setSize(width, heightNum);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.35;
    container.appendChild(renderer.domElement);

    // GROUP FOR THE RING
    const ringGroup = new THREE.Group();
    scene.add(ringGroup);

    // 1. GOLD BAND MATERIAL (PBR Metallic Yellow Gold)
    const goldMaterial = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(0xd4af37), // 18k yellow gold
      emissive: new THREE.Color(0x2a1a05),
      roughness: 0.14,
      metalness: 0.94,
      clearcoat: 1.0,
      clearcoatRoughness: 0.08,
      reflectivity: 1.0,
    });

    // 18k White Gold / Platinum Prong Material
    const platinumMaterial = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(0xf0f0f5),
      roughness: 0.1,
      metalness: 0.96,
      clearcoat: 1.0,
      clearcoatRoughness: 0.05,
    });

    // Ring Band Geometry (Smooth Torus)
    const bandGeometry = new THREE.TorusGeometry(1.65, 0.16, 32, 100);
    const bandMesh = new THREE.Mesh(bandGeometry, goldMaterial);
    bandMesh.rotation.x = Math.PI / 2;
    ringGroup.add(bandMesh);

    // Inner Comfort Fit Bevel Band
    const innerBandGeometry = new THREE.TorusGeometry(1.63, 0.11, 24, 80);
    const innerBandMesh = new THREE.Mesh(innerBandGeometry, goldMaterial);
    innerBandMesh.rotation.x = Math.PI / 2;
    ringGroup.add(innerBandMesh);

    // 2. DIAMOND CROWN & PRONGS
    const crownGroup = new THREE.Group();
    crownGroup.position.set(0, 1.62, 0);
    ringGroup.add(crownGroup);

    // 6 Cathedral Prongs Holding the Diamond
    const prongCount = 6;
    for (let i = 0; i < prongCount; i++) {
      const angle = (i / prongCount) * Math.PI * 2;
      const radius = 0.42;
      const px = Math.cos(angle) * radius;
      const pz = Math.sin(angle) * radius;

      const prongGeometry = new THREE.CylinderGeometry(0.04, 0.065, 0.72, 16);
      const prongMesh = new THREE.Mesh(prongGeometry, platinumMaterial);
      prongMesh.position.set(px, 0.28, pz);
      // Slight inward tilt
      prongMesh.rotation.z = -Math.cos(angle) * 0.15;
      prongMesh.rotation.x = Math.sin(angle) * 0.15;
      crownGroup.add(prongMesh);

      // Prong tip claw
      const tipGeometry = new THREE.SphereGeometry(0.05, 12, 12);
      const tipMesh = new THREE.Mesh(tipGeometry, platinumMaterial);
      tipMesh.position.set(px * 0.95, 0.64, pz * 0.95);
      crownGroup.add(tipMesh);
    }

    // Basket gallery ring underneath diamond
    const galleryRingGeom = new THREE.TorusGeometry(0.38, 0.035, 16, 40);
    const galleryRing = new THREE.Mesh(galleryRingGeom, platinumMaterial);
    galleryRing.rotation.x = Math.PI / 2;
    galleryRing.position.y = 0.25;
    crownGroup.add(galleryRing);

    // 3. BRILLIANT-CUT FACETED DIAMOND GEM
    const diamondMaterial = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(0xffffff),
      transmission: 0.92,
      opacity: 1,
      transparent: true,
      roughness: 0.04,
      ior: 2.417, // Natural diamond refractive index
      reflectivity: 0.9,
      clearcoat: 1.0,
      clearcoatRoughness: 0.02,
      flatShading: true, // Creates sparkling flat geometric facets
      dispersion: 0.044,
    });

    // Diamond Crown (Top Cone)
    const crownGemGeom = new THREE.CylinderGeometry(0.52, 0.78, 0.28, 16, 2, false);
    const crownGem = new THREE.Mesh(crownGemGeom, diamondMaterial);
    crownGem.position.y = 0.52;
    crownGroup.add(crownGem);

    // Diamond Table (Top flat facet)
    const tableGeom = new THREE.CircleGeometry(0.51, 16);
    const tableMesh = new THREE.Mesh(tableGeom, diamondMaterial);
    tableMesh.rotation.x = -Math.PI / 2;
    tableMesh.position.y = 0.66;
    crownGroup.add(tableMesh);

    // Diamond Pavilion (Bottom Cone)
    const pavilionGeom = new THREE.ConeGeometry(0.78, 0.72, 16, 2, false);
    const pavilion = new THREE.Mesh(pavilionGeom, diamondMaterial);
    pavilion.rotation.x = Math.PI;
    pavilion.position.y = 0.02;
    crownGroup.add(pavilion);

    // Pavé Accent Diamonds on the Band Shoulders
    const paveCount = 8;
    for (let i = 0; i < paveCount; i++) {
      const shoulderAngle = 0.18 + (i * 0.07);
      [-1, 1].forEach((dir) => {
        const x = Math.sin(shoulderAngle * dir) * 1.65;
        const y = Math.cos(shoulderAngle * dir) * 1.65;
        const paveGeom = new THREE.OctahedronGeometry(0.065, 0);
        const paveMesh = new THREE.Mesh(paveGeom, diamondMaterial);
        paveMesh.position.set(x, y, 0);
        paveMesh.rotation.set(Math.random(), Math.random(), Math.random());
        ringGroup.add(paveMesh);
      });
    }

    // 4. FLOATING CAUSTIC SPARKLE PARTICLES
    const sparkleCount = 35;
    const sparkleGeom = new THREE.BufferGeometry();
    const sparklePositions = new Float32Array(sparkleCount * 3);
    const sparkleScales = new Float32Array(sparkleCount);

    for (let i = 0; i < sparkleCount; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 2 - 1);
      const dist = 1.2 + Math.random() * 1.8;
      sparklePositions[i * 3] = Math.sin(phi) * Math.cos(theta) * dist;
      sparklePositions[i * 3 + 1] = Math.cos(phi) * dist + 1.2;
      sparklePositions[i * 3 + 2] = Math.sin(phi) * Math.sin(theta) * dist;
      sparkleScales[i] = 0.5 + Math.random() * 0.8;
    }
    sparkleGeom.setAttribute('position', new THREE.BufferAttribute(sparklePositions, 3));

    const sparkleMaterial = new THREE.PointsMaterial({
      color: new THREE.Color(0xffeedd),
      size: 0.12,
      transparent: true,
      opacity: 0.85,
      blending: THREE.AdditiveBlending,
    });
    const sparklePoints = new THREE.Points(sparkleGeom, sparkleMaterial);
    ringGroup.add(sparklePoints);

    // 5. LIGHTING RIG
    const ambientLight = new THREE.AmbientLight(0xfff7ed, 1.4);
    scene.add(ambientLight);

    // Warm Sun Directional Light
    const keyLight = new THREE.DirectionalLight(0xffeedd, 3.2);
    keyLight.position.set(5, 8, 6);
    scene.add(keyLight);

    // Diamond Sparkle Cool Fill Light
    const fillLight = new THREE.DirectionalLight(0xdbeafe, 2.8);
    fillLight.position.set(-6, -3, 4);
    scene.add(fillLight);

    // Orbiting Prismatic Point Lights (Create dynamic flashes as diamond spins)
    const sparkleLight1 = new THREE.PointLight(0xfff1e6, 4.5, 8);
    sparkleLight1.position.set(1.5, 2.5, 2);
    scene.add(sparkleLight1);

    const sparkleLight2 = new THREE.PointLight(0xe0f2fe, 3.5, 7);
    sparkleLight2.position.set(-2, 1.8, 1.5);
    scene.add(sparkleLight2);

    // Initial ring presentation tilt
    ringGroup.rotation.x = 0.35;
    ringGroup.rotation.y = -0.5;

    // 6. MOUSE / TOUCH INTERACTION HANDLERS
    const onMouseDown = (e: MouseEvent) => {
      if (!interactive) return;
      isDraggingRef.current = true;
      previousMousePositionRef.current = { x: e.clientX, y: e.clientY };
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDraggingRef.current || !interactive) return;
      const deltaX = e.clientX - previousMousePositionRef.current.x;
      const deltaY = e.clientY - previousMousePositionRef.current.y;

      ringGroup.rotation.y += deltaX * 0.01;
      ringGroup.rotation.x += deltaY * 0.01;

      rotationVelocityRef.current = {
        x: deltaY * 0.005,
        y: deltaX * 0.005,
      };

      previousMousePositionRef.current = { x: e.clientX, y: e.clientY };
    };

    const onMouseUp = () => {
      isDraggingRef.current = false;
    };

    // Touch support for mobile
    const onTouchStart = (e: TouchEvent) => {
      if (!interactive || e.touches.length === 0) return;
      isDraggingRef.current = true;
      previousMousePositionRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    };

    const onTouchMove = (e: TouchEvent) => {
      if (!isDraggingRef.current || !interactive || e.touches.length === 0) return;
      const deltaX = e.touches[0].clientX - previousMousePositionRef.current.x;
      const deltaY = e.touches[0].clientY - previousMousePositionRef.current.y;

      ringGroup.rotation.y += deltaX * 0.01;
      ringGroup.rotation.x += deltaY * 0.01;

      rotationVelocityRef.current = {
        x: deltaY * 0.005,
        y: deltaX * 0.005,
      };

      previousMousePositionRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    };

    const onTouchEnd = () => {
      isDraggingRef.current = false;
    };

    container.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);

    container.addEventListener('touchstart', onTouchStart, { passive: true });
    window.addEventListener('touchmove', onTouchMove, { passive: true });
    window.addEventListener('touchend', onTouchEnd);

    // Resize handler
    const onResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = typeof height === 'number' ? height : container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);

    // 7. ANIMATION LOOP
    let animationFrameId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      // Dynamic orbiting sparkle lights
      sparkleLight1.position.x = Math.sin(elapsedTime * 1.5) * 3;
      sparkleLight1.position.z = Math.cos(elapsedTime * 1.5) * 3;
      sparkleLight2.position.x = Math.cos(elapsedTime * 1.2) * 2.5;
      sparkleLight2.position.y = 1.8 + Math.sin(elapsedTime * 2) * 0.5;

      // Idle float & rotation physics
      if (!isDraggingRef.current) {
        if (autoRotate) {
          ringGroup.rotation.y += rotationVelocityRef.current.y;
          ringGroup.rotation.x += rotationVelocityRef.current.x;
          // Apply damping to return to gentle idle spin
          rotationVelocityRef.current.y = THREE.MathUtils.lerp(rotationVelocityRef.current.y, 0.008, 0.04);
          rotationVelocityRef.current.x = THREE.MathUtils.lerp(rotationVelocityRef.current.x, 0, 0.04);
        }
      }

      // Gentle floating bob
      ringGroup.position.y = Math.sin(elapsedTime * 1.8) * 0.08;

      // Sparkles pulse
      sparklePoints.rotation.y = elapsedTime * 0.2;

      renderer.render(scene, camera);
    };
    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', onResize);
      container.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      container.removeEventListener('touchstart', onTouchStart);
      window.removeEventListener('touchmove', onTouchMove);
      window.removeEventListener('touchend', onTouchEnd);
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
      goldMaterial.dispose();
      platinumMaterial.dispose();
      diamondMaterial.dispose();
    };
  }, [autoRotate, interactive, height, fullscreen]);

  return (
    <div
      className={`relative w-full overflow-hidden select-none group cursor-grab active:cursor-grabbing ${className}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      style={{ height: fullscreen ? '100vh' : height }}
    >
      {/* 3D WebGL Canvas Mount */}
      <div ref={containerRef} className="w-full h-full" />

      {/* 3D Interactive Badge Overlay */}
      <div className="absolute top-3 left-3 z-10 flex items-center gap-2 px-3 py-1 bg-[#20201E]/60 backdrop-blur-md rounded-full border border-white/20 text-white text-[10px] tracking-widest uppercase font-sans pointer-events-none">
        <Rotate3d className="w-3.5 h-3.5 text-[#D8C5A5] animate-spin-slow" />
        <span>Interactive 3D • Drag to Spin</span>
      </div>

      {/* Sparkle Diamond Specs Overlay on Hover */}
      <div
        className={`absolute bottom-3 left-3 right-3 sm:right-auto z-10 p-2.5 px-3.5 bg-[#FAF8F5]/90 backdrop-blur-md border border-[#D8C5A5] text-[#20201E] shadow-sm transition-opacity duration-300 pointer-events-none rounded-xs ${
          isHovered ? 'opacity-100' : 'opacity-85'
        }`}
      >
        <div className="flex items-center gap-2">
          <Sparkles className="w-3.5 h-3.5 text-[#B98F91]" />
          <span className="font-serif text-xs font-medium">Heirloom Oval Brilliant Diamond</span>
        </div>
        <span className="block text-[9px] uppercase tracking-wider text-[#8C867E] pt-0.5 font-mono">
          18K Gold • Cathedral 6-Prong Setting • 360° Inspection
        </span>
      </div>

      {/* Fullscreen Expansion Toggle */}
      <button
        onClick={() => setFullscreen(!fullscreen)}
        className="absolute top-3 right-3 z-10 p-1.5 bg-[#20201E]/60 hover:bg-[#20201E]/80 backdrop-blur-md text-white/90 rounded-full border border-white/20 transition-all cursor-pointer"
        title={fullscreen ? 'Exit Fullscreen 3D' : 'Inspect Fullscreen 3D'}
      >
        {fullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
      </button>
    </div>
  );
};
