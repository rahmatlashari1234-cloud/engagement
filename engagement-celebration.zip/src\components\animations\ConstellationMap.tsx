import React, { useState, useEffect, useRef } from 'react';
import { Sparkles, Compass } from 'lucide-react';

interface ConstellationNode {
  id: string;
  x: number; // percentage
  y: number; // percentage
  name: string;
  date: string;
  story: string;
}

const CONSTELLATION_NODES: ConstellationNode[] = [
  {
    id: 'first-met',
    x: 24,
    y: 38,
    name: 'The First Spark',
    date: 'Autumn 2021',
    story: 'Two paths crossed beneath golden autumn foliage in New York City.',
  },
  {
    id: 'first-trip',
    x: 44,
    y: 25,
    name: 'First Voyage',
    date: 'Summer 2022',
    story: 'Wandering cobblestone alleys and laughing under Mediterranean stars.',
  },
  {
    id: 'the-proposal',
    x: 62,
    y: 65,
    name: 'The Proposal',
    date: 'October 2026',
    story: 'A whispered promise, a diamond ring, and an eternal "Yes".',
  },
  {
    id: 'forever',
    x: 78,
    y: 40,
    name: 'Forever Written',
    date: 'Our Tomorrow',
    story: 'The beginning of our forever, surrounded by family, love, and grace.',
  },
];

export const ConstellationMap: React.FC<{ className?: string }> = ({ className = '' }) => {
  const [activeNode, setActiveNode] = useState<ConstellationNode | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Background ambient starlight twinkling
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let width = (canvas.width = canvas.parentElement?.clientWidth || 800);
    let height = (canvas.height = 360);

    const stars: { x: number; y: number; r: number; alpha: number; speed: number }[] = [];
    for (let i = 0; i < 90; i++) {
      stars.push({
        x: Math.random() * width,
        y: Math.random() * height,
        r: Math.random() * 1.5 + 0.5,
        alpha: Math.random(),
        speed: Math.random() * 0.02 + 0.008,
      });
    }

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      // Draw faint stars
      stars.forEach((s) => {
        s.alpha += s.speed;
        const currentAlpha = 0.2 + Math.abs(Math.sin(s.alpha)) * 0.7;
        ctx.fillStyle = `rgba(216, 197, 165, ${currentAlpha})`;
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fill();
      });

      animId = requestAnimationFrame(render);
    };

    render();

    const handleResize = () => {
      width = canvas.width = canvas.parentElement?.clientWidth || 800;
      height = canvas.height = 360;
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <div
      className={`relative w-full max-w-4xl mx-auto rounded-xl overflow-hidden bg-[#161513] border border-[#D8C5A5]/35 p-6 sm:p-10 text-[#F8F5F0] shadow-2xl ${className}`}
    >
      {/* Background Star Canvas */}
      <canvas ref={canvasRef} className="absolute inset-0 pointer-events-none z-0 w-full h-full" />

      {/* Header */}
      <div className="relative z-10 flex items-center justify-between border-b border-[#D8C5A5]/25 pb-4 mb-8">
        <div className="flex items-center gap-2">
          <Compass className="w-4 h-4 text-[#D8C5A5]" />
          <span className="text-[11px] uppercase tracking-[0.24em] font-sans text-[#D8C5A5]">
            Celestial Constellation of Love
          </span>
        </div>
        <span className="text-xs font-serif italic text-[#B98F91]">
          Written in the Stars
        </span>
      </div>

      {/* Constellation Sky Interactive Stage */}
      <div className="relative w-full h-72 sm:h-80 z-10">
        {/* SVG Golden Thread Lines connecting the milestone stars */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none overflow-visible">
          <defs>
            <linearGradient id="starlightLine" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#D8C5A5" stopOpacity="0.4" />
              <stop offset="50%" stopColor="#FFF2D6" stopOpacity="0.9" />
              <stop offset="100%" stopColor="#B98F91" stopOpacity="0.5" />
            </linearGradient>
          </defs>

          {/* Connected Constellation Polygon */}
          <path
            d={`M ${CONSTELLATION_NODES[0].x}% ${CONSTELLATION_NODES[0].y}% 
               L ${CONSTELLATION_NODES[1].x}% ${CONSTELLATION_NODES[1].y}% 
               L ${CONSTELLATION_NODES[2].x}% ${CONSTELLATION_NODES[2].y}% 
               L ${CONSTELLATION_NODES[3].x}% ${CONSTELLATION_NODES[3].y}%`}
            stroke="url(#starlightLine)"
            strokeWidth="1.6"
            strokeDasharray="4, 4"
            fill="none"
            className="animate-pulse"
          />

          {/* Heart Arc loop back to the first spark */}
          <path
            d={`M ${CONSTELLATION_NODES[3].x}% ${CONSTELLATION_NODES[3].y}% 
               C 60% 15%, 40% 15%, 
               ${CONSTELLATION_NODES[0].x}% ${CONSTELLATION_NODES[0].y}%`}
            stroke="url(#starlightLine)"
            strokeWidth="1"
            strokeDasharray="2, 4"
            fill="none"
            opacity="0.5"
          />
        </svg>

        {/* Milestone Star Nodes */}
        {CONSTELLATION_NODES.map((node) => {
          const isSelected = activeNode?.id === node.id;

          return (
            <div
              key={node.id}
              style={{ left: `${node.x}%`, top: `${node.y}%` }}
              onMouseEnter={() => setActiveNode(node)}
              onClick={() => setActiveNode(node)}
              className="absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer group z-20"
            >
              {/* Pulsing Star Core */}
              <div className="relative flex items-center justify-center">
                <div
                  className={`w-4 h-4 rounded-full border transition-all duration-300 flex items-center justify-center ${
                    isSelected
                      ? 'border-[#FFF2D6] bg-[#D8C5A5] scale-150 shadow-[0_0_18px_#FFF2D6]'
                      : 'border-[#D8C5A5]/80 bg-[#1C1B19] group-hover:scale-125 group-hover:border-[#FFF2D6]'
                  }`}
                >
                  <Sparkles
                    className={`w-2.5 h-2.5 ${
                      isSelected ? 'text-[#1C1B19]' : 'text-[#D8C5A5]'
                    }`}
                  />
                </div>

                {/* Star Glow Halo */}
                <div className="absolute inset-0 w-8 h-8 -m-2 rounded-full bg-[#D8C5A5]/10 animate-ping pointer-events-none" />
              </div>

              {/* Node Title Label */}
              <div className="mt-2 text-center whitespace-nowrap">
                <span className="block text-[10px] uppercase tracking-wider text-[#D8C5A5] font-sans font-medium">
                  {node.name}
                </span>
                <span className="block text-[9px] font-mono text-[#8C867E]">
                  {node.date}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Active Story Card at Bottom */}
      <div className="relative z-10 mt-4 p-4 rounded-md bg-[#201F1C]/90 border border-[#D8C5A5]/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 min-h-[70px]">
        <div>
          <span className="text-[10px] uppercase tracking-[0.2em] text-[#B98F91] font-semibold">
            {activeNode ? activeNode.name : 'Hover or Tap Any Star Node'}
          </span>
          <p className="text-xs sm:text-sm text-[#E5DFD5] font-light mt-0.5">
            {activeNode
              ? activeNode.story
              : 'Trace the celestial alignment of moments that led Amelia and Daniel to this holy union.'}
          </p>
        </div>
        {activeNode && (
          <span className="text-[11px] font-serif italic text-[#D8C5A5] whitespace-nowrap self-end sm:self-auto">
            {activeNode.date}
          </span>
        )}
      </div>
    </div>
  );
};
