import { useState, useEffect } from 'react';
import { Navbar } from './components/layout/Navbar';
import type { SectionKey } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';
import { SingleImageModal } from './components/modals/SingleImageModal';

// Dedicated Cover Section (Matching User Reference Template: Kinza Envelope)
import { CoverSection } from './sections/cover/CoverSection';

// Home Section Components (homeData only)
import { Hero } from './sections/home/Hero';
import { InvitationEnvelope } from './sections/home/InvitationEnvelope';
import { EngagementIntro } from './sections/home/EngagementIntro';
import { TheEngagement } from './sections/home/TheEngagement';
import { Countdown } from './sections/home/Countdown';
import { SectionPortals } from './sections/home/SectionPortals';
import { LoveNote } from './sections/home/LoveNote';
import { FinalPhoto } from './sections/home/FinalPhoto';

// Dedicated Section Components (each section has its own data co-located)
import { TheirStory } from './sections/story/TheirStory';
import { MomentsWeKeep } from './sections/moments/MomentsWeKeep';
import { PhotoGallery } from './sections/gallery/PhotoGallery';
import { EventDetails } from './sections/event/EventDetails';
import { DressCode } from './sections/event/DressCode';
import { HudsonValleyGuide } from './sections/guide/HudsonValleyGuide';
import { SoundtrackMixtape } from './sections/soundtrack/SoundtrackMixtape';
import { WishingWell } from './sections/wishingWell/WishingWell';
import { ToastBook } from './sections/toastBook/ToastBook';
import { Families } from './sections/families/Families';
import { GuestFaq } from './sections/faq/GuestFaq';
import { RsvpSection } from './sections/rsvp/RsvpSection';

import { ArrowLeft, ArrowRight, Home as HomeIcon } from 'lucide-react';
import { RosePetals3D } from './components/3d/RosePetals3D';
import { MagneticPearlCursor } from './components/animations/MagneticPearlCursor';
import { AmbientSoundscape } from './components/animations/AmbientSoundscape';

export function App() {
  const [activeSection, setActiveSection] = useState<SectionKey>('cover');
  const [showAllSections, setShowAllSections] = useState<boolean>(false);
  const [modalImage, setModalImage] = useState<{ url: string; title: string } | null>(null);

  // Sync hash routing if present (#story, #gallery, etc.)
  useEffect(() => {
    const handleHash = () => {
      const hash = window.location.hash.replace('#', '');
      const validSections: SectionKey[] = [
        'cover',
        'home',
        'story',
        'moments',
        'gallery',
        'event',
        'guide',
        'soundtrack',
        'wishing-well',
        'toasts',
        'rsvp',
      ];
      if (validSections.includes(hash as SectionKey)) {
        setActiveSection(hash as SectionKey);
      }
    };
    handleHash();
    window.addEventListener('hashchange', handleHash);
    return () => window.removeEventListener('hashchange', handleHash);
  }, []);

  const handleNavigate = (sectionKey: SectionKey) => {
    setActiveSection(sectionKey);
    setShowAllSections(false);
    window.location.hash = sectionKey === 'home' ? '' : sectionKey;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenSingleImage = (url: string, title: string) => {
    setModalImage({ url, title });
  };

  const handleCloseSingleImage = () => {
    setModalImage(null);
  };

  const sectionOrder: SectionKey[] = [
    'cover',
    'home',
    'story',
    'moments',
    'gallery',
    'event',
    'guide',
    'soundtrack',
    'wishing-well',
    'toasts',
    'rsvp',
  ];

  const currentIdx = sectionOrder.indexOf(activeSection);
  const nextSection = currentIdx < sectionOrder.length - 1 ? sectionOrder[currentIdx + 1] : null;
  const prevSection = currentIdx > 0 ? sectionOrder[currentIdx - 1] : null;

  const sectionLabels: Record<SectionKey, string> = {
    'cover': 'Invitation Cover',
    'home': 'Home',
    'story': 'Our Story & Journey',
    'moments': 'Moments We Keep',
    'gallery': 'Visual Poetry Gallery',
    'event': 'The Event & Schedule',
    'guide': 'A Weekend in Hudson Valley',
    'soundtrack': 'The Vinyl Soundtrack',
    'wishing-well': 'The Honeymoon Fund',
    'toasts': 'The Digital Toast Book',
    'rsvp': 'RSVP Celebration',
  };

  return (
    <div className="min-h-screen bg-[#F8F5F0] text-[#20201E] flex flex-col selection:bg-[#D8C5A5]/30">
      {/* Micro-Magnetic Luxury Bridal Pearl Cursor Follower */}
      <MagneticPearlCursor />

      {/* Global 3D Physics-based Drifting Rose Petals Engine */}
      <RosePetals3D count={40} />

      {/* Floating Ambient Acoustic Harp Serenade Player */}
      <AmbientSoundscape />

      {/* Sticky Top Navigation with Section Switcher */}
      <Navbar
        activeSection={activeSection}
        onNavigate={handleNavigate}
        showAllSections={showAllSections}
        onToggleShowAll={() => setShowAllSections(!showAllSections)}
      />

      <main className="flex-1">
        {/* VIEW MODE 1: Show All Sections Together (Full Feed Mode) */}
        {showAllSections ? (
          <div className="space-y-0">
            {/* Grand Opening Cover Section at top of full feed */}
            <CoverSection
              onEnterCelebration={() => {
                const hero = document.getElementById('hero');
                if (hero) hero.scrollIntoView({ behavior: 'smooth' });
              }}
              onOpenRsvp={() => handleNavigate('rsvp')}
            />

            <div className="py-4 px-6 bg-[#F2ECE4] border-b border-[#E5DFD5] text-center">
              <span className="text-xs uppercase tracking-[0.2em] text-[#8C867E]">
                Full Feed View • All Celebration Sections
              </span>
            </div>
            <Hero />
            <InvitationEnvelope onOpenRsvp={() => handleNavigate('rsvp')} />
            <EngagementIntro />
            <TheirStory onImageClick={handleOpenSingleImage} />
            <TheEngagement onImageClick={handleOpenSingleImage} />
            <Countdown />
            <PhotoGallery />
            <MomentsWeKeep onImageClick={handleOpenSingleImage} />
            <SoundtrackMixtape />
            <HudsonValleyGuide />
            <Families />
            <EventDetails />
            <DressCode />
            <GuestFaq />
            <WishingWell />
            <ToastBook />
            <RsvpSection />
            <LoveNote />
            <FinalPhoto />
          </div>
        ) : (
          /* VIEW MODE 2: Strict Section Isolation (Data is strictly in that section) */
          <>
            {/* If in a dedicated sub-section (not Home and not Cover), render editorial Breadcrumb Bar */}
            {activeSection !== 'home' && activeSection !== 'cover' && (
              <div className="pt-28 md:pt-32 pb-6 px-6 md:px-12 bg-[#F2ECE4] border-b border-[#E5DFD5]">
                <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => handleNavigate('home')}
                      className="inline-flex items-center gap-1.5 text-xs uppercase tracking-[0.18em] text-[#6F6A63] hover:text-[#20201E] transition-colors cursor-pointer"
                    >
                      <HomeIcon className="w-3.5 h-3.5" />
                      <span>Home</span>
                    </button>
                    <span className="text-[#D8C5A5]">•</span>
                    <span className="text-xs uppercase tracking-[0.18em] text-[#20201E] font-semibold">
                      {sectionLabels[activeSection]}
                    </span>
                  </div>

                  {/* Prev / Next Section Controls */}
                  <div className="flex items-center gap-4 text-xs tracking-wider uppercase text-[#6F6A63]">
                    {prevSection && (
                      <button
                        onClick={() => handleNavigate(prevSection)}
                        className="inline-flex items-center gap-1 hover:text-[#20201E] transition-colors cursor-pointer"
                      >
                        <ArrowLeft className="w-3 h-3" />
                        <span className="hidden sm:inline">{sectionLabels[prevSection]}</span>
                        <span className="sm:hidden">Prev</span>
                      </button>
                    )}
                    {nextSection && (
                      <button
                        onClick={() => handleNavigate(nextSection)}
                        className="inline-flex items-center gap-1 hover:text-[#20201E] transition-colors cursor-pointer"
                      >
                        <span className="hidden sm:inline">{sectionLabels[nextSection]}</span>
                        <span className="sm:hidden">Next</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* DEDICATED COVER SECTION (Pure full-screen experience matching user template) */}
            {activeSection === 'cover' && (
              <CoverSection
                onEnterCelebration={() => handleNavigate('home')}
                onOpenRsvp={() => handleNavigate('rsvp')}
              />
            )}

            {/* HOME SECTION */}
            {activeSection === 'home' && (
              <div className="space-y-0">
                {/* 1. Hero: Core announcement */}
                <Hero />
                {/* 2. Formal Stationery Envelope with 3D wax seal reveal */}
                <InvitationEnvelope onOpenRsvp={() => handleNavigate('rsvp')} />
                {/* 3. Introduction: Two Stories. One Beginning. */}
                <EngagementIntro />
                {/* 4. The Engagement: Visual centerpiece "WE SAID YES" */}
                <TheEngagement onImageClick={handleOpenSingleImage} />
                {/* 5. Live Countdown ticker */}
                <Countdown />
                {/* 6. Section Portals: Curated invitations into each dedicated chapter */}
                <SectionPortals onNavigate={handleNavigate} />
                {/* 7. Love Note: High-contrast warm charcoal atmospheric break */}
                <LoveNote />
                {/* 8. Final Photo: Sunset horizon */}
                <FinalPhoto />
              </div>
            )}

            {activeSection === 'story' && (
              <TheirStory onImageClick={handleOpenSingleImage} />
            )}

            {activeSection === 'moments' && (
              <MomentsWeKeep onImageClick={handleOpenSingleImage} />
            )}

            {activeSection === 'gallery' && (
              <PhotoGallery />
            )}

            {activeSection === 'event' && (
              <div className="space-y-0">
                <EventDetails />
                <DressCode />
                <GuestFaq />
                <Families />
              </div>
            )}

            {activeSection === 'guide' && (
              <HudsonValleyGuide />
            )}

            {activeSection === 'soundtrack' && (
              <SoundtrackMixtape />
            )}

            {activeSection === 'wishing-well' && (
              <WishingWell />
            )}

            {activeSection === 'toasts' && (
              <ToastBook />
            )}

            {activeSection === 'rsvp' && (
              <RsvpSection />
            )}
          </>
        )}
      </main>

      {/* Global Minimal Footer */}
      <Footer onNavigate={handleNavigate} />

      {/* Universal Single Image Modal for full-res photo popups */}
      <SingleImageModal
        isOpen={!!modalImage}
        imageUrl={modalImage ? modalImage.url : null}
        title={modalImage ? modalImage.title : null}
        onClose={handleCloseSingleImage}
      />
    </div>
  );
}

export default App;
