import React, { useEffect, useRef, useState } from 'react';

interface PetalParticle {
  x: number;
  y: number;
  z: number; // 3D depth distance
  vx: number;
  vy: number;
  vz: number;
  pitch: number;
  yaw: number;
  roll: number;
  vPitch: number;
  vYaw: number;
  vRoll: number;
  size: number;
  colorVariant: number;
  opacity: number;
}

interface RosePetals3DProps {
  className?: string;
  count?: number;
  interactive?: boolean;
}

export const RosePetals3D: React.FC<RosePetals3DProps> = ({
  className = '',
  count = 42,
  interactive = true,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mousePosRef = useRef({ x: -1000, y: -1000, vx: 0, vy: 0, lastX: 0, lastY: 0 });
  const [enabled, setEnabled] = useState(true);

  useEffect(() => {
    if (!enabled) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const onResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', onResize);

    // Track mouse velocity
    const onMouseMove = (e: MouseEvent) => {
      if (!interactive) return;
      const vx = e.clientX - mousePosRef.current.lastX;
      const vy = e.clientY - mousePosRef.current.lastY;
      mousePosRef.current = {
        x: e.clientX,
        y: e.clientY,
        vx: THREE_CLAMP(vx * 0.15, -12, 12),
        vy: THREE_CLAMP(vy * 0.15, -12, 12),
        lastX: e.clientX,
        lastY: e.clientY,
      };
    };
    window.addEventListener('mousemove', onMouseMove);

    function THREE_CLAMP(val: number, min: number, max: number) {
      return Math.max(min, Math.min(max, val));
    }

    // Initialize 3D Petals
    const petals: PetalParticle[] = [];
    for (let i = 0; i < count; i++) {
      petals.push({
        x: Math.random() * width,
        y: Math.random() * height,
        z: Math.random() * 400 - 150, // Depth from -150 (near) to 250 (far)
        vx: (Math.random() - 0.4) * 0.8,
        vy: 0.6 + Math.random() * 1.2, // Gentle downward gravity
        vz: (Math.random() - 0.5) * 0.3,
        pitch: Math.random() * Math.PI * 2,
        yaw: Math.random() * Math.PI * 2,
        roll: Math.random() * Math.PI * 2,
        vPitch: (Math.random() - 0.5) * 0.035,
        vYaw: (Math.random() - 0.5) * 0.025,
        vRoll: (Math.random() - 0.5) * 0.04,
        size: 14 + Math.random() * 14,
        colorVariant: Math.floor(Math.random() * 3),
        opacity: 0.75 + Math.random() * 0.25,
      });
    }

    // Color Gradients
    const petalColors = [
      { start: '#F5D3D5', mid: '#D9989B', end: '#B36D72' }, // Dusty rose
      { start: '#FCE7E8', mid: '#E5AAB0', end: '#C77D84' }, // Blush
      { start: '#ECD4D6', mid: '#C48A8E', end: '#9E5B63' }, // Velvet wine rose
    ];

    let animationFrameId: number;
    let time = 0;

    const render = () => {
      time += 0.016;
      ctx.clearRect(0, 0, width, height);

      // Decelerate mouse influence
      mousePosRef.current.vx *= 0.94;
      mousePosRef.current.vy *= 0.94;

      // Global harmonic breeze
      const breezeX = Math.sin(time * 0.8) * 0.75 + Math.cos(time * 0.3) * 0.3;

      // Sort petals by depth (Z-sorting for proper 3D occlusion)
      petals.sort((a, b) => b.z - a.z);

      for (let i = 0; i < petals.length; i++) {
        const p = petals[i];

        // 3D Perspective Projection
        const fov = 400;
        const scale = fov / (fov + p.z + 150); // Scale factor based on camera distance
        const screenX = p.x;
        const screenY = p.y;

        // Apply velocities & wind
        p.x += (p.vx + breezeX) * (1 / scale);
        p.y += p.vy * (1 / scale);
        p.z += p.vz;

        // 3D Rotations
        p.pitch += p.vPitch;
        p.yaw += p.vYaw;
        p.roll += p.vRoll;

        // Mouse Repulsion / Interactive Swirl
        const dx = p.x - mousePosRef.current.x;
        const dy = p.y - mousePosRef.current.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 140) {
          const force = (1 - dist / 140) * 4.5;
          p.x += (dx / dist) * force + mousePosRef.current.vx * 0.6;
          p.y += (dy / dist) * force + mousePosRef.current.vy * 0.6;
          p.vRoll += (Math.random() - 0.5) * 0.08;
          p.vPitch += (Math.random() - 0.5) * 0.08;
        }

        // Screen boundary wrap
        if (p.y > height + 40) {
          p.y = -30;
          p.x = Math.random() * width;
          p.z = Math.random() * 400 - 150;
        }
        if (p.x < -40) p.x = width + 30;
        if (p.x > width + 40) p.x = -30;
        if (p.z < -140) p.vz = Math.abs(p.vz);
        if (p.z > 280) p.vz = -Math.abs(p.vz);

        // Calculate 3D projected width & height from pitch & yaw
        const projWidth = Math.max(0.1, Math.cos(p.yaw)) * p.size * scale;
        const projHeight = Math.max(0.1, Math.cos(p.pitch)) * (p.size * 1.35) * scale;

        // Draw 3D Petal with realistic curvature
        ctx.save();
        ctx.translate(screenX, screenY);
        ctx.rotate(p.roll);

        // Depth of field blur for very close or very far petals
        const depthAlpha = p.z < -50 ? 0.95 : p.z > 150 ? 0.45 : 0.8;

        // Drop shadow simulating distance from surface
        ctx.shadowColor = 'rgba(185, 143, 145, 0.28)';
        ctx.shadowBlur = 8 * scale;
        ctx.shadowOffsetX = 3 * scale;
        ctx.shadowOffsetY = 4 * scale;

        ctx.beginPath();
        // Organic Rose Petal Shape
        const w = projWidth;
        const h = projHeight;
        ctx.moveTo(0, -h * 0.5);
        ctx.bezierCurveTo(w * 0.7, -h * 0.45, w * 0.85, h * 0.35, 0, h * 0.5);
        ctx.bezierCurveTo(-w * 0.85, h * 0.35, -w * 0.7, -h * 0.45, 0, -h * 0.5);
        ctx.closePath();

        // 3D Lighting & Gradient
        const gradient = ctx.createLinearGradient(0, -h * 0.5, 0, h * 0.5);
        const col = petalColors[p.colorVariant];
        gradient.addColorStop(0, col.start);
        gradient.addColorStop(0.65, col.mid);
        gradient.addColorStop(1, col.end);

        ctx.globalAlpha = p.opacity * depthAlpha;
        ctx.fillStyle = gradient;
        ctx.fill();

        // Subtle specular highlight spine
        ctx.beginPath();
        ctx.moveTo(0, -h * 0.35);
        ctx.quadraticCurveTo(w * 0.15, 0, 0, h * 0.35);
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
        ctx.lineWidth = 1 * scale;
        ctx.stroke();

        ctx.restore();
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', onResize);
      window.removeEventListener('mousemove', onMouseMove);
    };
  }, [enabled, count, interactive]);

  return (
    <>
      {enabled && (
        <canvas
          ref={canvasRef}
          className={`fixed inset-0 pointer-events-none z-30 ${className}`}
          style={{ mixBlendMode: 'normal' }}
          aria-hidden="true"
        />
      )}

      {/* Discreet Atmospheric Toggle */}
      <button
        onClick={() => setEnabled(!enabled)}
        className="fixed bottom-4 left-4 z-40 px-2.5 py-1 rounded-full bg-[#FAF8F5]/85 hover:bg-[#FAF8F5] text-[#20201E] border border-[#D8C5A5]/60 shadow-sm text-[10px] tracking-wider uppercase font-sans flex items-center gap-1.5 backdrop-blur-md transition-all cursor-pointer opacity-75 hover:opacity-100"
        title="Toggle 3D Rose Petals Atmosphere"
      >
        <span className={enabled ? 'text-[#B98F91] animate-pulse' : 'text-[#8C867E]'}>🌸</span>
        <span className="hidden sm:inline">3D Petals: {enabled ? 'On' : 'Off'}</span>
      </button>
    </>
  );
};
