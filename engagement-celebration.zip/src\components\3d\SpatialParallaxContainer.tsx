import React, { useState, useRef } from 'react';

interface SpatialParallaxContainerProps {
  children: React.ReactNode;
  className?: string;
  depthFactor?: number;
}

export const SpatialParallaxContainer: React.FC<SpatialParallaxContainerProps> = ({
  children,
  className = '',
  depthFactor = 1,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [offsets, setOffsets] = useState({ x: 0, y: 0, rotateX: 0, rotateY: 0 });

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const el = containerRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const normX = (e.clientX - centerX) / (rect.width / 2);
    const normY = (e.clientY - centerY) / (rect.height / 2);

    setOffsets({
      x: normX * 12 * depthFactor,
      y: normY * 12 * depthFactor,
      rotateX: -normY * 3 * depthFactor,
      rotateY: normX * 3 * depthFactor,
    });
  };

  const handleMouseLeave = () => {
    setOffsets({ x: 0, y: 0, rotateX: 0, rotateY: 0 });
  };

  return (
    <div
      ref={containerRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className={`relative ${className}`}
      style={{
        perspective: '1200px',
        transformStyle: 'preserve-3d',
      }}
    >
      <div
        className="transition-transform duration-300 ease-out"
        style={{
          transform: `rotateX(${offsets.rotateX}deg) rotateY(${offsets.rotateY}deg)`,
          transformStyle: 'preserve-3d',
        }}
      >
        {children}
      </div>
    </div>
  );
};
