export const FAMILIES_DATA = {
  heading: "With Love From Our Families",
  subheading: "United in joy and gratitude",
  quote: "“The love of a family is life’s greatest blessing. We are forever grateful for the foundation, warmth, and enduring grace our parents have given us every step of the way.”",
  brideParents: {
    title: "Parents of the Bride",
    names: "Mr. Arthur & Mrs. Evelyn Montgomery",
    note: "Hudson Valley, New York",
    imageUrl: "https://images.unsplash.com/photo-1543807535-eceef0bc6599?auto=format&fit=crop&w=1000&q=85",
    imageAlt: "Arthur and Evelyn Montgomery"
  },
  groomParents: {
    title: "Parents of the Groom",
    names: "Dr. Richard & Mrs. Eleanor Sterling",
    note: "Boston, Massachusetts",
    imageUrl: "https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&w=1000&q=85",
    imageAlt: "Richard and Eleanor Sterling"
  }
};
