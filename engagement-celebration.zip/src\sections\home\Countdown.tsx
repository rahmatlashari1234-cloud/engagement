import React, { useState, useEffect } from 'react';
import { HOME_DATE } from './homeData';
import { Calendar as CalendarIcon, Clock, Check } from 'lucide-react';

export const Countdown: React.FC = () => {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });
  const [copiedCalendar, setCopiedCalendar] = useState(false);

  useEffect(() => {
    const targetDate = new Date(HOME_DATE.isoDate).getTime();

    const calculateTime = () => {
      const now = new Date().getTime();
      const difference = targetDate - now;

      if (difference <= 0) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        return;
      }

      const days = Math.floor(difference / (1000 * 60 * 60 * 24));
      const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((difference % (1000 * 60)) / 1000);

      setTimeLeft({ days, hours, minutes, seconds });
    };

    calculateTime();
    const interval = setInterval(calculateTime, 1000);

    return () => clearInterval(interval);
  }, []);

  const downloadIcs = () => {
    const icsData = `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Amelia and Daniel Engagement//EN
CALSCALE:GREGORIAN
BEGIN:VEVENT
SUMMARY:Amelia & Daniel Engagement Celebration
DESCRIPTION:Together with their families, Amelia & Daniel are delighted to celebrate their engagement at The Glasshouse Conservatory.
LOCATION:The Glasshouse Conservatory, Stone Hill Estate, Hudson Valley, NY
DTSTART:20261114T220000Z
DTEND:20261115T043000Z
STATUS:CONFIRMED
END:VEVENT
END:VCALENDAR`;

    const blob = new Blob([icsData], { type: 'text/calendar;charset=utf-8' });
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.setAttribute('download', 'amelia-daniel-engagement.ics');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setCopiedCalendar(true);
    setTimeout(() => setCopiedCalendar(false), 3000);
  };

  const googleCalendarUrl = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(
    'Amelia & Daniel Engagement Celebration'
  )}&dates=20261114T220000Z/20261115T043000Z&details=${encodeURIComponent(
    'Together with their families, Amelia & Daniel are delighted to celebrate their engagement.'
  )}&location=${encodeURIComponent(
    'The Glasshouse Conservatory, 842 Hilltop Ridge Road, Hudson Valley, NY 12538'
  )}`;

  return (
    <section className="py-20 md:py-28 px-6 md:px-12 bg-[#F2ECE4] border-y border-[#E5DFD5]/80">
      <div className="max-w-4xl mx-auto text-center">
        {/* Section Label */}
        <div className="inline-flex items-center gap-2 mb-3">
          <Clock className="w-3.5 h-3.5 text-[#B98F91]" />
          <span className="text-[11px] uppercase tracking-[0.26em] text-[#6F6A63] font-semibold">
            Counting Down The Days
          </span>
        </div>

        <h3 className="font-serif text-3xl sm:text-4xl md:text-5xl text-[#20201E] font-normal tracking-tight mb-2">
          Until We Celebrate Together
        </h3>
        <p className="text-[#6F6A63] text-sm font-light mb-12">
          {HOME_DATE.display} • {HOME_DATE.time}
        </p>

        {/* Numbers Counter */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 sm:gap-8 max-w-2xl mx-auto mb-12">
          <div className="p-6 bg-[#F8F5F0] border border-[#E5DFD5] shadow-[0_4px_15px_rgba(32,32,30,0.02)]">
            <span className="font-serif text-4xl sm:text-5xl md:text-6xl text-[#20201E] font-light block leading-none mb-2">
              {String(timeLeft.days).padStart(2, '0')}
            </span>
            <span className="text-[10px] sm:text-[11px] uppercase tracking-[0.24em] text-[#8C867E] font-sans font-medium">
              Days
            </span>
          </div>

          <div className="p-6 bg-[#F8F5F0] border border-[#E5DFD5] shadow-[0_4px_15px_rgba(32,32,30,0.02)]">
            <span className="font-serif text-4xl sm:text-5xl md:text-6xl text-[#20201E] font-light block leading-none mb-2">
              {String(timeLeft.hours).padStart(2, '0')}
            </span>
            <span className="text-[10px] sm:text-[11px] uppercase tracking-[0.24em] text-[#8C867E] font-sans font-medium">
              Hours
            </span>
          </div>

          <div className="p-6 bg-[#F8F5F0] border border-[#E5DFD5] shadow-[0_4px_15px_rgba(32,32,30,0.02)]">
            <span className="font-serif text-4xl sm:text-5xl md:text-6xl text-[#20201E] font-light block leading-none mb-2">
              {String(timeLeft.minutes).padStart(2, '0')}
            </span>
            <span className="text-[10px] sm:text-[11px] uppercase tracking-[0.24em] text-[#8C867E] font-sans font-medium">
              Minutes
            </span>
          </div>

          <div className="p-6 bg-[#F8F5F0] border border-[#E5DFD5] shadow-[0_4px_15px_rgba(32,32,30,0.02)]">
            <span className="font-serif text-4xl sm:text-5xl md:text-6xl text-[#B98F91] font-light block leading-none mb-2">
              {String(timeLeft.seconds).padStart(2, '0')}
            </span>
            <span className="text-[10px] sm:text-[11px] uppercase tracking-[0.24em] text-[#8C867E] font-sans font-medium">
              Seconds
            </span>
          </div>
        </div>

        {/* Action: Add to Calendar */}
        <div className="flex flex-wrap items-center justify-center gap-4">
          <a
            href={googleCalendarUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#20201E] text-[#F8F5F0] text-xs uppercase tracking-[0.16em] font-medium hover:bg-[#3A3935] transition-colors"
          >
            <CalendarIcon className="w-3.5 h-3.5 text-[#D8C5A5]" />
            <span>Add to Google Calendar</span>
          </a>

          <button
            onClick={downloadIcs}
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#FAF8F5] border border-[#D8C5A5] text-[#20201E] text-xs uppercase tracking-[0.16em] font-medium hover:bg-[#F2ECE4] transition-colors cursor-pointer"
          >
            {copiedCalendar ? (
              <>
                <Check className="w-3.5 h-3.5 text-[#9BA595]" />
                <span>Downloaded (.ics)</span>
              </>
            ) : (
              <>
                <CalendarIcon className="w-3.5 h-3.5 text-[#8C867E]" />
                <span>Apple / Outlook (.ics)</span>
              </>
            )}
          </button>
        </div>
      </div>
    </section>
  );
};
