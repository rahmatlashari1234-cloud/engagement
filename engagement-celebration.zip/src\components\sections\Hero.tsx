import React from 'react';
import { ArrowDown } from 'lucide-react';
import { SITE_CONFIG } from '../../data/engagementContent';
import { OptimizedImage } from '../common/OptimizedImage';

export const Hero: React.FC = () => {
  const scrollToNext = () => {
    const nextSection = document.getElementById('introduction');
    if (nextSection) {
      nextSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="hero"
      className="relative min-h-screen flex flex-col justify-between pt-28 md:pt-36 pb-12 px-6 md:px-12 bg-[#F8F5F0] overflow-hidden"
    >
      {/* Editorial Content Header */}
      <div className="max-w-5xl mx-auto w-full text-center space-y-6 pt-4 md:pt-8 z-10">
        {/* Eyebrow Label */}
        <div className="inline-flex items-center gap-3">
          <span className="h-[1px] w-6 md:w-10 bg-[#B98F91]" />
          <span className="text-[11px] md:text-xs tracking-[0.28em] uppercase text-[#6F6A63] font-medium">
            {SITE_CONFIG.editorial.eyebrow}
          </span>
          <span className="h-[1px] w-6 md:w-10 bg-[#B98F91]" />
        </div>

        {/* Large Names Heading */}
        <h1 className="font-serif text-5xl sm:text-6xl md:text-8xl lg:text-9xl text-[#20201E] font-normal tracking-tight leading-[0.95]">
          <span>{SITE_CONFIG.couple.brideFirst}</span>
          <span className="mx-3 md:mx-6 font-serif italic text-[#B98F91] font-light">
            &
          </span>
          <span>{SITE_CONFIG.couple.groomFirst}</span>
        </h1>

        {/* Supporting Editorial Paragraph */}
        <p className="max-w-2xl mx-auto text-[#6F6A63] font-sans text-sm md:text-base leading-relaxed tracking-wide font-light">
          {SITE_CONFIG.editorial.heroSupporting}
        </p>

        {/* Date and Location Badge */}
        <div className="pt-2 flex flex-wrap items-center justify-center gap-2 md:gap-4 text-xs tracking-[0.16em] uppercase text-[#20201E] font-medium">
          <span>{SITE_CONFIG.celebrationDate.display}</span>
          <span className="text-[#D8C5A5] hidden sm:inline">•</span>
          <span className="text-[#6F6A63]">{SITE_CONFIG.venue.name}</span>
          <span className="text-[#D8C5A5] hidden md:inline">•</span>
          <span className="text-[#8C867E] hidden md:inline">Hudson Valley, NY</span>
        </div>
      </div>

      {/* Main Editorial Photograph Container */}
      <div className="max-w-6xl mx-auto w-full my-10 md:my-14 z-10">
        <div className="relative group overflow-hidden bg-[#EDE6DC] shadow-[0_20px_50px_rgba(32,32,30,0.06)] border border-[#E5DFD5]/60">
          <OptimizedImage
            src="https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=2200&q=85"
            alt="Amelia and Daniel editorial engagement portrait"
            priority={true}
            className="w-full h-[55vh] sm:h-[65vh] md:h-[72vh]"
            objectFit="cover"
            objectPosition="50% 30%"
          />
          {/* Subtle warm gradient overlay at the base for editorial mood */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#20201E]/40 via-transparent to-transparent pointer-events-none" />

          {/* Floating Subtle Editorial Caption */}
          <div className="absolute bottom-4 left-6 md:bottom-8 md:left-10 text-white/95 pointer-events-none">
            <span className="text-[10px] md:text-xs tracking-[0.24em] uppercase font-sans text-white/80 block mb-1">
              Photograph 01
            </span>
            <p className="font-serif italic text-lg md:text-2xl font-light drop-shadow-sm">
              The golden hour promise — Hudson Valley
            </p>
          </div>

          <div className="absolute bottom-4 right-6 md:bottom-8 md:right-10 text-white/80 text-[11px] tracking-widest uppercase font-sans hidden sm:block">
            {SITE_CONFIG.celebrationDate.engagementDate}
          </div>
        </div>
      </div>

      {/* Subtle Scroll Indicator */}
      <div className="text-center z-10 flex flex-col items-center">
        <button
          onClick={scrollToNext}
          className="group inline-flex flex-col items-center gap-2 text-[#8C867E] hover:text-[#20201E] transition-colors cursor-pointer"
          aria-label="Scroll to exploration"
        >
          <span className="text-[10px] tracking-[0.26em] uppercase font-sans">
            Scroll to Explore
          </span>
          <div className="w-[1px] h-8 bg-[#D8C5A5] relative overflow-hidden group-hover:h-10 transition-all duration-300">
            <div className="w-full h-3 bg-[#20201E] animate-bounce" />
          </div>
          <ArrowDown className="w-3.5 h-3.5 text-[#8C867E] group-hover:text-[#20201E] transition-transform group-hover:translate-y-0.5" />
        </button>
      </div>
    </section>
  );
};
