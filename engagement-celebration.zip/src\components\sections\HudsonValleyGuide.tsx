import React from 'react';
import { HUDSON_VALLEY_GUIDE } from '../../data/engagementContent';
import { OptimizedImage } from '../common/OptimizedImage';
import { Compass, MapPin } from 'lucide-react';

export const HudsonValleyGuide: React.FC = () => {
  return (
    <section className="py-24 md:py-36 px-6 md:px-12 bg-[#F8F5F0] border-t border-[#E5DFD5]/80">
      <div className="max-w-6xl mx-auto space-y-16 md:space-y-24">
        {/* Section Header */}
        <div className="text-center space-y-3 max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-2">
            <Compass className="w-3.5 h-3.5 text-[#B98F91]" />
            <span className="text-[11px] uppercase tracking-[0.28em] text-[#6F6A63] font-semibold">
              Travel & Leisure
            </span>
          </div>
          <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl text-[#20201E] font-normal tracking-tight">
            A Weekend in Hudson Valley
          </h2>
          <p className="text-sm md:text-base text-[#6F6A63] font-light leading-relaxed">
            For our traveling loved ones: a curated journal of our most cherished coffee houses, pastoral walks, and historic hearths across the valley.
          </p>
          <div className="w-12 h-[1px] bg-[#D8C5A5] mx-auto mt-4" />
        </div>

        {/* Asymmetrical 4-Card Editorial Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-start">
          {HUDSON_VALLEY_GUIDE.map((place, idx) => {
            const isOffset = idx % 2 === 1;

            return (
              <div
                key={place.id}
                className={`bg-[#FAF8F5] border border-[#E5DFD5] shadow-[0_8px_30px_rgba(32,32,30,0.03)] overflow-hidden transition-all duration-300 hover:border-[#D8C5A5] ${
                  isOffset ? 'md:mt-12' : ''
                }`}
              >
                {/* Photo with category badge */}
                <div className="relative overflow-hidden bg-[#EDE6DC]">
                  <OptimizedImage
                    src={place.imageUrl}
                    alt={place.name}
                    aspectRatio="16/10"
                    className="w-full"
                    objectFit="cover"
                  />
                  <div className="absolute top-4 left-4 bg-[#F8F5F0]/90 backdrop-blur-sm px-3 py-1 text-[10px] uppercase tracking-widest text-[#20201E] font-semibold border border-[#E5DFD5]">
                    {place.category}
                  </div>
                </div>

                {/* Content */}
                <div className="p-6 md:p-8 space-y-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5 text-xs text-[#8C867E]">
                      <MapPin className="w-3.5 h-3.5 text-[#B98F91]" />
                      <span>{place.town}</span>
                      <span>•</span>
                      <span className="font-light">{place.address}</span>
                    </div>

                    <h3 className="font-serif text-2xl md:text-3xl text-[#20201E] pt-1">
                      {place.name}
                    </h3>
                  </div>

                  <p className="text-xs sm:text-sm text-[#6F6A63] font-light leading-relaxed">
                    {place.note}
                  </p>

                  {/* Couple's Insider Tip */}
                  <div className="p-3.5 bg-[#F2ECE4] border-l-2 border-[#B98F91] text-xs text-[#20201E]">
                    <span className="font-semibold uppercase tracking-wider text-[10px] text-[#B98F91] block mb-0.5">
                      Our Insider Tip
                    </span>
                    <p className="font-light italic text-[#6F6A63]">
                      “{place.tip}”
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
