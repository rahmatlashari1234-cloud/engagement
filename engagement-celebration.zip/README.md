# Amelia & Daniel — High-End Engagement Celebration Website

A bespoke, editorial, modern engagement celebration website designed with the artistry of an experienced human creative director and frontend engineer.

---

## 🏛️ Section-Isolated Architecture & Modular Data Design

Each section is completely self-contained in its own folder under `src/sections/`. **All data related to a section is co-located exclusively inside that section's folder and nowhere else.**

The **Home section** is now a focused, high-end editorial portal that introduces the couple and celebration without dumping the full data of every section into one continuous page.

```text
src/sections/
├── home/                # Home Portal (Hero, Wax Seal Invitation, Intro, Proposal, Countdown, Chapters Index, Love Note)
│   ├── homeData.ts      # Core couple names, date, and portal gateways ONLY
│   ├── Hero.tsx
│   ├── InvitationEnvelope.tsx
│   ├── EngagementIntro.tsx
│   ├── TheEngagement.tsx
│   ├── Countdown.tsx
│   ├── SectionPortals.tsx
│   ├── LoveNote.tsx
│   └── FinalPhoto.tsx
│
├── story/               # Our Story & Journey Section
│   ├── storyData.ts     # Milestones, timeline dates, and story photography ONLY
│   └── TheirStory.tsx
│
├── gallery/             # Visual Poetry Gallery Section
│   ├── galleryData.ts   # 12 high-res photos, categories, aspects, captions ONLY
│   └── PhotoGallery.tsx
│
├── moments/             # Moments We Keep Section
│   ├── momentsData.ts   # 5 intimate memories, quotes, and layouts ONLY
│   └── MomentsWeKeep.tsx
│
├── event/               # The Event & Logistics Section
│   ├── eventData.ts     # Schedule, venue address, valet, dress code palette ONLY
│   ├── EventDetails.tsx
│   └── DressCode.tsx
│
├── guide/               # A Weekend in Hudson Valley Section
│   ├── guideData.ts     # 4 local café, trail, antique, and fireside tavern spots ONLY
│   └── HudsonValleyGuide.tsx
│
├── soundtrack/          # The Celebration Soundtrack Section
│   ├── soundtrackData.ts# Vinyl mixtape tracks, artists, notes, and durations ONLY
│   └── SoundtrackMixtape.tsx
│
├── wishingWell/         # The Honeymoon Fund & Wishing Well Section
│   ├── wishingWellData.ts# Experiential honeymoon gifts and details ONLY
│   └── WishingWell.tsx
│
├── toastBook/           # The Digital Toast Book Section
│   ├── toastData.ts     # Initial guest toasts and relations ONLY
│   └── ToastBook.tsx
│
├── faq/                 # Guest Inquiries & FAQ Section
│   ├── faqData.ts       # 6 guest Q&As and coordinator contact ONLY
│   └── GuestFaq.tsx
│
├── families/            # Heritage & Families Section
│   ├── familiesData.ts  # Parents portraits and tribute ONLY
│   └── Families.tsx
│
└── rsvp/                # RSVP Section
    ├── rsvpData.ts      # Dietary options, deadline, email ONLY
    └── RsvpSection.tsx
```

---

## 🎯 Navigation & View Modes

1. **Dedicated Section Mode (Default)**:
   - When you are on **Home**, only the Home experience and Section Portals are displayed.
   - Clicking **Our Story**, **Gallery**, **The Event**, **Guide**, **Soundtrack**, **Wishing Well**, **Toasts**, or **RSVP** in the navigation opens that section exclusively.
   - An editorial breadcrumb bar appears at the top of every section with `← Return to Home` and `Prev / Next Section` buttons.
2. **Full Feed Mode (Optional Toggle)**:
   - Clicking the **"Sections / Full Feed"** toggle button in the navbar or mobile menu allows guests to view all sections continuously if preferred.
3. **Deep Linking**:
   - URL hash anchors (`#story`, `#gallery`, `#event`, `#guide`, `#soundtrack`, `#wishing-well`, `#toasts`, `#rsvp`) are fully supported.

---

## 🚀 Running Locally

```bash
cd engagement-celebration
npm run dev      # Start Vite development server
npm run build    # Build production bundle to /dist
npm run preview  # Serve production preview locally
```
Preview is running live at **http://localhost:5173/**.
