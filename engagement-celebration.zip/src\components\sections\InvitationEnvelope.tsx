import React, { useState } from 'react';
import { SITE_CONFIG } from '../../data/engagementContent';
import { MonogramCrest } from '../common/MonogramCrest';
import { Sparkles, Heart, MailOpen } from 'lucide-react';

export const InvitationEnvelope: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  const handleToggle = () => {
    setIsOpen(!isOpen);
  };

  return (
    <section className="py-20 md:py-28 px-6 md:px-12 bg-[#F2ECE4] border-t border-[#E5DFD5] relative overflow-hidden">
      <div className="max-w-4xl mx-auto">
        {/* Section Header */}
        <div className="text-center space-y-3 mb-12">
          <div className="inline-flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-[#B98F91]" />
            <span className="text-[11px] uppercase tracking-[0.28em] text-[#6F6A63] font-semibold">
              Formal Stationery Suite
            </span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl text-[#20201E] font-normal tracking-tight">
            The Formal Invitation
          </h2>
          <p className="text-xs sm:text-sm text-[#6F6A63] font-light max-w-md mx-auto">
            Click the handcrafted wax seal to open the letterpress keepsake.
          </p>
        </div>

        {/* Envelope / Letterpress Container */}
        <div className="relative max-w-2xl mx-auto">
          {!isOpen ? (
            /* CLOSED ENVELOPE STATE */
            <div
              onClick={handleToggle}
              className="cursor-pointer group relative bg-[#FAF8F5] border border-[#E5DFD5] p-8 sm:p-14 shadow-[0_15px_40px_rgba(32,32,30,0.06)] transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_20px_50px_rgba(32,32,30,0.1)] flex flex-col items-center text-center"
            >
              {/* Envelope Flap Triangle Line SVG */}
              <div className="absolute top-0 left-0 right-0 h-16 pointer-events-none opacity-20">
                <svg viewBox="0 0 100 20" preserveAspectRatio="none" className="w-full h-full fill-none stroke-[#20201E]" strokeWidth="0.5">
                  <path d="M 0 0 L 50 20 L 100 0" />
                </svg>
              </div>

              {/* Monogram Crest Header */}
              <MonogramCrest size="sm" variant="gold" className="mb-4" />

              <span className="text-[11px] uppercase tracking-[0.26em] text-[#8C867E] mb-2 font-sans">
                Cordially Invited
              </span>
              <p className="font-serif italic text-2xl sm:text-3xl text-[#20201E] font-light mb-8">
                To Celebrate the Engagement of <br />
                <span className="not-italic font-normal">Amelia & Daniel</span>
              </p>

              {/* 3D Wax Seal Stamp */}
              <div className="relative group/seal my-2">
                <div className="w-16 h-16 rounded-full wax-seal flex items-center justify-center cursor-pointer transition-transform duration-300 group-hover/seal:scale-110 shadow-lg">
                  <span className="font-serif italic text-white text-lg font-semibold tracking-wider drop-shadow-sm">
                    A&D
                  </span>
                </div>
                <div className="absolute -bottom-7 left-1/2 -translate-x-1/2 whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity text-[10px] uppercase tracking-widest text-[#B98F91] font-semibold">
                  Tap to Unfold
                </div>
              </div>

              <div className="mt-10 text-[11px] uppercase tracking-[0.2em] text-[#8C867E]">
                Stone Hill Estate • Hudson Valley
              </div>
            </div>
          ) : (
            /* UNFOLDED FORMAL LETTERPRESS CARD */
            <div className="relative bg-[#FFFDF9] border border-[#D8C5A5] p-8 sm:p-14 md:p-16 shadow-[0_20px_60px_rgba(32,32,30,0.12)] text-center animate-fade-in space-y-6">
              {/* Top Controls to Re-fold */}
              <div className="absolute top-4 right-4">
                <button
                  onClick={handleToggle}
                  className="text-[10px] uppercase tracking-wider text-[#8C867E] hover:text-[#20201E] border border-[#E5DFD5] px-2.5 py-1 transition-colors"
                >
                  Fold Card
                </button>
              </div>

              {/* Foil Botanical Crest */}
              <MonogramCrest size="md" variant="gold" className="mx-auto" />

              <div className="space-y-2">
                <span className="text-[11px] uppercase tracking-[0.28em] text-[#8C867E] block font-medium">
                  Together With Their Families
                </span>
                <h3 className="font-serif text-3xl sm:text-5xl text-[#20201E] font-normal tracking-tight py-2">
                  Amelia Montgomery <br />
                  <span className="italic font-serif text-[#B98F91] text-2xl sm:text-3xl">&</span> <br />
                  Daniel Sterling
                </h3>
                <p className="text-xs sm:text-sm text-[#6F6A63] tracking-wide font-light max-w-md mx-auto pt-1">
                  request the pleasure of your company to celebrate their engagement
                </p>
              </div>

              <div className="w-16 h-[1px] bg-[#D8C5A5] mx-auto my-4" />

              {/* Ceremony & Reception Coordinates */}
              <div className="space-y-1 font-serif text-lg sm:text-xl text-[#20201E]">
                <p className="font-medium tracking-wide">
                  {SITE_CONFIG.celebrationDate.display}
                </p>
                <p className="text-sm font-sans uppercase tracking-[0.18em] text-[#8C867E]">
                  at five o’clock in the evening
                </p>
              </div>

              <div className="text-sm text-[#6F6A63] font-light space-y-0.5 pt-1">
                <p className="font-serif italic text-base text-[#20201E]">
                  {SITE_CONFIG.venue.name}
                </p>
                <p>{SITE_CONFIG.venue.estate}</p>
                <p className="text-xs text-[#8C867E]">{SITE_CONFIG.venue.address}, {SITE_CONFIG.venue.cityStateZip}</p>
              </div>

              <div className="pt-4 flex flex-wrap items-center justify-center gap-4">
                <a
                  href="#rsvp"
                  className="px-6 py-2.5 bg-[#20201E] text-[#F8F5F0] text-xs uppercase tracking-[0.2em] font-medium hover:bg-[#3A3935] transition-colors inline-flex items-center gap-2"
                >
                  <span>Accept With Joy (RSVP)</span>
                  <Heart className="w-3.5 h-3.5 text-[#B98F91] fill-[#B98F91]" />
                </a>

                <button
                  onClick={handleToggle}
                  className="px-4 py-2.5 border border-[#D8C5A5] text-[#20201E] text-xs uppercase tracking-[0.16em] font-medium hover:bg-[#F2ECE4] transition-colors inline-flex items-center gap-1.5"
                >
                  <MailOpen className="w-3.5 h-3.5 text-[#8C867E]" />
                  <span>Close Stationery</span>
                </button>
              </div>

              <p className="text-[10px] uppercase tracking-widest text-[#8C867E] pt-2">
                Kindly respond by {SITE_CONFIG.celebrationDate.rsvpDeadline} • Formal Cocktail Attire
              </p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
