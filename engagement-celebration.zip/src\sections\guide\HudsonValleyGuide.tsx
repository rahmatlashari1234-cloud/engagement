import React, { useState } from 'react';
import { HUDSON_VALLEY_GUIDE, GUIDE_META } from './guideData';
import { OptimizedImage } from '../../components/common/OptimizedImage';
import { Compass, RotateCw, MapPin, Stamp } from 'lucide-react';
import { BotanicalVine, RosePetal, PhotoFloralFlourish } from '../../components/common/FloralDecorations';

export const HudsonValleyGuide: React.FC = () => {
  const [flippedCards, setFlippedCards] = useState<Record<string, boolean>>({});

  const toggleFlip = (id: string) => {
    setFlippedCards((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  return (
    <section id="guide" className="py-24 md:py-36 px-6 md:px-12 bg-[#F8F5F0] border-t border-[#E5DFD5]/80 animate-fade-in select-none relative overflow-hidden">
      {/* Botanical Corner Vines & Drifting Petals */}
      <BotanicalVine position="top-left" size="lg" opacity={0.65} />
      <BotanicalVine position="top-right" size="lg" opacity={0.6} />
      <BotanicalVine position="bottom-left" size="md" opacity={0.5} />
      <BotanicalVine position="bottom-right" size="md" opacity={0.5} />

      <div className="absolute top-36 left-8 pointer-events-none">
        <RosePetal variant={1} rotate={-15} scale={1} />
      </div>
      <div className="absolute top-52 right-12 pointer-events-none">
        <RosePetal variant={2} rotate={35} scale={0.9} />
      </div>
      <div className="absolute bottom-36 left-10 pointer-events-none">
        <RosePetal variant={3} rotate={15} scale={0.85} />
      </div>
      <div className="absolute bottom-24 right-14 pointer-events-none">
        <RosePetal variant={1} rotate={-30} scale={0.9} />
      </div>
      <div className="max-w-6xl mx-auto space-y-16 md:space-y-24">
        {/* Section Header */}
        <div className="text-center space-y-3 max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-2">
            <Compass className="w-3.5 h-3.5 text-[#B98F91]" />
            <span className="text-[11px] uppercase tracking-[0.28em] text-[#6F6A63] font-semibold">
              3D Interactive Keepsake Cards
            </span>
          </div>
          <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl text-[#20201E] font-normal tracking-tight">
            {GUIDE_META.heading}
          </h2>
          <p className="text-sm md:text-base text-[#6F6A63] font-light leading-relaxed">
            Click any postcard to flip it over in 3D and read our personal handwritten notes, secret orders, and travel tips.
          </p>
          <div className="w-12 h-[1px] bg-[#D8C5A5] mx-auto mt-4" />
        </div>

        {/* 3D Flip Postcard Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-start">
          {HUDSON_VALLEY_GUIDE.map((place, idx) => {
            const isFlipped = !!flippedCards[place.id];
            const isOffset = idx % 2 === 1;

            return (
              <div
                key={place.id}
                className={`perspective-1000 ${isOffset ? 'md:mt-8' : ''}`}
              >
                <div
                  onClick={() => toggleFlip(place.id)}
                  className="w-full relative cursor-pointer min-h-[460px] sm:min-h-[480px] transition-transform duration-700"
                  style={{
                    transformStyle: 'preserve-3d',
                    transform: isFlipped ? 'rotateY(180deg)' : 'rotateY(0deg)',
                  }}
                >
                  {/* FRONT SIDE OF POSTCARD */}
                  <div
                    className="absolute inset-0 bg-[#FAF8F5] border border-[#E5DFD5] shadow-[0_12px_35px_rgba(32,32,30,0.05)] overflow-hidden flex flex-col justify-between p-4 backface-hidden group hover:border-[#D8C5A5] transition-colors"
                  >
                    <div>
                      {/* Photo with frame & editorial animations */}
                      <div className="relative overflow-hidden bg-[#EDE6DC] aspect-[16/10]">
                        <PhotoFloralFlourish position="top-right" className="opacity-80 z-20" />
                        <OptimizedImage
                          src={place.imageUrl}
                          alt={place.name}
                          animation="zoom-hover"
                          cornerAccents={true}
                          curtainReveal={true}
                          className="w-full h-full"
                          objectFit="cover"
                        />
                        <div className="absolute top-3 left-3 bg-[#F8F5F0]/90 backdrop-blur-sm px-2.5 py-0.5 text-[9px] uppercase tracking-widest text-[#20201E] font-semibold border border-[#E5DFD5]">
                          {place.category}
                        </div>
                      </div>

                      <div className="pt-5 px-2 space-y-2">
                        <div className="flex items-center gap-1.5 text-xs text-[#8C867E]">
                          <MapPin className="w-3.5 h-3.5 text-[#B98F91]" />
                          <span>{place.town}</span>
                          <span>•</span>
                          <span className="font-light">{place.address}</span>
                        </div>

                        <h3 className="font-serif text-2xl md:text-3xl text-[#20201E]">
                          {place.name}
                        </h3>

                        <p className="text-xs sm:text-sm text-[#6F6A63] font-light leading-relaxed line-clamp-2">
                          {place.note}
                        </p>
                      </div>
                    </div>

                    {/* Flip Trigger Cue */}
                    <div className="pt-4 px-2 border-t border-[#E5DFD5]/60 flex items-center justify-between text-xs text-[#8C867E]">
                      <span className="font-serif italic text-sm text-[#B98F91]">
                        Postcard No. 0{idx + 1}
                      </span>
                      <span className="inline-flex items-center gap-1 uppercase tracking-widest text-[10px] text-[#20201E] font-medium group-hover:text-[#B98F91] transition-colors">
                        <span>Flip Postcard</span>
                        <RotateCw className="w-3 h-3 group-hover:rotate-180 transition-transform duration-500" />
                      </span>
                    </div>
                  </div>

                  {/* BACK SIDE OF POSTCARD (3D Flipped) */}
                  <div
                    className="absolute inset-0 bg-[#F4EFE6] border-2 border-[#D8C5A5] shadow-[0_15px_40px_rgba(32,32,30,0.08)] p-6 sm:p-8 flex flex-col justify-between rotate-y-180 backface-hidden"
                  >
                    {/* Postcard Header & Postage Stamp */}
                    <div className="flex items-start justify-between border-b border-[#D8C5A5] pb-4">
                      <div>
                        <span className="font-serif italic text-2xl text-[#20201E] block leading-none">
                          Postale
                        </span>
                        <span className="text-[9px] uppercase tracking-[0.24em] text-[#8C867E] font-mono">
                          Hudson Valley Gazette • 2026
                        </span>
                      </div>

                      {/* Vintage Postal Stamp Graphic */}
                      <div className="relative">
                        <div className="w-14 h-16 bg-[#F8F5F0] border-2 border-dashed border-[#B98F91] p-1 flex flex-col items-center justify-center text-center shadow-sm">
                          <Stamp className="w-4 h-4 text-[#B98F91] mb-1" />
                          <span className="text-[7px] uppercase tracking-widest text-[#20201E] font-mono leading-none">
                            HV AIR MAIL
                          </span>
                          <span className="text-[7px] text-[#B98F91] font-mono">2026</span>
                        </div>
                        {/* Circular Postmark Cancellation Seal */}
                        <div className="absolute -left-4 top-2 w-12 h-12 rounded-full border border-[#20201E]/40 pointer-events-none flex items-center justify-center -rotate-12">
                          <span className="text-[6px] uppercase tracking-tighter text-[#20201E]/60 text-center font-mono leading-none">
                            STONE HILL<br />NOV 14
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Split Layout: Handwritten Message & Address Lines */}
                    <div className="grid grid-cols-1 sm:grid-cols-12 gap-6 my-auto pt-4">
                      {/* Left: Couple's Handwritten Note */}
                      <div className="sm:col-span-7 space-y-3">
                        <span className="text-[10px] uppercase tracking-widest text-[#B98F91] font-semibold block">
                          Our Personal Memory
                        </span>
                        <p className="font-serif italic text-base sm:text-lg text-[#20201E] leading-relaxed">
                          “{place.note}”
                        </p>
                        <div className="p-3 bg-[#FAF8F5] border-l-2 border-[#B98F91] text-xs">
                          <strong className="block text-[10px] uppercase text-[#B98F91] font-sans">
                            Insider Recommendation
                          </strong>
                          <p className="text-[#6F6A63] font-light mt-0.5">
                            {place.tip}
                          </p>
                        </div>
                      </div>

                      {/* Right: Traditional Postcard Address Lines */}
                      <div className="sm:col-span-5 border-t sm:border-t-0 sm:border-l border-[#D8C5A5] pt-4 sm:pt-0 sm:pl-5 space-y-4 flex flex-col justify-center">
                        <div className="border-b border-[#D8C5A5] pb-1">
                          <span className="text-[9px] uppercase tracking-widest text-[#8C867E] block">To:</span>
                          <span className="font-serif text-sm text-[#20201E]">Our Cherished Guests</span>
                        </div>
                        <div className="border-b border-[#D8C5A5] pb-1">
                          <span className="text-[9px] uppercase tracking-widest text-[#8C867E] block">Location:</span>
                          <span className="text-xs text-[#20201E] font-light">{place.address}</span>
                        </div>
                        <div className="border-b border-[#D8C5A5] pb-1">
                          <span className="text-[9px] uppercase tracking-widest text-[#8C867E] block">Signed:</span>
                          <span className="font-serif italic text-sm text-[#B98F91]">Amelia & Daniel</span>
                        </div>
                      </div>
                    </div>

                    {/* Flip Back Cue */}
                    <div className="pt-3 border-t border-[#D8C5A5] flex items-center justify-between text-xs text-[#8C867E]">
                      <span className="text-[10px] uppercase tracking-widest">
                        {place.town}
                      </span>
                      <span className="inline-flex items-center gap-1 uppercase tracking-widest text-[10px] text-[#20201E] font-medium hover:text-[#B98F91] transition-colors">
                        <span>Flip Back</span>
                        <RotateCw className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
