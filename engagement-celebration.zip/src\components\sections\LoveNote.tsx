import React from 'react';
import { SITE_CONFIG } from '../../data/engagementContent';
import { Sparkles } from 'lucide-react';

export const LoveNote: React.FC = () => {
  const { loveNote } = SITE_CONFIG.editorial;

  return (
    <section className="py-24 md:py-36 px-6 md:px-12 bg-[#1F1E1C] text-[#F8F5F0] relative overflow-hidden">
      {/* Subtle background ambient light */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#B98F91]/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-4xl mx-auto text-center relative z-10 space-y-10">
        {/* Subtle Accent Glyphs */}
        <div className="inline-flex items-center gap-3 text-[#D8C5A5]">
          <span className="w-8 h-[1px] bg-[#D8C5A5]/30" />
          <Sparkles className="w-3.5 h-3.5" />
          <span className="w-8 h-[1px] bg-[#D8C5A5]/30" />
        </div>

        {/* Section Heading */}
        <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl text-[#FAF8F5] font-normal tracking-tight">
          {loveNote.heading}
        </h2>

        {/* Heartfelt Letter Copy */}
        <div className="space-y-6 text-[#D8CFBF] text-base sm:text-lg md:text-xl font-light leading-relaxed max-w-2xl mx-auto">
          <p>
            {loveNote.paragraph1}
          </p>
          <p>
            {loveNote.paragraph2}
          </p>
        </div>

        {/* Signatures & Monogram */}
        <div className="pt-8 space-y-3">
          <span className="text-xs uppercase tracking-[0.26em] text-[#D8C5A5] block">
            {loveNote.signoff}
          </span>
          <p className="font-serif italic text-3xl sm:text-4xl text-[#FAF8F5]">
            {loveNote.coupleSignatures}
          </p>
        </div>
      </div>
    </section>
  );
};
