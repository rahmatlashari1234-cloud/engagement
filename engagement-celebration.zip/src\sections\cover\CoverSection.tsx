import React, { useState, useEffect, useRef } from 'react';
import { COVER_DEFAULT_DATA } from './coverData';
import { Heart, Sparkles, ArrowDown, Volume2, VolumeX, Edit3, Check } from 'lucide-react';
import { BotanicalVine, RosePetal, PhotoFloralFlourish } from '../../components/common/FloralDecorations';
import { GoldFoilGlare } from '../../components/3d/GoldFoilGlare';
import { CalligraphyFlourish } from '../../components/animations/CalligraphyFlourish';

interface CoverSectionProps {
  onEnterCelebration: () => void;
  onOpenRsvp?: () => void;
}

interface Particle {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  rotation: number;
  vRot: number;
  opacity: number;
}

export const CoverSection: React.FC<CoverSectionProps> = ({
  onEnterCelebration,
  onOpenRsvp,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [recipientName, setRecipientName] = useState(COVER_DEFAULT_DATA.recipient);
  const [isEditingName, setIsEditingName] = useState(false);
  const [tempName, setTempName] = useState(COVER_DEFAULT_DATA.recipient);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [particles, setParticles] = useState<Particle[]>([]);
  const [isSquishing, setIsSquishing] = useState(false);

  const audioCtxRef = useRef<AudioContext | null>(null);

  // Play a soft luxury chime / harp pluck on opening
  const playOpenChime = () => {
    if (!soundEnabled) return;
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!audioCtxRef.current) {
        audioCtxRef.current = new AudioCtx();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }

      // Elegant pentatonic chord arpeggio (C5, E5, G5, B5, C6)
      const freqs = [523.25, 659.25, 783.99, 987.77, 1046.5];
      freqs.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.08);

        gain.gain.setValueAtTime(0, ctx.currentTime + idx * 0.08);
        gain.gain.linearRampToValueAtTime(0.12, ctx.currentTime + idx * 0.08 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + idx * 0.08 + 1.2);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(ctx.currentTime + idx * 0.08);
        osc.stop(ctx.currentTime + idx * 0.08 + 1.3);
      });
    } catch {
      // Audio autoplay policy fallback
    }
  };

  // Sparkle Confetti Burst using the website's exact Champagne, Rose, and Ivory colors
  const triggerSparkles = () => {
    const newParticles: Particle[] = [];
    const colors = ['#D8C5A5', '#B98F91', '#F8F5F0', '#FAF8F5', '#E5DFD5'];

    for (let i = 0; i < 38; i++) {
      const angle = (Math.PI * 2 * i) / 38 + (Math.random() - 0.5) * 0.5;
      const speed = 2.2 + Math.random() * 5.0;
      newParticles.push({
        id: Math.random(),
        x: 50,
        y: 48,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 1.2,
        size: Math.random() * 7 + 4,
        color: colors[Math.floor(Math.random() * colors.length)],
        rotation: Math.random() * 360,
        vRot: (Math.random() - 0.5) * 10,
        opacity: 1,
      });
    }

    setParticles(newParticles);
  };

  // Particle Physics Tick
  useEffect(() => {
    if (particles.length === 0) return;
    const interval = setInterval(() => {
      setParticles((prev) =>
        prev
          .map((p) => ({
            ...p,
            x: p.x + p.vx * 0.25,
            y: p.y + p.vy * 0.25,
            vy: p.vy + 0.12, // gravity
            rotation: p.rotation + p.vRot,
            opacity: p.opacity - 0.022,
          }))
          .filter((p) => p.opacity > 0)
      );
    }, 24);

    return () => clearInterval(interval);
  }, [particles]);

  const handleToggleOpen = () => {
    setIsSquishing(true);
    setTimeout(() => setIsSquishing(false), 550);
    if (!isOpen) {
      playOpenChime();
      triggerSparkles();
      setIsOpen(true);
    } else {
      setIsOpen(false);
    }
  };

  const handleSaveName = (e: React.FormEvent) => {
    e.preventDefault();
    if (tempName.trim()) {
      setRecipientName(tempName.trim());
    }
    setIsEditingName(false);
  };

  return (
    <section
      id="cover-section"
      className="relative min-h-screen w-full flex flex-col items-center justify-between pt-28 sm:pt-32 pb-10 md:pb-14 px-4 sm:px-6 select-none overflow-hidden cover-luxury-bg text-[#F8F5F0]"
    >
      {/* Botanical Floral Corner Vines & Falling Petals */}
      <BotanicalVine position="top-left" size="md" opacity={0.45} />
      <BotanicalVine position="top-right" size="md" opacity={0.45} />
      <BotanicalVine position="bottom-left" size="sm" opacity={0.35} />
      <BotanicalVine position="bottom-right" size="sm" opacity={0.35} />

      {/* Floating subtle rose petals */}
      <div className="absolute top-32 left-8 sm:left-14 pointer-events-none">
        <RosePetal variant={1} rotate={-20} scale={0.9} />
      </div>
      <div className="absolute top-44 right-10 sm:right-16 pointer-events-none">
        <RosePetal variant={2} rotate={35} scale={0.85} />
      </div>
      <div className="absolute bottom-32 left-10 pointer-events-none">
        <RosePetal variant={3} rotate={15} scale={0.8} />
      </div>
      <div className="absolute bottom-28 right-12 pointer-events-none">
        <RosePetal variant={1} rotate={-35} scale={0.85} />
      </div>

      {/* Subtle Warm Atmospheric Candlelight Glow */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-1/3 left-1/4 w-80 h-80 rounded-full bg-[#B98F91]/12 blur-3xl" />
        <div className="absolute bottom-1/3 right-1/4 w-80 h-80 rounded-full bg-[#D8C5A5]/12 blur-3xl" />
      </div>

      {/* Streamlined Minimalist Header (Clear of the fixed menu) */}
      <div className="w-full max-w-5xl mx-auto flex items-center justify-between z-20 pt-2">
        {/* Subtle Luxury Eyebrow */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/8 backdrop-blur-md border border-[#D8C5A5]/30 text-[10px] tracking-[0.24em] uppercase font-sans text-[#D8C5A5]">
          <Sparkles className="w-3 h-3 text-[#D8C5A5]" />
          <span>A Private Celebration Invitation</span>
        </div>

        {/* Audio Mute/Unmute */}
        <button
          onClick={() => setSoundEnabled(!soundEnabled)}
          className="p-2 rounded-full bg-white/8 hover:bg-white/16 border border-[#D8C5A5]/25 backdrop-blur-md transition-colors text-[#D8C5A5] cursor-pointer"
          title={soundEnabled ? 'Mute Chimes' : 'Enable Chimes'}
          aria-label="Toggle Audio Chimes"
        >
          {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
        </button>
      </div>

      {/* CENTERPIECE: The 3D Origami Envelope (Adjusted translation to preserve menu clearance) */}
      <div
        className={`my-auto w-full max-w-2xl py-4 sm:py-6 flex flex-col items-center justify-center z-10 transition-transform duration-700 ease-out ${
          isOpen ? 'translate-y-14 sm:translate-y-18' : 'translate-y-0'
        }`}
      >
        <div className="relative w-full max-w-[540px] aspect-[16/11] sm:aspect-[16/10.5] perspective-1200">
          {/* The Outer Envelope Box in Warm Linen & Cream */}
          <div
            className="relative w-full h-full rounded-2xl sm:rounded-3xl border-2 border-[#D8C5A5]/80 shadow-[0_25px_60px_rgba(0,0,0,0.55)] cover-envelope-palette overflow-visible transition-all duration-700"
            style={{ transformStyle: 'preserve-3d' }}
          >
            {/* INSET INNER LETTER / INVITATION CARD (Elevates completely in front of envelope flaps) */}
            <div
              className={`absolute inset-x-2 sm:inset-x-4 top-2 bg-[#FAF8F5] border border-[#D8C5A5] shadow-2xl p-4 sm:p-6 flex flex-col justify-between transition-all duration-700 ease-out text-[#20201E] rounded-lg max-h-[88vh] overflow-y-auto ${
                isOpen
                  ? '-translate-y-[52%] sm:-translate-y-[50%] opacity-100 z-40 shadow-[0_25px_50px_rgba(0,0,0,0.38)] pointer-events-auto'
                  : 'translate-y-2 opacity-0 pointer-events-none z-10'
              }`}
            >
              <GoldFoilGlare className="w-full h-full flex flex-col justify-between" intensity={1.1}>
                {/* Foil Stamped Border */}
                <div className="absolute inset-2 border border-[#D8C5A5]/60 pointer-events-none" />

                <div className="space-y-3 relative z-10">
                  <div className="flex items-center justify-between border-b border-[#E5DFD5] pb-2">
                    <span className="font-script text-2xl sm:text-3xl text-[#B98F91]">
                      To My Dearest {recipientName},
                    </span>
                    <span className="text-[9px] uppercase tracking-widest text-[#8C867E] font-mono">
                      Save The Date
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
                    <div className="sm:col-span-8 space-y-2">
                      <p className="font-serif italic text-xs sm:text-sm text-[#20201E] leading-relaxed">
                        “{COVER_DEFAULT_DATA.letter.bodyParagraph1}”
                      </p>
                      <p className="text-xs text-[#6F6A63] font-light leading-relaxed hidden sm:block">
                        {COVER_DEFAULT_DATA.letter.bodyParagraph2}
                      </p>
                    </div>

                    <div className="sm:col-span-4 flex justify-center">
                      <div className="p-1.5 bg-white border border-[#D8C5A5] shadow-md transform rotate-2 hover:rotate-0 transition-transform relative">
                        <PhotoFloralFlourish position="top-right" className="opacity-80" />
                        <img
                          src="/images/engagement-ring-reveal.png"
                          alt="The Engagement Ring Reveal"
                          className="w-20 h-24 sm:w-24 sm:h-28 object-cover"
                        />
                        <span className="block text-[9px] font-script text-center text-[#B98F91] pt-1">
                          She said yes ✨
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="py-2 px-3 bg-[#F2ECE4] border border-[#E5DFD5] text-center space-y-0.5">
                    <span className="font-serif text-sm sm:text-base text-[#20201E] font-medium block">
                      {COVER_DEFAULT_DATA.letter.eventDate}
                    </span>
                    <span className="text-[10px] tracking-wider uppercase text-[#8C867E] block font-sans">
                      {COVER_DEFAULT_DATA.letter.eventVenue}
                    </span>
                  </div>
                </div>

                {/* Action Buttons on Letter */}
                <div className="pt-4 flex flex-wrap items-center justify-between gap-2 border-t border-[#E5DFD5] relative z-10">
                  <button
                    onClick={onEnterCelebration}
                    className="px-4 py-2 bg-[#20201E] text-[#F8F5F0] text-[11px] uppercase tracking-[0.18em] font-medium hover:bg-[#383733] transition-colors flex items-center gap-1.5 cursor-pointer shadow-sm rounded-xs"
                  >
                    <span>Enter Celebration</span>
                    <span>→</span>
                  </button>

                  {onOpenRsvp && (
                    <button
                      onClick={onOpenRsvp}
                      className="px-3.5 py-2 border border-[#B98F91] text-[#B98F91] hover:bg-[#B98F91] hover:text-white text-[11px] uppercase tracking-[0.16em] font-medium transition-colors cursor-pointer rounded-xs"
                    >
                      Joyfully RSVP
                    </button>
                  )}
                </div>
              </GoldFoilGlare>
            </div>

            {/* ENVELOPE FOLD FLAPS (Harmonized with Warm Linen, Cream & Soft Champagne) */}

            {/* Left Triangular Flap */}
            <div
              className="absolute inset-0 pointer-events-none z-20"
              style={{
                clipPath: 'polygon(0% 0%, 50% 50%, 0% 100%)',
                background: 'linear-gradient(to right, #FAF8F5, #EDE6DC)',
                filter: 'drop-shadow(2px 0px 4px rgba(0,0,0,0.06))',
              }}
            />

            {/* Right Triangular Flap */}
            <div
              className="absolute inset-0 pointer-events-none z-20"
              style={{
                clipPath: 'polygon(100% 0%, 50% 50%, 100% 100%)',
                background: 'linear-gradient(to left, #FAF8F5, #EDE6DC)',
                filter: 'drop-shadow(-2px 0px 4px rgba(0,0,0,0.06))',
              }}
            />

            {/* Bottom Triangular Flap */}
            <div
              className="absolute inset-0 pointer-events-none z-20"
              style={{
                clipPath: 'polygon(0% 100%, 50% 50%, 100% 100%)',
                background: 'linear-gradient(to top, #EDE6DC, #F5EFE7)',
                filter: 'drop-shadow(0px -3px 6px rgba(0,0,0,0.08))',
              }}
            />

            {/* Top Triangular Flap (Animates Upwards in 3D) */}
            <div
              className="absolute inset-0 pointer-events-none origin-top transition-transform duration-700 ease-out z-30"
              style={{
                clipPath: 'polygon(0% 0%, 100% 0%, 50% 50%)',
                background: 'linear-gradient(to bottom, #FFFFFF, #EFE7DE)',
                transform: isOpen ? 'rotateX(180deg)' : 'rotateX(0deg)',
                filter: isOpen ? 'none' : 'drop-shadow(0px 4px 8px rgba(0,0,0,0.12))',
              }}
            />

            {/* CENTER WAX SEAL BUTTON in Signature Dusty Rose (#B98F91) with Soft Champagne Stars (Slides to bottom point when open so it never covers letter text) */}
            <div
              className={`absolute left-1/2 -translate-x-1/2 transition-all duration-700 ease-out z-50 ${
                isOpen
                  ? 'top-[92%] sm:top-[94%] -translate-y-1/2 scale-90'
                  : 'top-1/2 -translate-y-1/2 scale-100'
              }`}
            >
              {/* Soft Champagne Golden Sparkles Orbiting Seal */}
              <div className="absolute -top-6 -right-6 pointer-events-none text-[#D8C5A5] animate-sparkle">
                ✨
              </div>
              <div className="absolute -bottom-6 -left-6 pointer-events-none text-[#D8C5A5] animate-sparkle delay-500">
                ✨
              </div>
              <div className="absolute -top-5 -left-5 pointer-events-none text-[#D8C5A5] text-sm animate-sparkle delay-700">
                ✦
              </div>
              <div className="absolute -bottom-5 -right-5 pointer-events-none text-[#D8C5A5] text-sm animate-sparkle delay-1000">
                ✦
              </div>

              {/* Interactive Dusty Rose Wax Seal Button with Molten Impression Squish */}
              <button
                onClick={handleToggleOpen}
                aria-label={isOpen ? 'Fold Envelope Back' : 'Open Envelope Surprise'}
                title={isOpen ? 'Click seal to close envelope' : 'Click seal to open envelope'}
                className={`relative w-16 h-16 sm:w-20 sm:h-20 rounded-full flex items-center justify-center cursor-pointer transition-all duration-300 transform group cover-wax-palette ${
                  isSquishing
                    ? 'scale-x-125 scale-y-80 rotate-2 shadow-[0_0_35px_#D8C5A5]'
                    : 'hover:scale-110 active:scale-95'
                }`}
              >
                {/* Embossed inner rim */}
                <div className="w-13 h-13 sm:w-16 sm:h-16 rounded-full border border-white/40 flex items-center justify-center">
                  {/* Warm Ivory Heart Icon */}
                  <Heart
                    className="w-7 h-7 sm:w-8 sm:h-8 fill-[#F8F5F0] text-[#F8F5F0] transition-transform duration-300 group-hover:scale-115 drop-shadow-sm"
                  />
                </div>

                {/* Subtle pulse ring on hover */}
                <div className="absolute inset-0 rounded-full border-2 border-[#D8C5A5]/60 animate-ping pointer-events-none opacity-0 group-hover:opacity-40" />
              </button>
            </div>

            {/* Flying Sparkle Particles Canvas Overlay */}
            {particles.map((p) => (
              <div
                key={p.id}
                className="absolute pointer-events-none z-50"
                style={{
                  left: `${p.x}%`,
                  top: `${p.y}%`,
                  width: `${p.size}px`,
                  height: `${p.size}px`,
                  backgroundColor: p.color,
                  borderRadius: p.size > 8 ? '50%' : '2px',
                  opacity: p.opacity,
                  transform: `rotate(${p.rotation}deg)`,
                  boxShadow: `0 0 6px ${p.color}`,
                }}
              />
            ))}
          </div>
        </div>

        {/* BOTTOM SECTION: Calligraphy Dedication & Tap Prompt (Harmonized Colors) */}
        <div className="mt-8 text-center space-y-3 z-20">
          {/* Liquid Gold Flourish Divider */}
          <CalligraphyFlourish variant="divider" className="my-1" />

          {/* "💖 For My Amelia 💖" Calligraphy Dedication */}
          <div className="flex items-center justify-center gap-2">
            <span className="text-2xl sm:text-3xl text-[#B98F91] animate-bounce">💖</span>

            {isEditingName ? (
              <form onSubmit={handleSaveName} className="inline-flex items-center gap-2">
                <input
                  type="text"
                  value={tempName}
                  onChange={(e) => setTempName(e.target.value)}
                  className="bg-white/15 border border-[#D8C5A5]/50 px-3 py-1 text-2xl font-script text-[#F8F5F0] rounded focus:outline-none"
                  autoFocus
                />
                <button
                  type="submit"
                  className="p-1 rounded bg-[#D8C5A5] text-[#20201E]"
                  title="Save Name"
                >
                  <Check className="w-4 h-4" />
                </button>
              </form>
            ) : (
              <h1
                onClick={() => setIsEditingName(true)}
                className="font-script text-4xl sm:text-5xl md:text-6xl tracking-wide font-normal cursor-pointer text-[#F8F5F0] hover:text-[#D8C5A5] transition-colors drop-shadow-[0_2px_12px_rgba(216,197,165,0.3)]"
                title="Click to customize name"
              >
                For My {recipientName}
              </h1>
            )}

            <span className="text-2xl sm:text-3xl text-[#B98F91] animate-bounce">💖</span>

            {/* Discreet Edit button */}
            {!isEditingName && (
              <button
                onClick={() => setIsEditingName(true)}
                className="p-1 text-[#D8C5A5]/50 hover:text-[#D8C5A5] transition-colors cursor-pointer"
                title="Edit Recipient Name"
              >
                <Edit3 className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* "✨ Tap to open your surprise ✨" Button / Prompt in Soft Champagne */}
          <button
            onClick={handleToggleOpen}
            className="group inline-flex items-center gap-2 text-xs sm:text-sm tracking-[0.2em] uppercase font-sans font-medium transition-all duration-300 cursor-pointer text-[#D8C5A5] hover:text-[#F8F5F0] hover:scale-105"
          >
            <span className="text-base group-hover:rotate-12 transition-transform">✨</span>
            <span className="border-b border-[#D8C5A5]/60 group-hover:border-[#F8F5F0] pb-0.5">
              {isOpen ? 'Tap to fold envelope' : 'Tap to open your surprise'}
            </span>
            <span className="text-base group-hover:-rotate-12 transition-transform">✨</span>
          </button>
        </div>
      </div>

      {/* Clean Bottom Navigation Cue */}
      <div className="w-full max-w-5xl mx-auto flex items-center justify-between text-xs opacity-75 z-20 pt-4 border-t border-white/10 text-[#D8C5A5]">
        <span className="text-[11px] tracking-widest uppercase font-sans text-white/70">
          Amelia & Daniel Celebration
        </span>

        <button
          onClick={onEnterCelebration}
          className="inline-flex items-center gap-1.5 text-[#D8C5A5] hover:text-[#F8F5F0] transition-colors cursor-pointer tracking-wider uppercase text-[11px]"
        >
          <span>Continue to Celebration</span>
          <ArrowDown className="w-3.5 h-3.5 animate-bounce" />
        </button>
      </div>
    </section>
  );
};
