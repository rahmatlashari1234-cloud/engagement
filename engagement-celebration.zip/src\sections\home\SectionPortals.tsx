import React from 'react';
import { SECTION_PORTALS } from './homeData';
import { OptimizedImage } from '../../components/common/OptimizedImage';
import { TiltCard } from '../../components/common/TiltCard';
import { ArrowUpRight, Compass } from 'lucide-react';
import type { SectionKey } from '../../components/layout/Navbar';
import { BotanicalVine, RosePetal, PhotoFloralFlourish } from '../../components/common/FloralDecorations';

interface SectionPortalsProps {
  onNavigate: (sectionKey: SectionKey) => void;
}

export const SectionPortals: React.FC<SectionPortalsProps> = ({ onNavigate }) => {
  return (
    <section className="py-24 md:py-36 px-6 md:px-12 bg-[#FAF8F5] border-t border-[#E5DFD5]/80 relative overflow-hidden">
      {/* Botanical Corner Vines & Petals */}
      <BotanicalVine position="top-left" size="lg" opacity={0.6} />
      <BotanicalVine position="bottom-right" size="lg" opacity={0.55} />
      <div className="absolute top-28 left-10 pointer-events-none">
        <RosePetal variant={1} rotate={-20} scale={0.9} />
      </div>
      <div className="absolute bottom-24 right-12 pointer-events-none">
        <RosePetal variant={2} rotate={30} scale={0.85} />
      </div>
      <div className="max-w-6xl mx-auto space-y-16 md:space-y-24">
        {/* Section Header */}
        <div className="text-center space-y-4 max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-2">
            <Compass className="w-3.5 h-3.5 text-[#B98F91]" />
            <span className="text-[11px] uppercase tracking-[0.28em] text-[#6F6A63] font-semibold">
              The Celebration Chapters
            </span>
          </div>
          <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl text-[#20201E] font-normal tracking-tight">
            Explore Dedicated Sections
          </h2>
          <p className="text-sm md:text-base text-[#6F6A63] font-light leading-relaxed">
            Every chapter of our celebration has its own dedicated space. Move your cursor over the 3D gallery cards to explore each experience.
          </p>
          <div className="w-12 h-[1px] bg-[#D8C5A5] mx-auto mt-4" />
        </div>

        {/* 6 Gateway Cards Grid with 3D Mouse Perspective Tilt */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {SECTION_PORTALS.map((portal) => (
            <TiltCard
              key={portal.id}
              maxRotation={7}
              scale={1.03}
              onClick={() => onNavigate(portal.sectionKey as SectionKey)}
              className="cursor-pointer"
            >
              <div className="h-full bg-[#F8F5F0] border border-[#E5DFD5] shadow-[0_8px_30px_rgba(32,32,30,0.03)] overflow-hidden transition-all duration-300 hover:border-[#B98F91] flex flex-col justify-between">
                <div>
                  <div className="relative overflow-hidden bg-[#EDE6DC] aspect-[16/10]">
                    <PhotoFloralFlourish position="top-right" className="opacity-80 z-20" />
                    <OptimizedImage
                      src={portal.previewImage}
                      alt={portal.title}
                      animation="zoom-hover"
                      cornerAccents={true}
                      curtainReveal={true}
                      className="w-full h-full"
                      objectFit="cover"
                    />
                    <div className="absolute top-3 left-3 bg-[#F8F5F0]/90 backdrop-blur-sm px-2.5 py-0.5 text-[10px] uppercase tracking-widest text-[#20201E] font-mono border border-[#E5DFD5]">
                      {portal.number}
                    </div>
                  </div>

                  <div className="p-6 space-y-2">
                    <h3 className="font-serif text-2xl text-[#20201E] transition-colors flex items-center justify-between">
                      <span>{portal.title}</span>
                      <ArrowUpRight className="w-4 h-4 text-[#8C867E]" />
                    </h3>
                    <p className="text-xs text-[#6F6A63] font-light leading-relaxed">
                      {portal.tagline}
                    </p>
                  </div>
                </div>

                <div className="p-6 pt-0">
                  <span className="inline-flex items-center gap-1.5 text-xs uppercase tracking-wider text-[#20201E] font-medium">
                    <span>{portal.buttonText}</span>
                    <span>→</span>
                  </span>
                </div>
              </div>
            </TiltCard>
          ))}
        </div>

        {/* Quick Shortcuts Bar */}
        <div className="p-8 bg-[#F2ECE4] border border-[#E5DFD5] flex flex-wrap items-center justify-between gap-6">
          <div className="space-y-1">
            <span className="font-serif text-xl text-[#20201E] block">
              Looking for something specific?
            </span>
            <span className="text-xs text-[#6F6A63] font-light">
              Jump directly to any guest experience:
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => onNavigate('event')}
              className="px-4 py-2 bg-[#FAF8F5] border border-[#E5DFD5] text-xs uppercase tracking-wider hover:border-[#20201E] transition-colors cursor-pointer"
            >
              Event Logistics & FAQ
            </button>
            <button
              onClick={() => onNavigate('wishing-well')}
              className="px-4 py-2 bg-[#FAF8F5] border border-[#E5DFD5] text-xs uppercase tracking-wider hover:border-[#20201E] transition-colors cursor-pointer"
            >
              Honeymoon Fund
            </button>
            <button
              onClick={() => onNavigate('rsvp')}
              className="px-5 py-2 bg-[#20201E] text-[#F8F5F0] text-xs uppercase tracking-widest font-medium hover:bg-[#383733] transition-colors cursor-pointer"
            >
              RSVP Now
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
