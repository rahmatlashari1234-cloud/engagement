import React, { useState, useRef, useEffect, useCallback } from 'react';
import type { GalleryItem } from '../../sections/gallery/galleryData';
import { OptimizedImage } from '../common/OptimizedImage';
import { ChevronLeft, ChevronRight, Eye, Sparkles } from 'lucide-react';

interface CurvedCylinderGalleryProps {
  items: GalleryItem[];
  onOpenLightbox: (index: number) => void;
  className?: string;
}

export const CurvedCylinderGallery: React.FC<CurvedCylinderGalleryProps> = ({
  items,
  onOpenLightbox,
  className = '',
}) => {
  const [rotationAngle, setRotationAngle] = useState(0);
  const [activeIndex, setActiveIndex] = useState(0);
  const isDraggingRef = useRef(false);
  const startXRef = useRef(0);
  const currentAngleRef = useRef(0);
  const velocityRef = useRef(0);
  const containerRef = useRef<HTMLDivElement>(null);

  // Geometry calculations
  const totalItems = Math.min(items.length, 12);
  const displayItems = items.slice(0, totalItems);
  const anglePerItem = 360 / totalItems;
  const cylinderRadius = 460; // 3D radius in px

  const updateActiveFromAngle = useCallback((angle: number) => {
    // Normalize angle to [0, 360)
    const normalized = ((-angle % 360) + 360) % 360;
    const closestIdx = Math.round(normalized / anglePerItem) % totalItems;
    setActiveIndex(closestIdx);
  }, [anglePerItem, totalItems]);

  const rotateTo = (index: number) => {
    const targetAngle = -index * anglePerItem;
    // Animate smoothly to targetAngle
    currentAngleRef.current = targetAngle;
    setRotationAngle(targetAngle);
    setActiveIndex(index);
  };

  const handlePrev = () => {
    const nextIdx = (activeIndex - 1 + totalItems) % totalItems;
    rotateTo(nextIdx);
  };

  const handleNext = () => {
    const nextIdx = (activeIndex + 1) % totalItems;
    rotateTo(nextIdx);
  };

  // Drag interaction
  const onMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = true;
    startXRef.current = e.clientX;
    velocityRef.current = 0;
  };

  const onMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current) return;
    const deltaX = e.clientX - startXRef.current;
    const angleDelta = (deltaX / window.innerWidth) * 120;
    currentAngleRef.current += angleDelta;
    velocityRef.current = angleDelta;
    setRotationAngle(currentAngleRef.current);
    updateActiveFromAngle(currentAngleRef.current);
    startXRef.current = e.clientX;
  };

  const onMouseUp = () => {
    if (!isDraggingRef.current) return;
    isDraggingRef.current = false;
    // Snap to closest card
    const targetIdx = Math.round(-currentAngleRef.current / anglePerItem);
    rotateTo(((targetIdx % totalItems) + totalItems) % totalItems);
  };

  // Touch handlers for mobile
  const onTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 0) return;
    isDraggingRef.current = true;
    startXRef.current = e.touches[0].clientX;
  };

  const onTouchMove = (e: React.TouchEvent) => {
    if (!isDraggingRef.current || e.touches.length === 0) return;
    const deltaX = e.touches[0].clientX - startXRef.current;
    const angleDelta = (deltaX / window.innerWidth) * 140;
    currentAngleRef.current += angleDelta;
    setRotationAngle(currentAngleRef.current);
    updateActiveFromAngle(currentAngleRef.current);
    startXRef.current = e.touches[0].clientX;
  };

  const onTouchEnd = () => {
    isDraggingRef.current = false;
    const targetIdx = Math.round(-currentAngleRef.current / anglePerItem);
    rotateTo(((targetIdx % totalItems) + totalItems) % totalItems);
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') handlePrev();
      if (e.key === 'ArrowRight') handleNext();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeIndex]);

  return (
    <div
      ref={containerRef}
      className={`relative w-full py-16 overflow-hidden select-none cursor-grab active:cursor-grabbing ${className}`}
      onMouseDown={onMouseDown}
      onMouseMove={onMouseMove}
      onMouseUp={onMouseUp}
      onMouseLeave={onMouseUp}
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
    >
      {/* 3D Perspective Stage Container */}
      <div
        className="w-full h-[460px] sm:h-[520px] flex items-center justify-center relative"
        style={{
          perspective: '1400px',
          perspectiveOrigin: '50% 50%',
        }}
      >
        {/* Revolving Cylinder Carousel */}
        <div
          className="relative w-[280px] sm:w-[320px] h-[380px] sm:h-[440px] transition-transform duration-500 ease-out"
          style={{
            transformStyle: 'preserve-3d',
            transform: `rotateY(${rotationAngle}deg)`,
          }}
        >
          {displayItems.map((item, idx) => {
            const itemAngle = idx * anglePerItem;
            const isCenter = idx === activeIndex;

            // Calculate angular distance to active
            const diffAngle = Math.abs((((itemAngle + rotationAngle) % 360) + 540) % 360 - 180);
            const opacity = Math.max(0.2, 1 - (diffAngle / 120));

            return (
              <div
                key={item.id}
                onClick={(e) => {
                  e.stopPropagation();
                  if (isCenter) {
                    onOpenLightbox(idx);
                  } else {
                    rotateTo(idx);
                  }
                }}
                className={`absolute inset-0 bg-[#FAF8F5] border transition-all duration-300 rounded-sm shadow-2xl p-2.5 flex flex-col justify-between ${
                  isCenter
                    ? 'border-[#D8C5A5] ring-2 ring-[#B98F91]/30 shadow-[0_25px_60px_rgba(32,32,30,0.22)]'
                    : 'border-[#E5DFD5] opacity-75 hover:opacity-100'
                }`}
                style={{
                  transform: `rotateY(${itemAngle}deg) translateZ(${cylinderRadius}px)`,
                  backfaceVisibility: 'hidden',
                  opacity,
                }}
              >
                {/* Photo with inner matting */}
                <div className="relative w-full h-[78%] overflow-hidden bg-[#EDE6DC] border border-[#E5DFD5]">
                  <OptimizedImage
                    src={item.imageUrl}
                    alt={item.title}
                    className="w-full h-full"
                    objectFit="cover"
                  />

                  {/* Focus Badge */}
                  {isCenter && (
                    <div className="absolute top-2.5 left-2.5 z-10 flex items-center gap-1.5 px-2.5 py-0.5 bg-[#20201E]/75 backdrop-blur-sm text-white text-[9px] uppercase tracking-widest font-mono rounded-full border border-white/20">
                      <Sparkles className="w-2.5 h-2.5 text-[#D8C5A5]" />
                      <span>Plate {String(idx + 1).padStart(2, '0')}</span>
                    </div>
                  )}

                  {/* Expand Overlay */}
                  <div className="absolute inset-0 bg-[#20201E]/30 opacity-0 hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <span className="px-3 py-1 bg-[#FAF8F5] text-[#20201E] text-[10px] uppercase tracking-widest font-medium border border-[#D8C5A5] shadow-sm flex items-center gap-1">
                      <Eye className="w-3 h-3 text-[#B98F91]" />
                      <span>{isCenter ? 'Expand Full' : 'Focus'}</span>
                    </span>
                  </div>
                </div>

                {/* Editorial Caption */}
                <div className="pt-2 px-1 text-center">
                  <h4 className="font-serif text-sm sm:text-base text-[#20201E] truncate font-normal">
                    {item.title}
                  </h4>
                  <span className="text-[10px] uppercase tracking-wider text-[#8C867E] block truncate font-sans">
                    {item.location || item.category}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 3D Navigation Controls */}
      <div className="flex items-center justify-center gap-6 mt-8 z-20 relative">
        <button
          onClick={handlePrev}
          aria-label="Previous photograph in 3D cylinder"
          className="p-2.5 rounded-full bg-[#FAF8F5] border border-[#D8C5A5] text-[#20201E] hover:bg-[#20201E] hover:text-[#FAF8F5] transition-colors shadow-sm cursor-pointer"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>

        <div className="text-center">
          <span className="font-serif text-sm text-[#20201E]">
            {String(activeIndex + 1).padStart(2, '0')}
          </span>
          <span className="text-[#8C867E] text-xs font-mono mx-1.5">/</span>
          <span className="font-mono text-xs text-[#8C867E]">
            {String(totalItems).padStart(2, '0')}
          </span>
        </div>

        <button
          onClick={handleNext}
          aria-label="Next photograph in 3D cylinder"
          className="p-2.5 rounded-full bg-[#FAF8F5] border border-[#D8C5A5] text-[#20201E] hover:bg-[#20201E] hover:text-[#FAF8F5] transition-colors shadow-sm cursor-pointer"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      <p className="text-center text-[11px] uppercase tracking-widest text-[#8C867E] mt-3 font-sans">
        ✦ Drag or swipe horizontally to revolve in 3D space ✦
      </p>
    </div>
  );
};
