import React from 'react';
import { SITE_CONFIG } from '../../data/engagementContent';
import { OptimizedImage } from '../common/OptimizedImage';
import { FloralDivider } from '../common/FloralDivider';

export const Families: React.FC = () => {
  const { families } = SITE_CONFIG;

  return (
    <section className="py-24 md:py-36 px-6 md:px-12 bg-[#F8F5F0] border-t border-[#E5DFD5]/60">
      <div className="max-w-5xl mx-auto">
        {/* Section Header */}
        <div className="text-center space-y-4 mb-16 md:mb-24">
          <span className="text-[11px] tracking-[0.26em] uppercase text-[#B98F91] font-semibold">
            05 / Heritage & Gratitude
          </span>
          <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl text-[#20201E] font-normal tracking-tight">
            {families.heading}
          </h2>
          <p className="max-w-2xl mx-auto text-sm md:text-base text-[#6F6A63] font-light leading-relaxed">
            {families.subheading}
          </p>
          <FloralDivider variant="diamond" className="my-6" />
        </div>

        {/* Family Quote */}
        <div className="max-w-3xl mx-auto text-center mb-16 md:mb-20 px-4">
          <p className="font-serif italic text-xl md:text-2xl text-[#20201E] font-light leading-relaxed">
            {families.quote}
          </p>
        </div>

        {/* Respectful Family Introduction Columns */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 md:gap-16">
          {/* Bride's Family */}
          <div className="space-y-6 text-center md:text-left">
            <div className="overflow-hidden border border-[#E5DFD5] bg-[#EDE6DC] shadow-sm">
              <OptimizedImage
                src={families.brideParents.imageUrl}
                alt={families.brideParents.imageAlt}
                aspectRatio="16/11"
                className="w-full"
                objectFit="cover"
              />
            </div>
            <div className="space-y-2 pt-2">
              <span className="text-xs uppercase tracking-[0.2em] text-[#B98F91] font-semibold block">
                {families.brideParents.title}
              </span>
              <h3 className="font-serif text-2xl md:text-3xl text-[#20201E] font-normal">
                {families.brideParents.names}
              </h3>
              <p className="text-sm text-[#8C867E] tracking-wider uppercase font-sans">
                {families.brideParents.note}
              </p>
              <p className="text-sm text-[#6F6A63] font-light leading-relaxed pt-2">
                With endless gratitude for a lifetime of unconditional love, laughter at every dinner table, and showing us the true meaning of an enduring marriage.
              </p>
            </div>
          </div>

          {/* Groom's Family */}
          <div className="space-y-6 text-center md:text-left">
            <div className="overflow-hidden border border-[#E5DFD5] bg-[#EDE6DC] shadow-sm">
              <OptimizedImage
                src={families.groomParents.imageUrl}
                alt={families.groomParents.imageAlt}
                aspectRatio="16/11"
                className="w-full"
                objectFit="cover"
              />
            </div>
            <div className="space-y-2 pt-2">
              <span className="text-xs uppercase tracking-[0.2em] text-[#D8C5A5] font-semibold block">
                {families.groomParents.title}
              </span>
              <h3 className="font-serif text-2xl md:text-3xl text-[#20201E] font-normal">
                {families.groomParents.names}
              </h3>
              <p className="text-sm text-[#8C867E] tracking-wider uppercase font-sans">
                {families.groomParents.note}
              </p>
              <p className="text-sm text-[#6F6A63] font-light leading-relaxed pt-2">
                With heartfelt thanks for steadfast guidance, endless encouragement, and opening your arms with warmth to embrace our new shared chapter.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
