import React, { useState } from 'react';
import { EVENT_VENUE, EVENT_SCHEDULE, EVENT_META } from './eventData';
import { OptimizedImage } from '../../components/common/OptimizedImage';
import { VenueModal } from '../../components/modals/VenueModal';
import { Calendar, Clock, MapPin, Compass, Sparkles } from 'lucide-react';
import { BotanicalVine, RosePetal, PhotoFloralFlourish } from '../../components/common/FloralDecorations';

export const EventDetails: React.FC = () => {
  const [venueModalOpen, setVenueModalOpen] = useState(false);

  return (
    <section id="event" className="py-24 md:py-36 px-6 md:px-12 bg-[#FAF8F5] border-t border-[#E5DFD5]/60 animate-fade-in relative overflow-hidden">
      {/* Botanical Corner Vines & Drifting Petals */}
      <BotanicalVine position="top-left" size="lg" opacity={0.65} />
      <BotanicalVine position="top-right" size="lg" opacity={0.6} />
      <BotanicalVine position="bottom-left" size="md" opacity={0.5} />
      <BotanicalVine position="bottom-right" size="md" opacity={0.5} />

      <div className="absolute top-36 left-8 pointer-events-none">
        <RosePetal variant={1} rotate={-15} scale={1} />
      </div>
      <div className="absolute top-52 right-12 pointer-events-none">
        <RosePetal variant={2} rotate={35} scale={0.9} />
      </div>
      <div className="absolute bottom-36 left-10 pointer-events-none">
        <RosePetal variant={3} rotate={15} scale={0.85} />
      </div>
      <div className="absolute bottom-24 right-14 pointer-events-none">
        <RosePetal variant={1} rotate={-30} scale={0.9} />
      </div>

      <div className="max-w-6xl mx-auto space-y-20 md:space-y-28">
        {/* Section Header */}
        <div className="text-center space-y-4 max-w-2xl mx-auto">
          <span className="text-[11px] tracking-[0.26em] uppercase text-[#B98F91] font-semibold">
            {EVENT_META.sectionNumber}
          </span>
          <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl text-[#20201E] font-normal tracking-tight">
            {EVENT_META.heading}
          </h2>
          <p className="text-sm md:text-base text-[#6F6A63] font-light leading-relaxed">
            {EVENT_META.subheading}
          </p>
          <div className="w-12 h-[1px] bg-[#D8C5A5] mx-auto mt-4" />
        </div>

        {/* Primary Event Overview Card */}
        <div className="bg-[#F8F5F0] border border-[#E5DFD5] shadow-[0_10px_35px_rgba(32,32,30,0.04)] overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch">
            {/* Left: Venue Image with Editorial Animation */}
            <div className="lg:col-span-5 relative bg-[#EDE6DC] group overflow-hidden">
              <PhotoFloralFlourish position="top-left" className="opacity-85 z-20" />
              <OptimizedImage
                src="https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=1200&q=85"
                alt="The Glasshouse Conservatory architecture"
                className="w-full h-full min-h-[320px]"
                animation="zoom-hover"
                cornerAccents={true}
                curtainReveal={true}
                objectFit="cover"
              />
              <div className="absolute top-4 left-4 z-10 bg-[#F8F5F0]/90 backdrop-blur-sm px-3 py-1 text-[10px] uppercase tracking-widest text-[#20201E] font-medium border border-[#E5DFD5] transition-transform duration-300 group-hover:translate-x-0.5">
                Estate Grounds
              </div>
            </div>

            {/* Right: Key Facts */}
            <div className="lg:col-span-7 p-8 md:p-12 flex flex-col justify-between space-y-8">
              <div className="space-y-6">
                <div>
                  <span className="text-xs uppercase tracking-[0.24em] text-[#B98F91] font-semibold block mb-1">
                    Engagement Ceremony & Dinner
                  </span>
                  <h3 className="font-serif text-3xl md:text-4xl text-[#20201E]">
                    {EVENT_VENUE.name}
                  </h3>
                  <p className="font-serif italic text-lg text-[#6F6A63]">
                    {EVENT_VENUE.estate}
                  </p>
                </div>

                {/* Grid of Key Info */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-4 border-t border-[#E5DFD5]/80">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-[#8C867E]">
                      <Calendar className="w-3.5 h-3.5 text-[#B98F91]" />
                      <span>Date</span>
                    </div>
                    <p className="font-serif text-lg text-[#20201E]">
                      {EVENT_META.displayDate}
                    </p>
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-[#8C867E]">
                      <Clock className="w-3.5 h-3.5 text-[#D8C5A5]" />
                      <span>Time</span>
                    </div>
                    <p className="font-serif text-lg text-[#20201E]">
                      {EVENT_META.displayTime}
                    </p>
                  </div>

                  <div className="space-y-1 sm:col-span-2">
                    <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-[#8C867E]">
                      <MapPin className="w-3.5 h-3.5 text-[#9BA595]" />
                      <span>Address & Location</span>
                    </div>
                    <p className="font-serif text-lg text-[#20201E]">
                      {EVENT_VENUE.address}, {EVENT_VENUE.cityStateZip}
                    </p>
                  </div>
                </div>
              </div>

              {/* Action: Open Venue Modal */}
              <div className="pt-4 border-t border-[#E5DFD5]/80 flex flex-wrap items-center justify-between gap-4">
                <button
                  onClick={() => setVenueModalOpen(true)}
                  className="inline-flex items-center gap-2 px-6 py-3 bg-[#20201E] text-[#F8F5F0] text-xs uppercase tracking-[0.16em] font-medium hover:bg-[#383733] transition-colors cursor-pointer"
                >
                  <Compass className="w-4 h-4 text-[#D8C5A5]" />
                  <span>View Location & Directions</span>
                </button>

                <span className="text-xs text-[#8C867E] italic">
                  Valet parking provided on-site
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Schedule Breakdown */}
        <div className="space-y-8">
          <div className="text-center">
            <span className="text-xs uppercase tracking-[0.24em] text-[#8C867E]">
              Flow of the Evening
            </span>
            <h3 className="font-serif text-3xl md:text-4xl text-[#20201E] mt-1">
              Celebration Schedule
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {EVENT_SCHEDULE.map((item, idx) => (
              <div
                key={idx}
                className="p-6 bg-[#F8F5F0] border border-[#E5DFD5] space-y-3 relative group hover:border-[#D8C5A5] transition-colors"
              >
                <div className="flex items-center justify-between">
                  <span className="font-serif text-2xl text-[#B98F91]">
                    {item.time}
                  </span>
                  <Sparkles className="w-3.5 h-3.5 text-[#D8C5A5] opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
                <h4 className="font-serif text-xl text-[#20201E] font-normal leading-snug">
                  {item.title}
                </h4>
                <p className="text-xs text-[#6F6A63] font-light leading-relaxed">
                  {item.description}
                </p>
                <span className="block text-[10px] uppercase tracking-wider text-[#8C867E] pt-2 border-t border-[#E5DFD5]/60 font-sans">
                  {item.location}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Interactive Venue Details Modal */}
      <VenueModal
        isOpen={venueModalOpen}
        onClose={() => setVenueModalOpen(false)}
      />
    </section>
  );
};
