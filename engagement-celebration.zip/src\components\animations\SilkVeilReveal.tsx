import React, { useEffect, useState } from 'react';

interface SilkVeilRevealProps {
  children: React.ReactNode;
  isOpen?: boolean;
  className?: string;
}

export const SilkVeilReveal: React.FC<SilkVeilRevealProps> = ({
  children,
  isOpen = true,
  className = '',
}) => {
  const [veilLifted, setVeilLifted] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setVeilLifted(false);
      const timer = setTimeout(() => {
        setVeilLifted(true);
      }, 50);
      return () => clearTimeout(timer);
    } else {
      setVeilLifted(false);
    }
  }, [isOpen]);

  return (
    <div className={`relative overflow-hidden ${className}`}>
      {children}

      {/* COUTURE SILK VEIL TRANSLUCENT OVERLAY */}
      <div
        className={`absolute inset-0 pointer-events-none transition-all duration-700 ease-out z-40 ${
          veilLifted
            ? 'opacity-0 -translate-y-full'
            : 'opacity-100 translate-y-0'
        }`}
        style={{
          background:
            'linear-gradient(180deg, rgba(250, 248, 245, 0.95) 0%, rgba(245, 238, 228, 0.88) 50%, rgba(216, 197, 165, 0.3) 100%)',
          backdropFilter: 'blur(8px)',
        }}
      >
        {/* Soft fabric wave folds */}
        <div className="absolute bottom-0 inset-x-0 h-16 bg-gradient-to-t from-[#FAF8F5]/80 via-transparent to-transparent" />
      </div>
    </div>
  );
};
