export interface Milestone {
  id: string;
  year: string;
  date: string;
  title: string;
  description: string;
  location: string;
  imageUrl: string;
  imageAlt: string;
  tag: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: 'all' | 'couple' | 'proposal' | 'details' | 'candid';
  imageUrl: string;
  caption: string;
  aspect: 'tall' | 'wide' | 'square';
  location?: string;
}

export interface MomentItem {
  id: string;
  number: string;
  title: string;
  subtitle: string;
  story: string;
  date: string;
  imageUrl: string;
  imageAlt: string;
  quote?: string;
}

export interface ScheduleEvent {
  time: string;
  title: string;
  description: string;
  location: string;
}

export interface TrackItem {
  id: string;
  title: string;
  artist: string;
  album: string;
  year: string;
  note: string;
  duration: string;
}

export interface GuidePlace {
  id: string;
  category: string;
  name: string;
  town: string;
  address: string;
  note: string;
  imageUrl: string;
  tip: string;
}

export interface FaqItem {
  question: string;
  answer: string;
  category: string;
}

export interface HoneymoonItem {
  id: string;
  title: string;
  destination: string;
  description: string;
  amount: string;
  imageUrl: string;
  tag: string;
}

export interface ToastItem {
  id: string;
  author: string;
  relationship: string;
  message: string;
  date: string;
}

export const SITE_CONFIG = {
  couple: {
    brideFirst: "Amelia",
    brideFull: "Amelia Montgomery",
    groomFirst: "Daniel",
    groomFull: "Daniel Sterling",
    monogram: "A & D",
    hashtag: "#AmeliaAndDaniel2026",
  },
  celebrationDate: {
    display: "Saturday, November 14, 2026",
    time: "5:00 PM Eastern Standard Time",
    isoDate: "2026-11-14T17:00:00-05:00",
    rsvpDeadline: "October 20, 2026",
    engagementDate: "August 29, 2026",
    engagementLocation: "Positano, Amalfi Coast, Italy",
  },
  venue: {
    name: "The Glasshouse Conservatory",
    estate: "Stone Hill Estate & Gardens",
    address: "842 Hilltop Ridge Road",
    cityStateZip: "Hudson Valley, NY 12538",
    googleMapsUrl: "https://maps.google.com/?q=Hudson+Valley+New+York",
    phone: "+1 (845) 555-0192",
    email: "celebration@ameliaanddaniel.com",
    valetNote: "Complimentary valet parking will be available at the estate entrance.",
    shuttleNote: "Shuttle transportation provided from The Beekman Arms Hotel starting at 4:15 PM.",
    dressCode: "Formal Cocktail • Muted & Earth Tones",
  },
  editorial: {
    eyebrow: "THE BEGINNING OF FOREVER",
    heroSupporting: "Together with their families, they are delighted to celebrate their engagement.",
    introHeading: "Two Stories. One Beginning.",
    introText1: "It was never about grand theatrical gestures; it was the quiet realization that every road before this was leading to the exact same place. Over morning coffees, quiet train rides, shared laughter, and five years of learning each other's cadence, we found home.",
    introText2: "On a sunlit evening overlooking the Mediterranean in Positano, a simple question was asked, and an eternal promise was spoken. Now, we gather our closest loved ones to celebrate the beginning of the rest of our lives.",
    coupleQuote: "“Some moments become memories. Some moments become the foundation of everything that follows.”",
    engagementSectionHeading: "WE SAID YES",
    engagementNarrative: "With the Mediterranean shimmering beneath the August twilight and the faint melody of church bells echoing across the cliffs, Daniel asked Amelia to walk through every chapter of life together. With tears, laughter, and an absolute certainty in our hearts, forever began right there.",
    loveNote: {
      heading: "A New Chapter Begins",
      paragraph1: "To our dearest family and lifelong friends: each of you has shaped who we are individually, and who we are together. You have cheered for us through beginnings, supported us through quiet moments, and brought boundless joy to our journey.",
      paragraph2: "As we step into this next chapter, having you by our side to toast our engagement means more to us than words can convey. We cannot wait to dance, laugh, and celebrate together under the autumn stars.",
      signoff: "With all our love,",
      coupleSignatures: "Amelia & Daniel"
    }
  },
  dressCode: {
    title: "DRESS CODE",
    subtitle: "Formal Cocktail • Warm Earth & Muted Tones",
    description: "We invite you to dress in elegant formal cocktail attire. To complement the natural botanical aesthetic of the Glasshouse Conservatory, we encourage soft, muted shades such as warm ivory, champagne, dusty rose, muted sage, and deep charcoal.",
    palette: [
      { name: "Warm Ivory", hex: "#F8F5F0", border: "#E5DFD5" },
      { name: "Champagne", hex: "#D8C5A5", border: "#C8B492" },
      { name: "Dusty Rose", hex: "#B98F91", border: "#A77A7C" },
      { name: "Muted Sage", hex: "#9BA595", border: "#889481" },
      { name: "Muted Taupe", hex: "#6F6A63", border: "#5C5750" },
      { name: "Deep Charcoal", hex: "#20201E", border: "#0F0F0E" },
    ],
    footwearNote: "The ceremony and cocktail reception will take place across paved stone pathways and the conservatory lawn. Stiletto heels are welcome, though block heels or wedges may offer greater comfort."
  },
  families: {
    heading: "With Love From Our Families",
    subheading: "United in joy and gratitude",
    quote: "“The love of a family is life’s greatest blessing. We are forever grateful for the foundation, warmth, and enduring grace our parents have given us every step of the way.”",
    brideParents: {
      title: "Parents of the Bride",
      names: "Mr. Arthur & Mrs. Evelyn Montgomery",
      note: "Hudson Valley, New York",
      imageUrl: "https://images.unsplash.com/photo-1543807535-eceef0bc6599?auto=format&fit=crop&w=1000&q=85",
      imageAlt: "Arthur and Evelyn Montgomery"
    },
    groomParents: {
      title: "Parents of the Groom",
      names: "Dr. Richard & Mrs. Eleanor Sterling",
      note: "Boston, Massachusetts",
      imageUrl: "https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&w=1000&q=85",
      imageAlt: "Richard and Eleanor Sterling"
    }
  },
  schedule: [
    {
      time: "5:00 PM",
      title: "Welcome Drinks & Passed Canapés",
      description: "Arrival at the Stone Hill Estate. Guests are welcomed to the conservatory garden terrace with champagne and seasonal small plates.",
      location: "Garden Terrace"
    },
    {
      time: "6:00 PM",
      title: "Engagement Ceremony & Ring Blessing",
      description: "An intimate ceremony celebrating our commitment, accompanied by live acoustic strings and personal blessings.",
      location: "The Glasshouse Conservatory"
    },
    {
      time: "7:15 PM",
      title: "Candlelit Dinner & Heartfelt Toasts",
      description: "A seasonal three-course farm-to-table dinner featuring local Hudson Valley harvests and toasts from our families.",
      location: "The Grand Atrium"
    },
    {
      time: "9:00 PM",
      title: "Dessert, Cocktails & Dancing",
      description: "Cutting the celebration cake, artisanal espresso bar, and dancing under the stars until midnight.",
      location: "The Conservatory Pavilion"
    }
  ]
};

export const STORY_MILESTONES: Milestone[] = [
  {
    id: "m1",
    year: "2021",
    date: "October 14, 2021",
    title: "First Meeting",
    description: "An impromptu rainy afternoon in Greenwich Village. A crowded corner café with only one open table left. What was meant to be a twenty-minute coffee turned into three hours of effortless conversation about architecture, literature, and favorite records.",
    location: "Greenwich Village, New York",
    imageUrl: "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=1000&q=85",
    imageAlt: "Amelia and Daniel first meeting",
    tag: "The Spark"
  },
  {
    id: "m2",
    year: "2022",
    date: "February 22, 2022",
    title: "First Conversation That Never Ended",
    description: "Walking across the Brooklyn Bridge past midnight under gentle winter flurries, losing track of time and realizing that silence with each other was just as comforting as words.",
    location: "Brooklyn, New York",
    imageUrl: "https://images.unsplash.com/photo-1537633552985-df8429e8048b?auto=format&fit=crop&w=1000&q=85",
    imageAlt: "Night in the city together",
    tag: "City Lights"
  },
  {
    id: "m3",
    year: "2023",
    date: "July 8, 2023",
    title: "Our First Long Journey",
    description: "Traveling along coastal cliffside roads, getting delightfully lost without a map, and discovering that traveling together felt like a seamless dance rather than an itinerary.",
    location: "Amalfi Coast, Italy",
    imageUrl: "https://images.unsplash.com/photo-1465495976277-4387d4b0b4c6?auto=format&fit=crop&w=1000&q=85",
    imageAlt: "Coastal road trip together",
    tag: "The Horizon"
  },
  {
    id: "m4",
    year: "2025",
    date: "April 19, 2025",
    title: "Building Our Shared Home",
    description: "Unpacking endless cardboard boxes in our sun-drenched loft, assembling bookshelves together, and bringing home Oliver, our golden retriever who immediately made our house a home.",
    location: "Hudson Valley, New York",
    imageUrl: "https://images.unsplash.com/photo-1529636798458-92182e662485?auto=format&fit=crop&w=1000&q=85",
    imageAlt: "Sunlit moments in Hudson Valley",
    tag: "Rooted"
  },
  {
    id: "m5",
    year: "2026",
    date: "August 29, 2026",
    title: "The Question & She Said Yes",
    description: "Under the golden hour glow on a secluded cliffside balcony overlooking Positano, Daniel knelt down. Between joyful tears and quiet gasps of wonder, Amelia said yes before he could even finish the sentence.",
    location: "Positano, Italy",
    imageUrl: "https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=1000&q=85",
    imageAlt: "The proposal ring and embrace",
    tag: "Forever"
  },
  {
    id: "m6",
    year: "2026",
    date: "November 14, 2026",
    title: "Our Engagement Celebration",
    description: "Gathering our closest loved ones under the glass conservatory to raise a glass to love, intentional partnerships, and the countless adventures that await us.",
    location: "The Glasshouse Conservatory",
    imageUrl: "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&w=1000&q=85",
    imageAlt: "Celebration with loved ones",
    tag: "The Celebration"
  }
];

export const MOMENTS_WE_KEEP: MomentItem[] = [
  {
    id: "moment-1",
    number: "01",
    title: "That First Hello",
    subtitle: "A rainy Tuesday in Manhattan",
    story: "We both reached for the same vintage hardcover at the Strand Bookstore before realizing we had also ordered the exact same cortado ten minutes earlier. What began as an apologetic laugh became the beginning of every tomorrow.",
    date: "Autumn 2021",
    imageUrl: "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=1200&q=85",
    imageAlt: "The first hello",
    quote: "“You didn’t just enter my life; you gave it context.”"
  },
  {
    id: "moment-2",
    number: "02",
    title: "The Day Everything Changed",
    subtitle: "A silent morning at Montauk Point",
    story: "Watching the Atlantic horizon wrap in dense morning mist, wrapped in a single wool blanket. Without uttering a word, we both understood that whatever the world brought next, we would meet it as one.",
    date: "Spring 2023",
    imageUrl: "https://images.unsplash.com/photo-1583939003579-730e3918a45a?auto=format&fit=crop&w=1200&q=85",
    imageAlt: "Montauk Point morning",
    quote: "“In your quiet, I found the certainty I had searched for my whole life.”"
  },
  {
    id: "moment-3",
    number: "03",
    title: "Sunsets in Positano",
    subtitle: "Overlooking the Tyrrhenian Sea",
    story: "Warm breezes carrying the scent of rosemary and lemon trees. We spent hours watching small wooden fishing boats return to the shore as the cliffside villas lit up like amber constellations.",
    date: "Summer 2026",
    imageUrl: "https://images.unsplash.com/photo-1470240731273-7821a6eeb6bd?auto=format&fit=crop&w=1200&q=85",
    imageAlt: "Sunset over the coastline",
    quote: "“Time stood completely still, and the world belonged solely to us.”"
  },
  {
    id: "moment-4",
    number: "04",
    title: "The Question",
    subtitle: "August 29, 2026 • Golden Hour",
    story: "With a custom antique oval ring crafted from his grandmother's heirloom gold, Daniel asked for a lifetime together. The tears that followed were sweeter than any speech either of us could have rehearsed.",
    date: "August 2026",
    imageUrl: "https://images.unsplash.com/photo-1605100804763-247f67b3557e?auto=format&fit=crop&w=1200&q=85",
    imageAlt: "The ring and proposal moment",
    quote: "“Yes, a million times yes.”"
  },
  {
    id: "moment-5",
    number: "05",
    title: "The Beginning of Forever",
    subtitle: "The promise we carry forward",
    story: "Here we stand: grounded by gratitude, surrounded by family, and ready to walk together through every season that life brings. The past was beautiful, but our story has only just begun.",
    date: "November 2026",
    imageUrl: "https://images.unsplash.com/photo-1522673607200-164d1b6ce486?auto=format&fit=crop&w=1200&q=85",
    imageAlt: "Walking together into forever",
    quote: "“To love and to be loved is to feel the sun from both sides.”"
  }
];

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: "g1",
    title: "Golden Hour Embrace",
    category: "couple",
    imageUrl: "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=1400&q=85",
    caption: "The golden warmth of late summer on the estate grounds.",
    aspect: "tall",
    location: "Hudson Valley, NY"
  },
  {
    id: "g2",
    title: "The Heirloom Diamond Ring",
    category: "details",
    imageUrl: "https://images.unsplash.com/photo-1605100804763-247f67b3557e?auto=format&fit=crop&w=1200&q=85",
    caption: "Hand-set antique oval diamond with delicate botanical band.",
    aspect: "square",
    location: "Positano, Italy"
  },
  {
    id: "g3",
    title: "The Glasshouse Conservatory",
    category: "details",
    imageUrl: "https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=1400&q=85",
    caption: "Our celebration venue bathed in natural conservatory light.",
    aspect: "wide",
    location: "Stone Hill Estate"
  },
  {
    id: "g4",
    title: "Intimate Whisper",
    category: "couple",
    imageUrl: "https://images.unsplash.com/photo-1583939003579-730e3918a45a?auto=format&fit=crop&w=1200&q=85",
    caption: "Quiet glances between chapters.",
    aspect: "tall",
    location: "Long Island Sound"
  },
  {
    id: "g5",
    title: "Dusty Rose & Garden Florals",
    category: "details",
    imageUrl: "https://images.unsplash.com/photo-1519225421980-715cb0215aed?auto=format&fit=crop&w=1200&q=85",
    caption: "Heirloom garden roses and eucalyptus foliage for our celebration.",
    aspect: "square",
    location: "Floral Studio"
  },
  {
    id: "g6",
    title: "A Toast to Forever",
    category: "candid",
    imageUrl: "https://images.unsplash.com/photo-1526047932273-341f2a7631f9?auto=format&fit=crop&w=1200&q=85",
    caption: "Vintage champagne flutes raised in intimate celebration.",
    aspect: "square",
    location: "Private Terrace"
  },
  {
    id: "g7",
    title: "Wildflower Walk",
    category: "couple",
    imageUrl: "https://images.unsplash.com/photo-1522673607200-164d1b6ce486?auto=format&fit=crop&w=1200&q=85",
    caption: "Walking hand in hand through the late autumn meadows.",
    aspect: "wide",
    location: "Catskill Foothills"
  },
  {
    id: "g8",
    title: "Candlelit Tablescape",
    category: "details",
    imageUrl: "https://images.unsplash.com/photo-1469371670807-013ccf25f16a?auto=format&fit=crop&w=1400&q=85",
    caption: "Linen, taper candles, and warm ceramics for our evening dinner.",
    aspect: "wide",
    location: "Conservatory Atrium"
  },
  {
    id: "g9",
    title: "Sunset Horizon",
    category: "proposal",
    imageUrl: "https://images.unsplash.com/photo-1470240731273-7821a6eeb6bd?auto=format&fit=crop&w=1400&q=85",
    caption: "The cliffside horizon moments after she said yes.",
    aspect: "tall",
    location: "Positano Balcony"
  },
  {
    id: "g10",
    title: "Laughter With Loved Ones",
    category: "candid",
    imageUrl: "https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&w=1400&q=85",
    caption: "Pure unscripted laughter with family upon sharing the news.",
    aspect: "wide",
    location: "Family Dinner"
  },
  {
    id: "g11",
    title: "The Hand We Hold",
    category: "proposal",
    imageUrl: "https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=1200&q=85",
    caption: "Clasping hands overlooking the sea, promised forever.",
    aspect: "tall",
    location: "Amalfi Coast"
  },
  {
    id: "g12",
    title: "Tender Light",
    category: "couple",
    imageUrl: "https://images.unsplash.com/photo-1537633552985-df8429e8048b?auto=format&fit=crop&w=1200&q=85",
    caption: "Soft morning light in our sunlit living room.",
    aspect: "square",
    location: "Our Loft"
  }
];

export const SOUNDTRACK_TRACKS: TrackItem[] = [
  {
    id: "track-1",
    title: "Beyond",
    artist: "Leon Bridges",
    album: "Good Thing",
    year: "2018",
    note: "The song playing when Daniel first asked Amelia to dance in their sunlit kitchen.",
    duration: "4:00"
  },
  {
    id: "track-2",
    title: "Come Away With Me",
    artist: "Norah Jones",
    album: "Come Away With Me",
    year: "2002",
    note: "Our rainy Tuesday café soundtrack that started our first conversation.",
    duration: "3:18"
  },
  {
    id: "track-3",
    title: "Songbird",
    artist: "Fleetwood Mac",
    album: "Rumours",
    year: "1977",
    note: "The acoustic melody floating through Positano on the night we said yes.",
    duration: "3:20"
  },
  {
    id: "track-4",
    title: "Simply the Best (Acoustic)",
    artist: "Noah Reid",
    album: "Gemini",
    year: "2020",
    note: "Played softly on road trips across the Hudson Valley.",
    duration: "3:02"
  },
  {
    id: "track-5",
    title: "La Vie En Rose",
    artist: "Louis Armstrong",
    album: "Satchmo Serenades",
    year: "1950",
    note: "A timeless vinyl favorite we spin on Sunday mornings.",
    duration: "3:24"
  }
];

export const HUDSON_VALLEY_GUIDE: GuidePlace[] = [
  {
    id: "place-1",
    category: "Morning Espresso",
    name: "Little King Bakery & Café",
    town: "Beacon, NY",
    address: "199 Main Street, Beacon",
    note: "Our favorite Saturday sanctuary for cortados, cardamom morning buns, and design publications.",
    imageUrl: "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=800&q=80",
    tip: "Order the wild lavender latte and sit by the back courtyard window."
  },
  {
    id: "place-2",
    category: "Scenic Nature Trail",
    name: "Poet’s Walk Romantic Landscape",
    town: "Red Hook, NY",
    address: "Route 199, Red Hook",
    note: "Winding pastoral trails celebrated by 19th-century poets, overlooking the rolling Hudson River.",
    imageUrl: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80",
    tip: "Arrive at 4:30 PM for breathtaking golden hour light across the ridge."
  },
  {
    id: "place-3",
    category: "Antiques & Books",
    name: "Warren Street Heritage Quarter",
    town: "Hudson, NY",
    address: "Warren Street, Historic District",
    note: "A mile of mid-century architectural galleries, rare books, and curated ceramic workshops.",
    imageUrl: "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80",
    tip: "Don't miss the tucked-away garden atrium at Spotty Dog Books."
  },
  {
    id: "place-4",
    category: "Evening Fireside Drinks",
    name: "The Tavern at Beekman Arms",
    town: "Rhinebeck, NY",
    address: "6387 Mill Street, Rhinebeck",
    note: "America's oldest continuously operating inn (est. 1766) with roaring stone hearths and spiced bourbon cider.",
    imageUrl: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80",
    tip: "Try the smoky Hudson Maple Manhattan beside the library fireplace."
  }
];

export const GUEST_FAQS: FaqItem[] = [
  {
    category: "Celebration",
    question: "Can I bring a plus-one?",
    answer: "Due to the intimate greenhouse capacity of the Glasshouse Conservatory, plus-ones are designated specifically on your formal invitation envelope and RSVP form. If your RSVP indicates 'Amelia Montgomery & Guest', you are warmly invited to bring a companion!"
  },
  {
    category: "Celebration",
    question: "Are children invited to the celebration?",
    answer: "While we adore your little ones, our engagement celebration will be an adults-only evening to allow all guests, including parents, an unhurried night of relaxation and revelry."
  },
  {
    category: "Ceremony",
    question: "What is your photography policy during the ceremony?",
    answer: "We kindly request an 'unplugged' ceremony. We invite you to be fully present with us as we exchange vows and blessings. Our professional editorial photographer and cinematographer will capture every moment, which we will joyfully share with you afterward! During cocktail hour and the evening reception, photographs are warmly welcomed."
  },
  {
    category: "Attire & Weather",
    question: "What will the weather be like in Hudson Valley in November?",
    answer: "Hudson Valley autumns are brisk and romantic, typically averaging 50°F (10°C) during late afternoon and dipping to 38°F (3°C) at night. The Conservatory is climate-controlled and heated with radiant floors and glass ceilings, but we recommend bringing a chic coat or wrap for the outdoor arrivals and garden terrace stroll."
  },
  {
    category: "Logistics",
    question: "Will transportation be provided from hotels?",
    answer: "Yes! Executive shuttles will depart from The Beekman Arms Hotel in Rhinebeck at 4:15 PM and 4:35 PM, returning continuously from 9:30 PM until midnight. Complimentary valet parking is also provided on-site for those driving directly."
  },
  {
    category: "Dietary",
    question: "How are dietary allergies and preferences accommodated?",
    answer: "Our culinary team from Stone Hill Estate crafts a bespoke seasonal three-course dinner. Vegetarian, vegan, gluten-free, dairy-free, and nut-allergy options will be provided seamlessly. Please ensure you indicate your dietary needs on the RSVP form."
  }
];

export const HONEYMOON_EXPERIENCES: HoneymoonItem[] = [
  {
    id: "gift-1",
    title: "Kyoto Heritage Ryokan & Onsen Stay",
    destination: "Kyoto, Japan",
    description: "Two nights in a tranquil wooden ryokan in the Arashiyama bamboo forest with traditional multi-course kaiseki dinner.",
    amount: "$350",
    imageUrl: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=800&q=80",
    tag: "Honeymoon Escape"
  },
  {
    id: "gift-2",
    title: "Cliffside Dinner Overlooking Ravello",
    destination: "Amalfi Coast, Italy",
    description: "An intimate candlelit dinner among terraced lemon groves and sea breezes where we reminisce about our proposal.",
    amount: "$220",
    imageUrl: "https://images.unsplash.com/photo-1533105079780-92b9be482077?auto=format&fit=crop&w=800&q=80",
    tag: "Romantic Evening"
  },
  {
    id: "gift-3",
    title: "Artisanal Ceramic Workshop",
    destination: "Tokyo, Japan",
    description: "A private pottery masterclass learning centuries-old wheel throwing to create handcrafted heirloom dinnerware for our home.",
    amount: "$175",
    imageUrl: "https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?auto=format&fit=crop&w=800&q=80",
    tag: "Shared Craft"
  },
  {
    id: "gift-4",
    title: "Tuscan Organic Vineyard Reserve Tasting",
    destination: "Val d'Orcia, Tuscany",
    description: "Walking century-old olive groves, tasting barrel-aged Brunello di Montalcino, and dining at a farmhouse table.",
    amount: "$190",
    imageUrl: "https://images.unsplash.com/photo-1506377247377-2a5b3b417ebb?auto=format&fit=crop&w=800&q=80",
    tag: "Harvest & Wine"
  }
];

export const INITIAL_TOASTS: ToastItem[] = [
  {
    id: "t1",
    author: "Charlotte Montgomery",
    relationship: "Maid of Honor & Sister",
    message: "From the very first day Amelia told me about that coffee in Greenwich Village, her eyes had a light I had never seen before. Daniel, you are the easiest brother to love. May your years together be filled with laughter and endless adventures.",
    date: "September 12, 2026"
  },
  {
    id: "t2",
    author: "Julian Vance",
    relationship: "Best Man & Lifelong Friend",
    message: "I have known Daniel since university dorm days. He has always been steady and thoughtful, but with Amelia, he became the happiest version of himself. Here’s to the couple that makes true love look as effortless as breathing.",
    date: "September 18, 2026"
  },
  {
    id: "t3",
    author: "Eleanor & Arthur",
    relationship: "The Parents",
    message: "Watching our children grow, find one another, and build a partnership rooted in mutual respect and kindness is the greatest gift of our lives. You have our blessing today, tomorrow, and for all the days of your lives.",
    date: "September 24, 2026"
  },
  {
    id: "t4",
    author: "Dr. Marcus & Vivienne Leigh",
    relationship: "Close Friends",
    message: "Raising a toast from afar until November 14th! The way you look at each other across crowded rooms is pure poetry. We cannot wait to dance under the conservatory stars with you two!",
    date: "October 2, 2026"
  }
];

export const IMAGE_ATTRIBUTIONS = [
  { photographer: "Nathan Dumlao", source: "Unsplash", theme: "Editorial couple and warm outdoor lighting" },
  { photographer: "Kari Shea", source: "Unsplash", theme: "Fine art engagement and celebration details" },
  { photographer: "Jeremy Wong", source: "Unsplash", theme: "Romantic couple portraits and natural sunlight" },
  { photographer: "Alvin Mahmudov", source: "Unsplash", theme: "Heirloom jewelry and ring details" },
  { photographer: "Scott Webb", source: "Unsplash", theme: "Botanical florals and conservatory architecture" }
];
