import React from 'react';
import { HOME_EDITORIAL, COUPLE_DATA, HOME_DATE } from './homeData';
import { OptimizedImage } from '../../components/common/OptimizedImage';
import { FloralDivider } from '../../components/common/FloralDivider';
import { TiltCard } from '../../components/common/TiltCard';
import { BotanicalVine, RosePetal, PhotoFloralFlourish } from '../../components/common/FloralDecorations';

export const EngagementIntro: React.FC = () => {
  return (
    <section
      id="introduction"
      className="py-24 md:py-36 px-6 md:px-12 bg-[#F8F5F0] border-t border-[#E5DFD5]/60 overflow-hidden relative"
    >
      {/* Botanical Corner Vines & Drifting Petals */}
      <BotanicalVine position="top-right" size="lg" opacity={0.6} />
      <BotanicalVine position="bottom-left" size="md" opacity={0.5} />
      <div className="absolute top-24 right-12 pointer-events-none">
        <RosePetal variant={2} rotate={25} scale={0.9} />
      </div>
      <div className="absolute bottom-20 left-10 pointer-events-none">
        <RosePetal variant={1} rotate={-35} scale={0.85} />
      </div>
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Editorial Content */}
          <div className="lg:col-span-6 space-y-8 pr-0 lg:pr-6">
            <div className="space-y-3">
              <span className="text-[11px] tracking-[0.24em] uppercase text-[#B98F91] font-semibold">
                01 / The Prelude
              </span>
              <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl text-[#20201E] font-normal tracking-tight leading-[1.08]">
                {HOME_EDITORIAL.introHeading}
              </h2>
            </div>

            <div className="space-y-5 text-[#6F6A63] text-base md:text-lg leading-relaxed font-light">
              <p>
                {HOME_EDITORIAL.introText1}
              </p>
              <p>
                {HOME_EDITORIAL.introText2}
              </p>
            </div>

            {/* Pull Quote Box */}
            <div className="border-l-2 border-[#D8C5A5] pl-6 py-2 my-6">
              <blockquote className="font-serif italic text-xl md:text-2xl text-[#20201E] font-light leading-relaxed">
                {HOME_EDITORIAL.coupleQuote}
              </blockquote>
              <cite className="block text-xs uppercase tracking-[0.2em] text-[#8C867E] not-italic mt-3 font-sans">
                — {COUPLE_DATA.brideFirst} & {COUPLE_DATA.groomFirst}
              </cite>
            </div>

            <FloralDivider variant="diamond" className="justify-start my-6" />

            <div className="flex items-center gap-6 pt-2">
              <div>
                <span className="block text-xs uppercase tracking-widest text-[#8C867E]">
                  Engagement Place
                </span>
                <span className="font-serif text-lg text-[#20201E]">
                  {HOME_DATE.engagementLocation}
                </span>
              </div>
              <div className="h-8 w-[1px] bg-[#E5DFD5]" />
              <div>
                <span className="block text-xs uppercase tracking-widest text-[#8C867E]">
                  Celebration Date
                </span>
                <span className="font-serif text-lg text-[#20201E]">
                  November 14, 2026
                </span>
              </div>
            </div>
          </div>

          {/* Right Column: Secondary Editorial Photography with 3D Tilt */}
          <div className="lg:col-span-6 relative">
            <div className="absolute -top-4 -right-4 w-full h-full border border-[#D8C5A5]/60 pointer-events-none hidden sm:block transition-transform duration-500 hover:translate-x-1 hover:translate-y-1" />
            
            <TiltCard maxTilt={6} scale={1.02} glare={true} className="relative shadow-[0_20px_45px_rgba(32,32,30,0.07)] border border-[#E5DFD5]/80 bg-[#EDE6DC]">
              <PhotoFloralFlourish position="top-right" className="opacity-90 z-20" />
              <PhotoFloralFlourish position="bottom-left" className="opacity-90 z-20" />
              <div className="group overflow-hidden">
                <OptimizedImage
                  src="https://images.unsplash.com/photo-1522673607200-164d1b6ce486?auto=format&fit=crop&w=1200&q=85"
                  alt="Amelia and Daniel walking together outdoors"
                  aspectRatio="4/5"
                  animation="zoom-hover"
                  cornerAccents={true}
                  curtainReveal={true}
                  className="w-full"
                  objectFit="cover"
                />
                <div className="p-4 bg-[#FAF8F5] border-t border-[#E5DFD5]/70 flex items-center justify-between text-xs text-[#8C867E]">
                  <span className="tracking-widest uppercase text-[10px] text-[#B98F91] font-semibold">Candid Editorial</span>
                  <span className="font-serif italic text-sm text-[#20201E]">Hudson Valley, New York</span>
                </div>
              </div>
            </TiltCard>
          </div>
        </div>
      </div>
    </section>
  );
};
