import React, { useState } from 'react';
import { HONEYMOON_EXPERIENCES, WISHING_WELL_META } from './wishingWellData';
import type { HoneymoonItem } from './wishingWellData';
import { OptimizedImage } from '../../components/common/OptimizedImage';
import { Gift, Heart, Check, X } from 'lucide-react';
import { TiltCard } from '../../components/common/TiltCard';
import { BotanicalVine, RosePetal, PhotoFloralFlourish } from '../../components/common/FloralDecorations';

export const WishingWell: React.FC = () => {
  const [selectedGift, setSelectedGift] = useState<HoneymoonItem | null>(null);
  const [giverName, setGiverName] = useState('');
  const [personalNote, setPersonalNote] = useState('');
  const [giftSuccess, setGiftSuccess] = useState(false);

  const handleOpenGiftModal = (gift: HoneymoonItem) => {
    setSelectedGift(gift);
    setGiftSuccess(false);
  };

  const handleConfirmGift = (e: React.FormEvent) => {
    e.preventDefault();
    setGiftSuccess(true);
    setTimeout(() => {
      setSelectedGift(null);
      setGiverName('');
      setPersonalNote('');
      setGiftSuccess(false);
    }, 2400);
  };

  return (
    <section className="py-24 md:py-36 px-6 md:px-12 bg-[#F8F5F0] border-t border-[#E5DFD5]/80 animate-fade-in relative overflow-hidden">
      {/* Botanical Corner Vines & Drifting Petals */}
      <BotanicalVine position="top-left" size="lg" opacity={0.65} />
      <BotanicalVine position="top-right" size="lg" opacity={0.6} />
      <BotanicalVine position="bottom-left" size="md" opacity={0.5} />
      <BotanicalVine position="bottom-right" size="md" opacity={0.5} />

      <div className="absolute top-36 left-8 pointer-events-none">
        <RosePetal variant={1} rotate={-15} scale={1} />
      </div>
      <div className="absolute top-52 right-12 pointer-events-none">
        <RosePetal variant={2} rotate={35} scale={0.9} />
      </div>
      <div className="absolute bottom-36 left-10 pointer-events-none">
        <RosePetal variant={3} rotate={15} scale={0.85} />
      </div>
      <div className="absolute bottom-24 right-14 pointer-events-none">
        <RosePetal variant={1} rotate={-30} scale={0.9} />
      </div>

      <div className="max-w-6xl mx-auto space-y-16">
        {/* Section Header */}
        <div className="text-center space-y-4 max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-2">
            <Gift className="w-3.5 h-3.5 text-[#B98F91]" />
            <span className="text-[11px] uppercase tracking-[0.28em] text-[#6F6A63] font-semibold">
              {WISHING_WELL_META.sectionNumber}
            </span>
          </div>
          <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl text-[#20201E] font-normal tracking-tight">
            {WISHING_WELL_META.heading}
          </h2>
          <p className="text-sm md:text-base text-[#6F6A63] font-light leading-relaxed">
            {WISHING_WELL_META.subheading}
          </p>
          <div className="w-12 h-[1px] bg-[#D8C5A5] mx-auto mt-4" />
        </div>

        {/* 4 Curated Experiential Cards Grid with 3D Tilt */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {HONEYMOON_EXPERIENCES.map((item) => (
            <TiltCard key={item.id} maxTilt={4} scale={1.02} glare={true}>
              <div className="h-full bg-[#FAF8F5] border border-[#E5DFD5] shadow-[0_4px_20px_rgba(32,32,30,0.03)] flex flex-col justify-between overflow-hidden group hover:border-[#D8C5A5] transition-all">
                <div>
                  <div className="relative overflow-hidden bg-[#EDE6DC]">
                    <PhotoFloralFlourish position="top-right" className="opacity-80 z-20" />
                    <OptimizedImage
                      src={item.imageUrl}
                      alt={item.title}
                      aspectRatio="4/3"
                      animation="zoom-hover"
                      cornerAccents={true}
                      curtainReveal={true}
                      className="w-full"
                      objectFit="cover"
                    />
                    <div className="absolute top-3 left-3 z-10 bg-[#F8F5F0]/90 backdrop-blur-sm px-2.5 py-0.5 text-[9px] uppercase tracking-widest text-[#20201E] font-semibold border border-[#E5DFD5]">
                      {item.tag}
                    </div>
                  </div>

                  <div className="p-5 space-y-2">
                    <span className="text-[10px] uppercase tracking-wider text-[#B98F91] font-medium block">
                      {item.destination}
                    </span>
                    <h3 className="font-serif text-lg text-[#20201E] leading-snug">
                      {item.title}
                    </h3>
                    <p className="text-xs text-[#6F6A63] font-light leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                </div>

                <div className="p-5 pt-0">
                  <button
                    onClick={() => handleOpenGiftModal(item)}
                    className="w-full py-2.5 border border-[#20201E] text-[#20201E] text-xs uppercase tracking-[0.16em] font-medium hover:bg-[#20201E] hover:text-[#F8F5F0] transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Heart className="w-3 h-3 text-[#B98F91]" />
                    <span>Bless Experience</span>
                  </button>
                </div>
              </div>
            </TiltCard>
          ))}
        </div>

        <p className="text-center text-xs text-[#8C867E] font-light">
          {WISHING_WELL_META.envelopeNote}
        </p>
      </div>

      {/* Gift Experience Modal */}
      {selectedGift && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-[#161514]/75 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in"
          onClick={() => setSelectedGift(null)}
        >
          <div
            className="bg-[#F8F5F0] border border-[#E5DFD5] max-w-md w-full p-6 sm:p-8 shadow-2xl relative space-y-6"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setSelectedGift(null)}
              aria-label="Close"
              className="absolute top-4 right-4 p-1.5 text-[#6F6A63] hover:text-[#20201E]"
            >
              <X className="w-5 h-5" />
            </button>

            {giftSuccess ? (
              <div className="text-center py-6 space-y-3 animate-fade-in">
                <div className="w-12 h-12 rounded-full bg-[#9BA595]/20 text-[#9BA595] flex items-center justify-center mx-auto">
                  <Check className="w-6 h-6" />
                </div>
                <h4 className="font-serif text-2xl text-[#20201E]">Heartfelt Gratitude!</h4>
                <p className="text-xs text-[#6F6A63] leading-relaxed">
                  Thank you, <strong className="text-[#20201E]">{giverName || 'Dear Friend'}</strong>. Your generous token for “{selectedGift.title}” has been registered with love.
                </p>
              </div>
            ) : (
              <form onSubmit={handleConfirmGift} className="space-y-4">
                <div className="space-y-1">
                  <span className="text-[10px] uppercase tracking-wider text-[#B98F91] font-medium">
                    Honeymoon Blessing
                  </span>
                  <h4 className="font-serif text-2xl text-[#20201E]">
                    {selectedGift.title}
                  </h4>
                  <p className="text-xs text-[#6F6A63]">
                    {selectedGift.destination}
                  </p>
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] uppercase tracking-wider text-[#6F6A63] block">
                    Your Name(s) *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Eleanor & Marcus"
                    value={giverName}
                    onChange={(e) => setGiverName(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-[#E5DFD5] text-sm text-[#20201E] focus:outline-none focus:border-[#20201E]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] uppercase tracking-wider text-[#6F6A63] block">
                    Personal Note to Amelia & Daniel
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Wishing you a lifetime of joy..."
                    value={personalNote}
                    onChange={(e) => setPersonalNote(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-[#E5DFD5] text-sm text-[#20201E] focus:outline-none focus:border-[#20201E] resize-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-[#20201E] text-[#F8F5F0] text-xs uppercase tracking-[0.2em] font-medium hover:bg-[#383733] transition-colors mt-2"
                >
                  Send Blessing & Tribute
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </section>
  );
};
