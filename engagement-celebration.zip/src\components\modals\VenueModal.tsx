import React, { useEffect, useCallback } from 'react';
import { X, MapPin, Navigation, Car, Bus, Phone, Mail } from 'lucide-react';
import { SITE_CONFIG } from '../../data/engagementContent';

interface VenueModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const VenueModal: React.FC<VenueModalProps> = ({ isOpen, onClose }) => {
  const { venue } = SITE_CONFIG;

  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    },
    [onClose]
  );

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, handleKeyDown]);

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Venue and Directions Details"
      className="fixed inset-0 z-50 bg-[#161514]/75 backdrop-blur-sm flex items-center justify-center p-4 md:p-6 animate-fade-in"
      onClick={onClose}
    >
      <div
        className="relative bg-[#F8F5F0] border border-[#E5DFD5] max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 md:p-10 shadow-2xl space-y-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          aria-label="Close modal"
          className="absolute top-6 right-6 p-2 rounded-full border border-[#E5DFD5] hover:bg-[#EDE6DC] text-[#6F6A63] hover:text-[#20201E] transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="space-y-2 pr-8">
          <span className="text-[11px] uppercase tracking-[0.24em] text-[#B98F91] font-semibold">
            Venue & Guest Logistics
          </span>
          <h3 className="font-serif text-3xl md:text-4xl text-[#20201E] font-normal">
            {venue.name}
          </h3>
          <p className="font-serif italic text-lg text-[#6F6A63]">
            {venue.estate}
          </p>
        </div>

        {/* Address & Quick Maps Link */}
        <div className="p-4 bg-[#FAF8F5] border border-[#E5DFD5] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <MapPin className="w-5 h-5 text-[#B98F91] shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-[#20201E]">{venue.address}</p>
              <p className="text-xs text-[#6F6A63]">{venue.cityStateZip}</p>
            </div>
          </div>

          <a
            href={venue.googleMapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#20201E] text-[#F8F5F0] text-xs uppercase tracking-wider hover:bg-[#3A3935] transition-colors shrink-0"
          >
            <Navigation className="w-3.5 h-3.5 text-[#D8C5A5]" />
            <span>Open in Google Maps</span>
          </a>
        </div>

        {/* Simulated Map Visual Card */}
        <div className="relative h-48 sm:h-56 w-full bg-[#E8E1D5] border border-[#E5DFD5] overflow-hidden flex flex-col items-center justify-center p-6 text-center">
          <div className="w-12 h-12 rounded-full bg-[#F8F5F0] border border-[#D8C5A5] flex items-center justify-center shadow-md mb-2">
            <MapPin className="w-6 h-6 text-[#B98F91]" />
          </div>
          <span className="font-serif text-lg text-[#20201E]">Stone Hill Estate Conservatory</span>
          <span className="text-xs text-[#6F6A63]">Hudson Valley, New York</span>
          <a
            href={venue.googleMapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-3 text-xs underline text-[#20201E] hover:text-[#B98F91]"
          >
            Click to view full satellite view & directions →
          </a>
        </div>

        {/* Parking & Transportation Details */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div className="space-y-2 p-4 bg-[#F2ECE4] border border-[#E5DFD5]">
            <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-[#20201E] font-medium">
              <Car className="w-4 h-4 text-[#9BA595]" />
              <span>Valet & Parking</span>
            </div>
            <p className="text-xs text-[#6F6A63] leading-relaxed">
              {venue.valetNote}
            </p>
          </div>

          <div className="space-y-2 p-4 bg-[#F2ECE4] border border-[#E5DFD5]">
            <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-[#20201E] font-medium">
              <Bus className="w-4 h-4 text-[#D8C5A5]" />
              <span>Guest Shuttles</span>
            </div>
            <p className="text-xs text-[#6F6A63] leading-relaxed">
              {venue.shuttleNote}
            </p>
          </div>
        </div>

        {/* Accommodations & Inquiries */}
        <div className="border-t border-[#E5DFD5] pt-6 space-y-4">
          <h4 className="font-serif text-xl text-[#20201E]">Recommended Accommodations</h4>
          <p className="text-xs text-[#6F6A63] leading-relaxed">
            A room block has been reserved under “Montgomery-Sterling Celebration” at The Beekman Arms Hotel (Rhinebeck) and Troutbeck (Amenia). Please reserve by October 1st for preferred rates.
          </p>

          <div className="flex flex-wrap items-center gap-6 pt-2 text-xs text-[#8C867E]">
            <span className="inline-flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-[#B98F91]" />
              {venue.phone}
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-[#B98F91]" />
              {venue.email}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
