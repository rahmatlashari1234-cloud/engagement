import React from 'react';
import { FAMILIES_DATA } from './familiesData';
import { OptimizedImage } from '../../components/common/OptimizedImage';
import { FloralDivider } from '../../components/common/FloralDivider';
import { TiltCard } from '../../components/common/TiltCard';
import { BotanicalVine, RosePetal, PhotoFloralFlourish } from '../../components/common/FloralDecorations';

export const Families: React.FC = () => {
  return (
    <section className="py-24 md:py-36 px-6 md:px-12 bg-[#F8F5F0] border-t border-[#E5DFD5]/60 animate-fade-in relative overflow-hidden">
      {/* Botanical Corner Vines & Drifting Petals */}
      <BotanicalVine position="top-left" size="lg" opacity={0.65} />
      <BotanicalVine position="top-right" size="lg" opacity={0.6} />
      <BotanicalVine position="bottom-left" size="md" opacity={0.5} />
      <BotanicalVine position="bottom-right" size="md" opacity={0.5} />

      <div className="absolute top-36 left-8 pointer-events-none">
        <RosePetal variant={1} rotate={-15} scale={1} />
      </div>
      <div className="absolute top-52 right-12 pointer-events-none">
        <RosePetal variant={2} rotate={35} scale={0.9} />
      </div>
      <div className="absolute bottom-32 left-10 pointer-events-none">
        <RosePetal variant={3} rotate={15} scale={0.85} />
      </div>
      <div className="absolute bottom-24 right-14 pointer-events-none">
        <RosePetal variant={1} rotate={-30} scale={0.9} />
      </div>
      <div className="max-w-5xl mx-auto">
        {/* Section Header */}
        <div className="text-center space-y-4 mb-16 md:mb-24">
          <span className="text-[11px] tracking-[0.26em] uppercase text-[#B98F91] font-semibold">
            Heritage & Gratitude
          </span>
          <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl text-[#20201E] font-normal tracking-tight">
            {FAMILIES_DATA.heading}
          </h2>
          <p className="max-w-2xl mx-auto text-sm md:text-base text-[#6F6A63] font-light leading-relaxed">
            {FAMILIES_DATA.subheading}
          </p>
          <FloralDivider variant="diamond" className="my-6" />
        </div>

        {/* Family Quote */}
        <div className="max-w-3xl mx-auto text-center mb-16 md:mb-20 px-4">
          <p className="font-serif italic text-xl md:text-2xl text-[#20201E] font-light leading-relaxed">
            {FAMILIES_DATA.quote}
          </p>
        </div>

        {/* Respectful Family Introduction Columns */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 md:gap-16">
          {/* Bride's Family */}
          <div className="space-y-6 text-center md:text-left">
            <TiltCard maxTilt={4} scale={1.02} glare={true}>
              <div className="overflow-hidden border border-[#E5DFD5] bg-[#EDE6DC] shadow-md group relative">
                <PhotoFloralFlourish position="top-right" className="opacity-85 z-20" />
                <OptimizedImage
                  src={FAMILIES_DATA.brideParents.imageUrl}
                  alt={FAMILIES_DATA.brideParents.imageAlt}
                  aspectRatio="16/11"
                  animation="zoom-hover"
                  cornerAccents={true}
                  curtainReveal={true}
                  className="w-full"
                  objectFit="cover"
                />
              </div>
            </TiltCard>
            <div className="space-y-2 pt-2">
              <span className="text-xs uppercase tracking-[0.2em] text-[#B98F91] font-semibold block">
                {FAMILIES_DATA.brideParents.title}
              </span>
              <h3 className="font-serif text-2xl md:text-3xl text-[#20201E] font-normal">
                {FAMILIES_DATA.brideParents.names}
              </h3>
              <p className="text-sm text-[#8C867E] tracking-wider uppercase font-sans">
                {FAMILIES_DATA.brideParents.note}
              </p>
              <p className="text-sm text-[#6F6A63] font-light leading-relaxed pt-2">
                With endless gratitude for a lifetime of unconditional love, laughter at every dinner table, and showing us the true meaning of an enduring marriage.
              </p>
            </div>
          </div>

          {/* Groom's Family */}
          <div className="space-y-6 text-center md:text-left">
            <TiltCard maxTilt={4} scale={1.02} glare={true}>
              <div className="overflow-hidden border border-[#E5DFD5] bg-[#EDE6DC] shadow-md group relative">
                <PhotoFloralFlourish position="top-left" className="opacity-85 z-20" />
                <OptimizedImage
                  src={FAMILIES_DATA.groomParents.imageUrl}
                  alt={FAMILIES_DATA.groomParents.imageAlt}
                  aspectRatio="16/11"
                  animation="zoom-hover"
                  cornerAccents={true}
                  curtainReveal={true}
                  className="w-full"
                  objectFit="cover"
                />
              </div>
            </TiltCard>
            <div className="space-y-2 pt-2">
              <span className="text-xs uppercase tracking-[0.2em] text-[#D8C5A5] font-semibold block">
                {FAMILIES_DATA.groomParents.title}
              </span>
              <h3 className="font-serif text-2xl md:text-3xl text-[#20201E] font-normal">
                {FAMILIES_DATA.groomParents.names}
              </h3>
              <p className="text-sm text-[#8C867E] tracking-wider uppercase font-sans">
                {FAMILIES_DATA.groomParents.note}
              </p>
              <p className="text-sm text-[#6F6A63] font-light leading-relaxed pt-2">
                With heartfelt thanks for steadfast guidance, endless encouragement, and opening your arms with warmth to embrace our new shared chapter.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
