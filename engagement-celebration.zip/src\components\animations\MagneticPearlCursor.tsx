import React, { useEffect, useState, useRef } from 'react';

export const MagneticPearlCursor: React.FC = () => {
  const [pos, setPos] = useState({ x: -100, y: -100 });
  const [trailerPos, setTrailerPos] = useState({ x: -100, y: -100 });
  const [isHovered, setIsHovered] = useState(false);
  const [isClicking, setIsClicking] = useState(false);
  const [isVisible, setIsVisible] = useState(false);

  const trailerPosRef = useRef({ x: -100, y: -100 });
  const targetPosRef = useRef({ x: -100, y: -100 });
  const animFrameRef = useRef<number | null>(null);

  useEffect(() => {
    // Only enable on non-touch devices
    if (window.matchMedia('(pointer: coarse)').matches) return;

    const handleMouseMove = (e: MouseEvent) => {
      setIsVisible(true);
      targetPosRef.current = { x: e.clientX, y: e.clientY };
      setPos({ x: e.clientX, y: e.clientY });

      // Check if hovering interactive target
      const target = e.target as HTMLElement | null;
      if (
        target &&
        (target.closest('button') ||
          target.closest('a') ||
          target.closest('[role="button"]') ||
          target.closest('.cursor-pointer') ||
          target.closest('input'))
      ) {
        setIsHovered(true);
      } else {
        setIsHovered(false);
      }
    };

    const handleMouseDown = () => setIsClicking(true);
    const handleMouseUp = () => setIsClicking(false);
    const handleMouseLeave = () => setIsVisible(false);

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);
    document.addEventListener('mouseleave', handleMouseLeave);

    // Smooth spring physics for cursor halo
    const loop = () => {
      const current = trailerPosRef.current;
      const target = targetPosRef.current;
      const ease = 0.18; // Spring damping

      current.x += (target.x - current.x) * ease;
      current.y += (target.y - current.y) * ease;

      setTrailerPos({ x: current.x, y: current.y });
      animFrameRef.current = requestAnimationFrame(loop);
    };

    animFrameRef.current = requestAnimationFrame(loop);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
      document.removeEventListener('mouseleave', handleMouseLeave);
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, []);

  if (!isVisible) return null;

  return (
    <div className="pointer-events-none fixed inset-0 z-[99999] overflow-hidden select-none">
      {/* 1. CENTER BRIDAL PEARL DOT */}
      <div
        className="fixed top-0 left-0 w-2.5 h-2.5 rounded-full bg-[#FBF9F5] border border-[#D8C5A5] shadow-[0_0_8px_rgba(216,197,165,0.8)] -translate-x-1/2 -translate-y-1/2 transition-transform duration-75"
        style={{
          transform: `translate3d(${pos.x}px, ${pos.y}px, 0) scale(${isClicking ? 0.75 : 1})`,
        }}
      />

      {/* 2. TRAILING SPRING GOLD HALO RING */}
      <div
        className={`fixed top-0 left-0 rounded-full border pointer-events-none transition-all duration-300 -translate-x-1/2 -translate-y-1/2 ${
          isHovered
            ? 'w-10 h-10 border-[#B98F91] bg-[#B98F91]/8 shadow-[0_0_16px_rgba(185,143,145,0.4)] scale-110'
            : 'w-7 h-7 border-[#D8C5A5]/70 bg-[#FAF8F5]/5 shadow-[0_0_10px_rgba(216,197,165,0.3)] scale-100'
        }`}
        style={{
          transform: `translate3d(${trailerPos.x}px, ${trailerPos.y}px, 0) scale(${
            isClicking ? 0.85 : isHovered ? 1.25 : 1
          })`,
        }}
      />

      {/* 3. CLICK PULSE WAVE */}
      {isClicking && (
        <div
          className="fixed top-0 left-0 w-12 h-12 rounded-full border border-[#D8C5A5] animate-ping -translate-x-1/2 -translate-y-1/2 opacity-60"
          style={{
            transform: `translate3d(${pos.x}px, ${pos.y}px, 0)`,
          }}
        />
      )}
    </div>
  );
};
