import React from 'react';

interface MonogramCrestProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  variant?: 'light' | 'dark' | 'gold';
}

export const MonogramCrest: React.FC<MonogramCrestProps> = ({
  className = '',
  size = 'md',
  variant = 'gold',
}) => {
  let sizeClass = 'w-24 h-24';
  if (size === 'sm') sizeClass = 'w-14 h-14';
  if (size === 'lg') sizeClass = 'w-36 h-36';

  let colorStroke = '#D8C5A5';
  let colorFill = '#B98F91';
  let textFill = '#20201E';

  if (variant === 'light') {
    colorStroke = '#FAF8F5';
    colorFill = '#D8C5A5';
    textFill = '#FAF8F5';
  } else if (variant === 'dark') {
    colorStroke = '#6F6A63';
    colorFill = '#20201E';
    textFill = '#20201E';
  }

  return (
    <div className={`relative inline-flex items-center justify-center ${sizeClass} ${className}`}>
      <svg
        viewBox="0 0 120 120"
        className="w-full h-full"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Outer Fine Laurel Botanical Wreath */}
        <circle
          cx="60"
          cy="60"
          r="54"
          stroke={colorStroke}
          strokeWidth="0.8"
          strokeDasharray="2 2"
          opacity="0.6"
        />

        {/* Left Olive Branch Laurel */}
        <path
          d="M 60 14 C 42 16, 20 34, 18 60 C 16 82, 34 102, 60 106"
          stroke={colorStroke}
          strokeWidth="1.2"
          strokeLinecap="round"
        />
        {/* Left Leaves */}
        <path d="M 45 22 C 40 20, 36 24, 40 28 C 43 27, 45 25, 45 22 Z" fill={colorFill} opacity="0.7" />
        <path d="M 30 36 C 24 35, 22 41, 28 44 C 30 42, 31 38, 30 36 Z" fill={colorFill} opacity="0.7" />
        <path d="M 20 56 C 14 57, 14 65, 20 67 C 22 64, 22 59, 20 56 Z" fill={colorFill} opacity="0.7" />
        <path d="M 24 78 C 20 81, 23 88, 29 86 C 29 83, 27 80, 24 78 Z" fill={colorFill} opacity="0.7" />
        <path d="M 38 96 C 36 100, 42 104, 46 100 C 44 98, 41 96, 38 96 Z" fill={colorFill} opacity="0.7" />

        {/* Right Olive Branch Laurel */}
        <path
          d="M 60 14 C 78 16, 100 34, 102 60 C 104 82, 86 102, 60 106"
          stroke={colorStroke}
          strokeWidth="1.2"
          strokeLinecap="round"
        />
        {/* Right Leaves */}
        <path d="M 75 22 C 80 20, 84 24, 80 28 C 77 27, 75 25, 75 22 Z" fill={colorFill} opacity="0.7" />
        <path d="M 90 36 C 96 35, 98 41, 92 44 C 90 42, 89 38, 90 36 Z" fill={colorFill} opacity="0.7" />
        <path d="M 100 56 C 106 57, 106 65, 100 67 C 98 64, 98 59, 100 56 Z" fill={colorFill} opacity="0.7" />
        <path d="M 96 78 C 100 81, 97 88, 91 86 C 91 83, 93 80, 96 78 Z" fill={colorFill} opacity="0.7" />
        <path d="M 82 96 C 84 100, 78 104, 74 100 C 76 98, 79 96, 82 96 Z" fill={colorFill} opacity="0.7" />

        {/* Small Top Diamond Accent */}
        <polygon points="60,8 62,11 60,14 58,11" fill={colorStroke} />
        {/* Small Bottom Star Accent */}
        <circle cx="60" cy="107" r="1.5" fill={colorStroke} />

        {/* Interlocking Monogram Typography */}
        <text
          x="46"
          y="68"
          fontFamily="Cormorant Garamond, Georgia, serif"
          fontSize="30"
          fontWeight="400"
          fill={textFill}
          textAnchor="middle"
        >
          A
        </text>
        <text
          x="59"
          y="66"
          fontFamily="Cormorant Garamond, Georgia, serif"
          fontSize="18"
          fontStyle="italic"
          fill={colorFill}
          textAnchor="middle"
        >
          &
        </text>
        <text
          x="74"
          y="68"
          fontFamily="Cormorant Garamond, Georgia, serif"
          fontSize="30"
          fontWeight="400"
          fill={textFill}
          textAnchor="middle"
        >
          D
        </text>
      </svg>
    </div>
  );
};
