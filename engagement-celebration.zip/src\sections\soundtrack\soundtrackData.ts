export interface TrackItem {
  id: string;
  title: string;
  artist: string;
  album: string;
  year: string;
  note: string;
  duration: string;
}

export const SOUNDTRACK_META = {
  sectionNumber: "Side A • 33 ⅓ RPM",
  heading: "Songs Between Moments",
  subheading: "The vinyl records and acoustic melodies that accompanied our quiet coffee mornings, midnight road trips, and the night we said yes.",
  spotifyUrl: "https://open.spotify.com",
};

export const SOUNDTRACK_TRACKS: TrackItem[] = [
  {
    id: "track-1",
    title: "Beyond",
    artist: "Leon Bridges",
    album: "Good Thing",
    year: "2018",
    note: "The song playing when Daniel first asked Amelia to dance in their sunlit kitchen.",
    duration: "4:00"
  },
  {
    id: "track-2",
    title: "Come Away With Me",
    artist: "Norah Jones",
    album: "Come Away With Me",
    year: "2002",
    note: "Our rainy Tuesday café soundtrack that started our first conversation.",
    duration: "3:18"
  },
  {
    id: "track-3",
    title: "Songbird",
    artist: "Fleetwood Mac",
    album: "Rumours",
    year: "1977",
    note: "The acoustic melody floating through Positano on the night we said yes.",
    duration: "3:20"
  },
  {
    id: "track-4",
    title: "Simply the Best (Acoustic)",
    artist: "Noah Reid",
    album: "Gemini",
    year: "2020",
    note: "Played softly on road trips across the Hudson Valley.",
    duration: "3:02"
  },
  {
    id: "track-5",
    title: "La Vie En Rose",
    artist: "Louis Armstrong",
    album: "Satchmo Serenades",
    year: "1950",
    note: "A timeless vinyl favorite we spin on Sunday mornings.",
    duration: "3:24"
  }
];
