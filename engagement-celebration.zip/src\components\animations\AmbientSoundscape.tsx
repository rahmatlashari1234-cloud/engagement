import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Volume2, Music, Sparkles } from 'lucide-react';

export const AmbientSoundscape: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume] = useState(0.25);
  const [rippleKey, setRippleKey] = useState(0);

  const audioCtxRef = useRef<AudioContext | null>(null);
  const isPlayingRef = useRef(false);
  const loopTimeoutRef = useRef<number | null>(null);

  // Romantic Pentatonic Harp & Celesta Note Frequencies (D Major / A Major Romance)
  // D4, F#4, A4, B4, D5, E5, F#5, A5
  const notes = [293.66, 369.99, 440.0, 493.88, 587.33, 659.25, 739.99, 880.0];

  const playHarpPluck = useCallback((freq: number, time: number, ctx: AudioContext, masterGain: GainNode) => {
    const osc = ctx.createOscillator();
    const noteGain = ctx.createGain();

    // Warm triangle/sine blend
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, time);

    // Harp decay envelope
    noteGain.gain.setValueAtTime(0, time);
    noteGain.gain.linearRampToValueAtTime(0.35, time + 0.02);
    noteGain.gain.exponentialRampToValueAtTime(0.0001, time + 2.2);

    osc.connect(noteGain);
    noteGain.connect(masterGain);

    osc.start(time);
    osc.stop(time + 2.3);
  }, []);

  const startArpeggioLoop = useCallback(() => {
    if (!isPlayingRef.current) return;

    try {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!audioCtxRef.current) {
        audioCtxRef.current = new AudioCtx();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }

      const masterGain = ctx.createGain();
      masterGain.gain.setValueAtTime(volume, ctx.currentTime);
      masterGain.connect(ctx.destination);

      const chordProgression = [
        [0, 2, 4, 7], // D Maj 9
        [1, 3, 5, 7], // F# min 7
        [2, 4, 6, 7], // G Maj 7
        [3, 5, 7, 6], // A Maj 9
      ];

      const playChord = (chordIdx: number) => {
        if (!isPlayingRef.current) return;
        const currentChord = chordProgression[chordIdx % chordProgression.length];

        // Trigger visual water ripple
        setRippleKey((prev) => prev + 1);

        currentChord.forEach((noteIdx, i) => {
          const freq = notes[noteIdx % notes.length];
          const pluckTime = ctx.currentTime + i * 0.28;
          playHarpPluck(freq, pluckTime, ctx, masterGain);
        });

        loopTimeoutRef.current = window.setTimeout(() => {
          playChord(chordIdx + 1);
        }, 3400);
      };

      playChord(0);
    } catch {
      // Audio safety
    }
  }, [notes, playHarpPluck, volume]);

  const toggleSoundtrack = () => {
    if (isPlaying) {
      isPlayingRef.current = false;
      setIsPlaying(false);
      if (loopTimeoutRef.current) clearTimeout(loopTimeoutRef.current);
      if (audioCtxRef.current && audioCtxRef.current.state === 'running') {
        audioCtxRef.current.suspend();
      }
    } else {
      isPlayingRef.current = true;
      setIsPlaying(true);
      startArpeggioLoop();
    }
  };

  useEffect(() => {
    return () => {
      isPlayingRef.current = false;
      if (loopTimeoutRef.current) clearTimeout(loopTimeoutRef.current);
      if (audioCtxRef.current) audioCtxRef.current.close();
    };
  }, []);

  return (
    <div className="fixed bottom-6 left-6 z-40 flex items-center gap-3">
      {/* Harmonic Water Droplet Ripples on Note Pluck */}
      {isPlaying && (
        <div key={rippleKey} className="absolute inset-0 pointer-events-none -m-3">
          <div className="w-16 h-16 rounded-full border border-[#D8C5A5]/60 animate-ping opacity-50" />
          <div className="w-20 h-20 rounded-full border border-[#B98F91]/40 animate-ping opacity-30 delay-150" />
        </div>
      )}

      {/* Floating Audio Controller Pill */}
      <button
        onClick={toggleSoundtrack}
        aria-label={isPlaying ? 'Pause Celebration Harp Soundscape' : 'Play Celebration Harp Soundscape'}
        className={`group relative flex items-center gap-2.5 px-4 py-2.5 rounded-full backdrop-blur-md border shadow-lg transition-all duration-300 cursor-pointer ${
          isPlaying
            ? 'bg-[#20201E]/90 text-[#F8F5F0] border-[#D8C5A5]/70 shadow-[0_4px_20px_rgba(216,197,165,0.35)]'
            : 'bg-[#FAF8F5]/90 text-[#20201E] border-[#D8C5A5] hover:bg-[#20201E] hover:text-[#FAF8F5]'
        }`}
      >
        {isPlaying ? (
          <>
            <div className="relative flex items-center justify-center">
              <Volume2 className="w-4 h-4 text-[#D8C5A5]" />
              <Sparkles className="w-2 h-2 text-[#F5E8C7] absolute -top-1.5 -right-1.5 animate-pulse" />
            </div>
            <span className="text-[11px] uppercase tracking-widest font-sans font-medium">
              Acoustic Harp Serenade
            </span>
            {/* Animated equalizer waves */}
            <div className="flex items-end gap-0.5 h-3 ml-1">
              <span className="w-0.5 h-3 bg-[#D8C5A5] animate-pulse" />
              <span className="w-0.5 h-2 bg-[#D8C5A5] animate-pulse delay-75" />
              <span className="w-0.5 h-3 bg-[#D8C5A5] animate-pulse delay-150" />
            </div>
          </>
        ) : (
          <>
            <Music className="w-4 h-4 text-[#B98F91]" />
            <span className="text-[11px] uppercase tracking-widest font-sans">
              Play Celebration Harp
            </span>
          </>
        )}
      </button>
    </div>
  );
};
