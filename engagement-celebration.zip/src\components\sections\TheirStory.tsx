import React from 'react';
import { STORY_MILESTONES } from '../../data/engagementContent';
import { OptimizedImage } from '../common/OptimizedImage';
import { Calendar, MapPin } from 'lucide-react';

interface TheirStoryProps {
  onImageClick?: (imageUrl: string, title: string) => void;
}

export const TheirStory: React.FC<TheirStoryProps> = ({ onImageClick }) => {
  return (
    <section id="story" className="py-24 md:py-36 px-6 md:px-12 bg-[#FAF8F5] relative">
      <div className="max-w-5xl mx-auto">
        {/* Section Header */}
        <div className="text-center space-y-4 mb-20 md:mb-28">
          <span className="text-[11px] tracking-[0.26em] uppercase text-[#B98F91] font-semibold">
            02 / Our Journey
          </span>
          <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl text-[#20201E] font-normal tracking-tight">
            How Our Story Unfolded
          </h2>
          <p className="max-w-xl mx-auto text-sm md:text-base text-[#6F6A63] font-light leading-relaxed">
            Every step, every conversation, every sunset was quietly leading us to this moment.
          </p>
          <div className="w-12 h-[1px] bg-[#D8C5A5] mx-auto mt-6" />
        </div>

        {/* Vertical Timeline Progression */}
        <div className="relative">
          {/* Subtle central vertical line */}
          <div className="absolute left-4 md:left-1/2 top-4 bottom-4 w-[1px] bg-[#E5DFD5] -translate-x-1/2 hidden md:block" />
          <div className="absolute left-6 top-4 bottom-4 w-[1px] bg-[#E5DFD5] md:hidden" />

          <div className="space-y-16 md:space-y-28">
            {STORY_MILESTONES.map((milestone, idx) => {
              const isEven = idx % 2 === 0;

              return (
                <div
                  key={milestone.id}
                  className={`relative flex flex-col md:flex-row items-center gap-8 md:gap-16 ${
                    isEven ? 'md:flex-row-reverse' : ''
                  }`}
                >
                  {/* Central Node Dot on timeline */}
                  <div className="absolute left-6 md:left-1/2 top-0 md:top-8 -translate-x-1/2 w-4 h-4 rounded-full border-2 border-[#FAF8F5] bg-[#B98F91] z-10 shadow-sm" />

                  {/* Left / Right Content Box */}
                  <div className="w-full md:w-1/2 pl-12 md:pl-0">
                    <div
                      className={`space-y-4 ${
                        isEven ? 'md:text-left md:pl-10' : 'md:text-right md:pr-10'
                      }`}
                    >
                      {/* Meta tag & date */}
                      <div
                        className={`flex flex-wrap items-center gap-2 text-xs text-[#8C867E] ${
                          isEven ? 'md:justify-start' : 'md:justify-end'
                        }`}
                      >
                        <span className="inline-flex items-center gap-1 font-medium text-[#B98F91] bg-[#B98F91]/10 px-2 py-0.5 rounded-full text-[11px] tracking-wider uppercase">
                          {milestone.tag}
                        </span>
                        <span className="inline-flex items-center gap-1 text-[11px] uppercase tracking-wider text-[#6F6A63]">
                          <Calendar className="w-3 h-3 text-[#D8C5A5]" />
                          {milestone.date}
                        </span>
                      </div>

                      {/* Milestone Title */}
                      <h3 className="font-serif text-2xl md:text-3xl text-[#20201E] font-normal leading-snug">
                        {milestone.title}
                      </h3>

                      {/* Narrative Text */}
                      <p className="text-[#6F6A63] text-sm md:text-base font-light leading-relaxed">
                        {milestone.description}
                      </p>

                      {/* Location indicator */}
                      <div
                        className={`inline-flex items-center gap-1.5 text-xs text-[#8C867E] ${
                          isEven ? 'md:justify-start' : 'md:justify-end'
                        }`}
                      >
                        <MapPin className="w-3 h-3 text-[#9BA595]" />
                        <span>{milestone.location}</span>
                      </div>
                    </div>
                  </div>

                  {/* Image Card Box */}
                  <div className="w-full md:w-1/2 pl-12 md:pl-0">
                    <div
                      onClick={() => onImageClick && onImageClick(milestone.imageUrl, milestone.title)}
                      className={`group relative overflow-hidden bg-[#EDE6DC] border border-[#E5DFD5] shadow-[0_8px_25px_rgba(32,32,30,0.04)] cursor-pointer transition-transform duration-500 hover:-translate-y-1 ${
                        isEven ? 'md:mr-10' : 'md:ml-10'
                      }`}
                    >
                      <OptimizedImage
                        src={milestone.imageUrl}
                        alt={milestone.imageAlt}
                        aspectRatio="16/10"
                        className="w-full group-hover:scale-102 transition-transform duration-700 ease-out"
                        objectFit="cover"
                      />
                      <div className="absolute inset-0 bg-[#20201E]/0 group-hover:bg-[#20201E]/20 transition-colors duration-300 flex items-center justify-center">
                        <span className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 px-3 py-1 bg-[#F8F5F0]/90 backdrop-blur-sm text-[11px] uppercase tracking-widest text-[#20201E] font-medium">
                          View Photograph
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
