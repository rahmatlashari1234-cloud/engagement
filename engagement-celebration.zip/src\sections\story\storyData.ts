export interface Milestone {
  id: string;
  year: string;
  date: string;
  title: string;
  description: string;
  location: string;
  imageUrl: string;
  imageAlt: string;
  tag: string;
}

export const STORY_META = {
  sectionNumber: "02 / Our Journey",
  heading: "How Our Story Unfolded",
  subheading: "Every step, every conversation, every sunset was quietly leading us to this moment.",
};

export const STORY_MILESTONES: Milestone[] = [
  {
    id: "m1",
    year: "2021",
    date: "October 14, 2021",
    title: "First Meeting",
    description: "An impromptu rainy afternoon in Greenwich Village. A crowded corner café with only one open table left. What was meant to be a twenty-minute coffee turned into three hours of effortless conversation about architecture, literature, and favorite records.",
    location: "Greenwich Village, New York",
    imageUrl: "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=1000&q=85",
    imageAlt: "Amelia and Daniel first meeting",
    tag: "The Spark"
  },
  {
    id: "m2",
    year: "2022",
    date: "February 22, 2022",
    title: "First Conversation That Never Ended",
    description: "Walking across the Brooklyn Bridge past midnight under gentle winter flurries, losing track of time and realizing that silence with each other was just as comforting as words.",
    location: "Brooklyn, New York",
    imageUrl: "https://images.unsplash.com/photo-1537633552985-df8429e8048b?auto=format&fit=crop&w=1000&q=85",
    imageAlt: "Night in the city together",
    tag: "City Lights"
  },
  {
    id: "m3",
    year: "2023",
    date: "July 8, 2023",
    title: "Our First Long Journey",
    description: "Traveling along coastal cliffside roads, getting delightfully lost without a map, and discovering that traveling together felt like a seamless dance rather than an itinerary.",
    location: "Amalfi Coast, Italy",
    imageUrl: "https://images.unsplash.com/photo-1465495976277-4387d4b0b4c6?auto=format&fit=crop&w=1000&q=85",
    imageAlt: "Coastal road trip together",
    tag: "The Horizon"
  },
  {
    id: "m4",
    year: "2025",
    date: "April 19, 2025",
    title: "Building Our Shared Home",
    description: "Unpacking endless cardboard boxes in our sun-drenched loft, assembling bookshelves together, and bringing home Oliver, our golden retriever who immediately made our house a home.",
    location: "Hudson Valley, New York",
    imageUrl: "https://images.unsplash.com/photo-1529636798458-92182e662485?auto=format&fit=crop&w=1000&q=85",
    imageAlt: "Sunlit moments in Hudson Valley",
    tag: "Rooted"
  },
  {
    id: "m5",
    year: "2026",
    date: "August 29, 2026",
    title: "The Question & She Said Yes",
    description: "Under the golden hour glow on a secluded cliffside balcony overlooking Positano, Daniel knelt down. Between joyful tears and quiet gasps of wonder, Amelia said yes before he could even finish the sentence.",
    location: "Positano, Italy",
    imageUrl: "/images/engagement-ring-reveal.png",
    imageAlt: "Amelia and Daniel engagement proposal ring reveal",
    tag: "Forever"
  },
  {
    id: "m6",
    year: "2026",
    date: "November 14, 2026",
    title: "Our Engagement Celebration",
    description: "Gathering our closest loved ones under the glass conservatory to raise a glass to love, intentional partnerships, and the countless adventures that await us.",
    location: "The Glasshouse Conservatory",
    imageUrl: "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&w=1000&q=85",
    imageAlt: "Celebration with loved ones",
    tag: "The Celebration"
  }
];
