import React, { useState } from 'react';
import { SOUNDTRACK_TRACKS } from '../../data/engagementContent';
import { Play, Pause, Disc, ExternalLink, Music2 } from 'lucide-react';
import { ambientAudio } from '../../utils/audioPlayer';

export const SoundtrackMixtape: React.FC = () => {
  const [selectedTrack, setSelectedTrack] = useState(SOUNDTRACK_TRACKS[0]);
  const [isPlaying, setIsPlaying] = useState(false);

  const handlePlayToggle = (track: typeof SOUNDTRACK_TRACKS[0]) => {
    setSelectedTrack(track);
    const nowPlaying = ambientAudio.toggle();
    setIsPlaying(nowPlaying);
  };

  return (
    <section className="py-24 md:py-36 px-6 md:px-12 bg-[#FAF8F5] border-t border-[#E5DFD5]/80 overflow-hidden">
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <div className="text-center space-y-3 mb-16 md:mb-20">
          <div className="inline-flex items-center gap-2">
            <Music2 className="w-3.5 h-3.5 text-[#B98F91]" />
            <span className="text-[11px] uppercase tracking-[0.28em] text-[#6F6A63] font-semibold">
              The Celebration Soundtrack
            </span>
          </div>
          <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl text-[#20201E] font-normal tracking-tight">
            Songs Between Moments
          </h2>
          <p className="text-sm md:text-base text-[#6F6A63] font-light max-w-xl mx-auto">
            The vinyl records and acoustic melodies that accompanied our quiet coffee mornings, midnight road trips, and the night we said yes.
          </p>
        </div>

        {/* Vinyl Player & Tracklist Split Box */}
        <div className="bg-[#F8F5F0] border border-[#E5DFD5] shadow-[0_12px_40px_rgba(32,32,30,0.04)] grid grid-cols-1 lg:grid-cols-12 items-stretch">
          {/* Left Column: Vinyl Sleeve & Spinning Record Art */}
          <div className="lg:col-span-5 p-8 sm:p-12 bg-[#20201E] text-white flex flex-col justify-between relative overflow-hidden">
            {/* Subtle atmospheric ambient glow */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-[#B98F91]/10 rounded-full blur-2xl pointer-events-none" />

            <div className="space-y-1 relative z-10">
              <span className="text-[10px] uppercase tracking-[0.26em] text-[#D8C5A5]">
                Side A • 33 ⅓ RPM
              </span>
              <h3 className="font-serif text-2xl sm:text-3xl font-light text-[#FAF8F5]">
                Amelia & Daniel
              </h3>
              <p className="text-xs text-white/60 tracking-wider">
                Curated Autumn Mixtape
              </p>
            </div>

            {/* Stylized Spinning Vinyl Record Graphic */}
            <div className="my-8 flex items-center justify-center relative">
              <div
                className={`w-44 h-44 sm:w-52 sm:h-52 rounded-full bg-[#151413] border-4 border-[#2E2C2A] shadow-2xl flex items-center justify-center relative ${
                  isPlaying ? 'animate-spin-slow' : ''
                }`}
              >
                {/* Vinyl Grooves concentric rings */}
                <div className="w-36 h-36 rounded-full border border-white/5" />
                <div className="w-28 h-28 rounded-full border border-white/5" />
                <div className="w-20 h-20 rounded-full border border-white/10" />

                {/* Center Record Label */}
                <div className="w-16 h-16 rounded-full bg-[#B98F91] border-2 border-[#D8C5A5] flex flex-col items-center justify-center text-center p-1 shadow-inner">
                  <span className="font-serif italic text-[11px] text-white leading-none">
                    A&D
                  </span>
                  <div className="w-2 h-2 rounded-full bg-[#151413] mt-1" />
                </div>
              </div>
            </div>

            {/* Currently Selected Track Info */}
            <div className="pt-4 border-t border-white/10 relative z-10 space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-serif text-xl text-[#FAF8F5]">
                    {selectedTrack.title}
                  </h4>
                  <p className="text-xs text-[#D8C5A5] font-light">
                    {selectedTrack.artist} • {selectedTrack.year}
                  </p>
                </div>

                <button
                  onClick={() => handlePlayToggle(selectedTrack)}
                  aria-label={isPlaying ? 'Pause track' : 'Play track'}
                  className="w-10 h-10 rounded-full bg-[#FAF8F5] text-[#20201E] flex items-center justify-center hover:scale-105 transition-transform"
                >
                  {isPlaying ? (
                    <Pause className="w-4 h-4 fill-[#20201E]" />
                  ) : (
                    <Play className="w-4 h-4 fill-[#20201E] ml-0.5" />
                  )}
                </button>
              </div>

              <p className="text-xs text-white/70 italic font-light pt-1">
                “{selectedTrack.note}”
              </p>
            </div>
          </div>

          {/* Right Column: Tracklist & Couple Notes */}
          <div className="lg:col-span-7 p-8 sm:p-12 flex flex-col justify-between space-y-8">
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-[#E5DFD5]">
                <span className="text-xs uppercase tracking-[0.2em] text-[#8C867E]">
                  Select Track to Preview
                </span>
                <span className="text-xs text-[#8C867E] font-mono">
                  5 Selected Tracks
                </span>
              </div>

              {/* Tracks List */}
              <div className="space-y-3">
                {SOUNDTRACK_TRACKS.map((track, idx) => {
                  const isCurrent = selectedTrack.id === track.id;

                  return (
                    <div
                      key={track.id}
                      onClick={() => handlePlayToggle(track)}
                      className={`p-4 border transition-all cursor-pointer flex items-center justify-between group ${
                        isCurrent
                          ? 'border-[#B98F91] bg-[#F2ECE4] shadow-sm'
                          : 'border-[#E5DFD5] bg-[#FAF8F5] hover:border-[#D8C5A5]'
                      }`}
                    >
                      <div className="flex items-center gap-4">
                        <span className="font-serif text-lg text-[#8C867E] w-6">
                          0{idx + 1}
                        </span>
                        <div>
                          <h4 className="font-serif text-lg text-[#20201E] group-hover:text-[#B98F91] transition-colors leading-tight">
                            {track.title}
                          </h4>
                          <span className="text-xs text-[#6F6A63] font-light">
                            {track.artist}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-4 text-xs text-[#8C867E]">
                        <span className="font-mono hidden sm:inline">{track.duration}</span>
                        <div
                          className={`w-7 h-7 rounded-full border flex items-center justify-center transition-colors ${
                            isCurrent && isPlaying
                              ? 'border-[#B98F91] bg-[#B98F91] text-white'
                              : 'border-[#E5DFD5] group-hover:border-[#20201E]'
                          }`}
                        >
                          {isCurrent && isPlaying ? (
                            <Disc className="w-3.5 h-3.5 animate-spin-slow" />
                          ) : (
                            <Play className="w-3 h-3 fill-current ml-0.5" />
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* External Spotify Link Banner */}
            <div className="pt-6 border-t border-[#E5DFD5] flex flex-wrap items-center justify-between gap-4">
              <span className="text-xs text-[#6F6A63] font-light">
                Listen to the full curated reception playlist on Spotify
              </span>
              <a
                href="https://open.spotify.com"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.16em] text-[#20201E] font-medium hover:text-[#B98F91] transition-colors"
              >
                <span>Open Spotify Playlist</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
