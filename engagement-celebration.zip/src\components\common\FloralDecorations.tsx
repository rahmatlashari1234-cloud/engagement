import React from 'react';

/**
 * Botanical Corner Vine Flourish
 * Elegant, delicate botanical stems with soft sage/olive leaves and champagne gold floral buds.
 */
interface BotanicalVineProps {
  position?: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right';
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  opacity?: number;
}

export const BotanicalVine: React.FC<BotanicalVineProps> = ({
  position = 'top-left',
  className = '',
  size = 'md',
  opacity = 0.8,
}) => {
  const sizeClasses = {
    sm: 'w-24 sm:w-36',
    md: 'w-36 sm:w-56 md:w-72',
    lg: 'w-48 sm:w-72 md:w-96',
  }[size];

  const positionClasses = {
    'top-left': 'top-0 left-0',
    'top-right': 'top-0 right-0 transform scale-x-[-1]',
    'bottom-left': 'bottom-0 left-0 transform scale-y-[-1]',
    'bottom-right': 'bottom-0 right-0 transform scale-[-1]',
  }[position];

  return (
    <div
      className={`absolute ${positionClasses} ${sizeClasses} pointer-events-none select-none z-0 ${className}`}
      style={{ opacity }}
      aria-hidden="true"
    >
      <svg
        viewBox="0 0 320 260"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full text-[#7B8B77]"
      >
        {/* Main curved vine stem */}
        <path
          d="M -10 -10 C 60 40 120 70 190 120 C 240 160 270 200 290 260"
          stroke="currentColor"
          strokeWidth="1.5"
          strokeLinecap="round"
          className="opacity-60"
        />
        {/* Secondary gentle shoots */}
        <path
          d="M 60 40 C 110 30 160 50 200 80"
          stroke="currentColor"
          strokeWidth="1.2"
          strokeLinecap="round"
          className="opacity-50"
        />
        <path
          d="M 120 70 C 150 110 170 150 190 190"
          stroke="currentColor"
          strokeWidth="1.1"
          strokeLinecap="round"
          className="opacity-45"
        />
        <path
          d="M 190 120 C 215 100 245 105 260 130"
          stroke="currentColor"
          strokeWidth="1.0"
          strokeLinecap="round"
          className="opacity-40"
        />

        {/* Soft Olive & Sage Leaf Clusters */}
        <g fill="#889883" className="opacity-75">
          <path d="M 80 45 C 85 25 110 20 115 35 C 110 50 90 55 80 45 Z" />
          <path d="M 140 78 C 155 60 180 65 178 85 C 165 95 145 92 140 78 Z" />
          <path d="M 195 125 C 220 115 240 130 235 148 C 215 155 200 142 195 125 Z" />
          <path d="M 245 180 C 270 175 285 195 275 212 C 255 215 245 198 245 180 Z" />
          <path d="M 40 22 C 35 5 55 -5 68 8 C 65 24 50 30 40 22 Z" />
          <path d="M 160 52 C 180 40 200 48 198 62 C 182 70 168 62 160 52 Z" />
          <path d="M 170 160 C 160 180 175 200 190 195 C 195 178 185 165 170 160 Z" />
          <path d="M 225 95 C 240 82 255 90 252 104 C 240 112 230 105 225 95 Z" />
        </g>

        {/* Delicate Golden Blossom Buds */}
        <g fill="#D8C5A5" className="opacity-90">
          <circle cx="118" cy="36" r="3.5" />
          <circle cx="180" cy="86" r="4" />
          <circle cx="236" cy="149" r="3.2" />
          <circle cx="277" cy="214" r="4.2" />
          <circle cx="200" cy="63" r="3" />
          <circle cx="258" cy="128" r="3.5" />
        </g>
      </svg>
    </div>
  );
};

/**
 * Single Scattered Rose Petal
 */
interface RosePetalProps {
  className?: string;
  variant?: 1 | 2 | 3;
  rotate?: number;
  scale?: number;
}

export const RosePetal: React.FC<RosePetalProps> = ({
  className = '',
  variant = 1,
  rotate = 0,
  scale = 1,
}) => {
  return (
    <div
      className={`pointer-events-none select-none z-10 transition-transform ${className}`}
      style={{
        transform: `rotate(${rotate}deg) scale(${scale})`,
      }}
      aria-hidden="true"
    >
      {variant === 1 && (
        <svg
          width="24"
          height="32"
          viewBox="0 0 24 32"
          fill="none"
          className="drop-shadow-[0_4px_6px_rgba(185,143,145,0.25)]"
        >
          <path
            d="M 12 2 C 20 7 23 18 17 27 C 12 34 4 29 2 22 C -1 14 5 4 12 2 Z"
            fill="url(#floral-petal-g1)"
          />
          <defs>
            <linearGradient id="floral-petal-g1" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#EBC6C8" />
              <stop offset="60%" stopColor="#D89D9F" />
              <stop offset="100%" stopColor="#B98F91" />
            </linearGradient>
          </defs>
        </svg>
      )}

      {variant === 2 && (
        <svg
          width="20"
          height="28"
          viewBox="0 0 20 28"
          fill="none"
          className="drop-shadow-[0_3px_5px_rgba(185,143,145,0.22)]"
        >
          <path
            d="M 10 2 C 17 6 19 16 14 24 C 10 29 3 25 2 20 C 0 12 4 4 10 2 Z"
            fill="url(#floral-petal-g2)"
          />
          <defs>
            <linearGradient id="floral-petal-g2" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#F2D5D6" />
              <stop offset="70%" stopColor="#DC9E9F" />
              <stop offset="100%" stopColor="#C48C8F" />
            </linearGradient>
          </defs>
        </svg>
      )}

      {variant === 3 && (
        <svg
          width="16"
          height="22"
          viewBox="0 0 16 22"
          fill="none"
          className="drop-shadow-[0_2px_4px_rgba(185,143,145,0.2)]"
        >
          <path
            d="M 8 2 C 14 5 16 13 12 19 C 9 23 2 21 1 15 C 0 9 3 3 8 2 Z"
            fill="#E2A6A8"
            fillOpacity="0.9"
          />
        </svg>
      )}
    </div>
  );
};

/**
 * Picture Frame Floral Flourish
 * Attached directly to picture cards or photos to add delicate botanical corners.
 */
interface PhotoFloralFlourishProps {
  position?: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right';
  className?: string;
}

export const PhotoFloralFlourish: React.FC<PhotoFloralFlourishProps> = ({
  position = 'top-left',
  className = '',
}) => {
  const transformClasses = {
    'top-left': '-top-3 -left-3',
    'top-right': '-top-3 -right-3 transform scale-x-[-1]',
    'bottom-left': '-bottom-3 -left-3 transform scale-y-[-1]',
    'bottom-right': '-bottom-3 -right-3 transform scale-[-1]',
  }[position];

  return (
    <div
      className={`absolute ${transformClasses} w-14 h-14 pointer-events-none z-20 select-none ${className}`}
      aria-hidden="true"
    >
      <svg viewBox="0 0 60 60" fill="none" className="w-full h-full text-[#7B8B77]">
        {/* Curving stem framing corner */}
        <path
          d="M 4 56 C 6 30 20 16 56 4"
          stroke="currentColor"
          strokeWidth="1.2"
          strokeLinecap="round"
          className="opacity-70"
        />
        <path
          d="M 22 24 C 28 14 40 12 46 16"
          stroke="currentColor"
          strokeWidth="0.9"
          strokeLinecap="round"
          className="opacity-60"
        />
        {/* Tender leaves */}
        <g fill="#889883" className="opacity-80">
          <path d="M 20 22 C 22 10 34 8 36 18 C 32 26 24 28 20 22 Z" />
          <path d="M 12 36 C 4 34 2 22 12 20 C 18 22 18 32 12 36 Z" />
          <path d="M 38 12 C 48 4 56 10 52 20 C 44 22 40 16 38 12 Z" />
        </g>
        {/* Gold bud */}
        <circle cx="34" cy="18" r="2.2" fill="#D8C5A5" />
        <circle cx="50" cy="15" r="2" fill="#D8C5A5" />
      </svg>
    </div>
  );
};

/**
 * Section Floral Background Decor
 * Injects matching botanical vines in corners and scattered petals across any photo section.
 */
interface SectionFloralDecorProps {
  showPetals?: boolean;
  intensity?: 'minimal' | 'normal' | 'lush';
  className?: string;
}

export const SectionFloralDecor: React.FC<SectionFloralDecorProps> = ({
  showPetals = true,
  intensity = 'normal',
  className = '',
}) => {
  return (
    <div className={`absolute inset-0 pointer-events-none overflow-hidden select-none z-0 ${className}`} aria-hidden="true">
      {/* Top Left & Top Right Vines */}
      <BotanicalVine position="top-left" size={intensity === 'lush' ? 'lg' : 'md'} opacity={0.8} />
      <BotanicalVine position="top-right" size={intensity === 'lush' ? 'lg' : 'md'} opacity={0.75} />

      {/* Bottom Vines for normal and lush */}
      {intensity !== 'minimal' && (
        <>
          <BotanicalVine position="bottom-left" size="sm" opacity={0.65} />
          <BotanicalVine position="bottom-right" size="sm" opacity={0.7} />
        </>
      )}

      {/* Scattered Rose Petals drifting */}
      {showPetals && (
        <>
          <div className="absolute top-24 left-6 sm:left-12">
            <RosePetal variant={1} rotate={-15} scale={1.05} />
          </div>
          <div className="absolute top-36 right-8 sm:right-16">
            <RosePetal variant={2} rotate={40} scale={0.95} />
          </div>
          <div className="absolute top-1/2 left-4 sm:left-8">
            <RosePetal variant={3} rotate={25} scale={1} />
          </div>
          <div className="absolute bottom-28 right-10 sm:right-20">
            <RosePetal variant={1} rotate={-35} scale={1} />
          </div>
          <div className="absolute bottom-16 left-12 sm:left-24">
            <RosePetal variant={2} rotate={60} scale={0.85} />
          </div>
        </>
      )}
    </div>
  );
};
