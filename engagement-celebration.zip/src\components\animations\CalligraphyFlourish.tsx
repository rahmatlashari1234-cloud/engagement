import React, { useEffect, useState } from 'react';

interface CalligraphyFlourishProps {
  variant?: 'monogram' | 'ampersand' | 'heart-swash' | 'divider';
  className?: string;
  delay?: number;
  duration?: number;
  autoPlay?: boolean;
}

export const CalligraphyFlourish: React.FC<CalligraphyFlourishProps> = ({
  variant = 'heart-swash',
  className = '',
  delay = 200,
  duration = 2400,
  autoPlay = true,
}) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (!autoPlay) return;

    const timer = setTimeout(() => {
      const startTime = performance.now();
      const frame = (now: number) => {
        const elapsed = now - startTime;
        const p = Math.min(elapsed / duration, 1);
        // Smooth easing
        const eased = p === 1 ? 1 : 1 - Math.pow(2, -10 * p);
        setProgress(eased);

        if (p < 1) {
          requestAnimationFrame(frame);
        }
      };
      requestAnimationFrame(frame);
    }, delay);

    return () => clearTimeout(timer);
  }, [autoPlay, delay, duration]);

  // Different SVG paths for each variant
  if (variant === 'ampersand') {
    const pathLength = 320;
    const strokeDashoffset = pathLength * (1 - progress);

    return (
      <div className={`relative inline-block ${className}`}>
        <svg
          viewBox="0 0 100 120"
          className="w-full h-full overflow-visible"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <linearGradient id="goldCalligraphy" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#C2A878" />
              <stop offset="35%" stopColor="#F5E8C7" />
              <stop offset="70%" stopColor="#D8C5A5" />
              <stop offset="100%" stopColor="#A88B57" />
            </linearGradient>
            <filter id="goldGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="1.5" result="glow" />
              <feComposite in="SourceGraphic" in2="glow" operator="over" />
            </filter>
          </defs>

          {/* Spencerian Ampersand Path */}
          <path
            d="M 68 35 C 65 20, 50 14, 38 24 C 26 34, 32 50, 48 62 C 65 74, 76 86, 72 100 C 66 114, 42 115, 28 102 C 14 88, 22 72, 38 60 C 52 48, 62 38, 58 24 C 55 12, 40 10, 32 20 C 24 30, 26 48, 45 66 L 78 108"
            stroke="url(#goldCalligraphy)"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeDasharray={pathLength}
            strokeDashoffset={strokeDashoffset}
            filter="url(#goldGlow)"
          />

          {/* Shimmering Tip of the Pen */}
          {progress > 0 && progress < 0.98 && (
            <circle
              cx="50"
              cy="60"
              r="2.5"
              fill="#FFFBEB"
              className="animate-ping opacity-75"
            />
          )}
        </svg>
      </div>
    );
  }

  if (variant === 'monogram') {
    const pathLength = 480;
    const strokeDashoffset = pathLength * (1 - progress);

    return (
      <div className={`relative inline-block ${className}`}>
        <svg
          viewBox="0 0 200 120"
          className="w-full h-full overflow-visible"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <linearGradient id="goldMonogram" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#C4A470" />
              <stop offset="50%" stopColor="#F9F1D8" />
              <stop offset="100%" stopColor="#D4BD95" />
            </linearGradient>
          </defs>

          {/* Letter A & D Intertwined Monogram */}
          <path
            d="M 25 90 C 20 80, 35 40, 55 20 C 65 10, 75 12, 70 28 C 65 44, 45 78, 38 92 C 32 104, 45 102, 60 88 M 40 68 Q 65 62, 85 64 M 95 62 C 100 50, 110 52, 105 68 C 100 84, 115 82, 120 70 M 130 92 C 125 70, 128 35, 138 18 C 145 7, 165 8, 175 25 C 185 42, 182 72, 168 88 C 154 104, 135 102, 128 92"
            stroke="url(#goldMonogram)"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeDasharray={pathLength}
            strokeDashoffset={strokeDashoffset}
          />

          {/* Decorative flourish under the monogram */}
          <path
            d="M 15 105 Q 100 118, 185 102"
            stroke="url(#goldMonogram)"
            strokeWidth="1.2"
            strokeDasharray="200"
            strokeDashoffset={200 * (1 - progress)}
            opacity="0.75"
          />
        </svg>
      </div>
    );
  }

  if (variant === 'divider') {
    const pathLength = 260;
    const strokeDashoffset = pathLength * (1 - progress);

    return (
      <div className={`relative flex items-center justify-center ${className}`}>
        <svg
          viewBox="0 0 240 30"
          className="w-full max-w-[240px] h-8 overflow-visible"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <linearGradient id="dividerGold" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="transparent" />
              <stop offset="25%" stopColor="#D8C5A5" />
              <stop offset="50%" stopColor="#F5E8C7" />
              <stop offset="75%" stopColor="#D8C5A5" />
              <stop offset="100%" stopColor="transparent" />
            </linearGradient>
          </defs>

          {/* Flourished Symmetrical Scroll */}
          <path
            d="M 10 15 C 40 15, 60 5, 80 15 C 100 25, 110 15, 120 15 C 130 15, 140 25, 160 15 C 180 5, 200 15, 230 15"
            stroke="url(#dividerGold)"
            strokeWidth="1.5"
            strokeDasharray={pathLength}
            strokeDashoffset={strokeDashoffset}
          />
          {/* Center tiny diamond jewel */}
          <circle
            cx="120"
            cy="15"
            r={progress > 0.6 ? 2.5 : 0}
            fill="#D8C5A5"
            className="transition-all duration-300"
          />
        </svg>
      </div>
    );
  }

  // Default: 'heart-swash'
  const pathLength = 240;
  const strokeDashoffset = pathLength * (1 - progress);

  return (
    <div className={`relative inline-block ${className}`}>
      <svg
        viewBox="0 0 120 60"
        className="w-full h-full overflow-visible"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id="goldSwash" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#B98F91" />
            <stop offset="50%" stopColor="#D8C5A5" />
            <stop offset="100%" stopColor="#F5E8C7" />
          </linearGradient>
        </defs>

        <path
          d="M 10 35 C 30 15, 50 15, 60 30 C 70 15, 90 15, 110 35 C 90 55, 60 55, 60 50 C 60 35, 75 25, 85 30"
          stroke="url(#goldSwash)"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeDasharray={pathLength}
          strokeDashoffset={strokeDashoffset}
        />
      </svg>
    </div>
  );
};
