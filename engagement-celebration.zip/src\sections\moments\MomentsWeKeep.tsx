import React from 'react';
import { MOMENTS_WE_KEEP, MOMENTS_META } from './momentsData';
import { OptimizedImage } from '../../components/common/OptimizedImage';
import { FloralDivider } from '../../components/common/FloralDivider';
import { TiltCard } from '../../components/common/TiltCard';
import { BotanicalVine, RosePetal, PhotoFloralFlourish } from '../../components/common/FloralDecorations';

interface MomentsWeKeepProps {
  onImageClick?: (imageUrl: string, title: string) => void;
}

export const MomentsWeKeep: React.FC<MomentsWeKeepProps> = ({ onImageClick }) => {
  return (
    <section id="moments" className="py-24 md:py-36 px-6 md:px-12 bg-[#FAF8F5] border-t border-[#E5DFD5]/60 animate-fade-in relative overflow-hidden">
      {/* Botanical Corner Vines & Petals */}
      <BotanicalVine position="top-left" size="lg" opacity={0.65} />
      <BotanicalVine position="top-right" size="lg" opacity={0.6} />
      <BotanicalVine position="bottom-left" size="md" opacity={0.5} />
      <BotanicalVine position="bottom-right" size="md" opacity={0.5} />

      <div className="absolute top-44 left-8 pointer-events-none">
        <RosePetal variant={1} rotate={-20} scale={1} />
      </div>
      <div className="absolute top-72 right-10 pointer-events-none">
        <RosePetal variant={2} rotate={35} scale={0.9} />
      </div>
      <div className="absolute bottom-52 left-10 pointer-events-none">
        <RosePetal variant={3} rotate={15} scale={0.85} />
      </div>
      <div className="absolute bottom-28 right-12 pointer-events-none">
        <RosePetal variant={1} rotate={-30} scale={0.9} />
      </div>
      <div className="max-w-6xl mx-auto space-y-28 md:space-y-40">
        {/* Section Header */}
        <div className="text-center space-y-4 max-w-2xl mx-auto">
          <span className="text-[11px] tracking-[0.26em] uppercase text-[#B98F91] font-semibold">
            {MOMENTS_META.sectionNumber}
          </span>
          <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl text-[#20201E] font-normal tracking-tight">
            {MOMENTS_META.heading}
          </h2>
          <p className="text-sm md:text-base text-[#6F6A63] font-light leading-relaxed">
            {MOMENTS_META.subheading}
          </p>
          <FloralDivider variant="minimal" className="my-6" />
        </div>

        {/* MOMENT 1: That First Hello */}
        {(() => {
          const m1 = MOMENTS_WE_KEEP[0];
          return (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-center">
              <div className="lg:col-span-5 space-y-6">
                <div className="flex items-center gap-3">
                  <span className="font-serif text-3xl text-[#D8C5A5] italic">{m1.number}</span>
                  <span className="text-xs uppercase tracking-widest text-[#8C867E]">{m1.date}</span>
                </div>
                <h3 className="font-serif text-3xl sm:text-4xl text-[#20201E] leading-snug">
                  {m1.title}
                </h3>
                <p className="text-sm uppercase tracking-wider text-[#B98F91] font-medium">
                  {m1.subtitle}
                </p>
                <p className="text-[#6F6A63] text-base font-light leading-relaxed">
                  {m1.story}
                </p>
                {m1.quote && (
                  <p className="font-serif italic text-lg text-[#20201E] border-l border-[#B98F91] pl-4 py-1">
                    {m1.quote}
                  </p>
                )}
              </div>

              <div className="lg:col-span-7">
                <TiltCard maxTilt={5} scale={1.02} glare={true}>
                  <div
                    className="cursor-pointer group relative overflow-hidden bg-[#EDE6DC] border border-[#E5DFD5] shadow-xl"
                    onClick={() => onImageClick && onImageClick(m1.imageUrl, m1.title)}
                  >
                    <PhotoFloralFlourish position="top-right" className="opacity-85 z-20" />
                    <OptimizedImage
                      src={m1.imageUrl}
                      alt={m1.imageAlt}
                      aspectRatio="16/10"
                      animation="zoom-hover"
                      cornerAccents={true}
                      curtainReveal={true}
                      className="w-full"
                    />
                    <div className="absolute bottom-4 right-4 bg-[#FAF8F5]/90 px-3 py-1 text-[11px] uppercase tracking-wider text-[#20201E] backdrop-blur-sm border border-[#E5DFD5]">
                      Manhattan • 2021
                    </div>
                  </div>
                </TiltCard>
              </div>
            </div>
          );
        })()}

        {/* MOMENT 2: The Day Everything Changed */}
        {(() => {
          const m2 = MOMENTS_WE_KEEP[1];
          return (
            <div className="relative bg-[#F2ECE4] p-8 md:p-16 border border-[#E5DFD5]">
              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-12 items-center">
                <div className="md:col-span-6 order-2 md:order-1">
                  <TiltCard maxTilt={5} scale={1.02} glare={true}>
                    <div
                      className="cursor-pointer group overflow-hidden border border-[#E5DFD5]/80 bg-[#FAF8F5] shadow-md relative"
                      onClick={() => onImageClick && onImageClick(m2.imageUrl, m2.title)}
                    >
                      <PhotoFloralFlourish position="top-left" className="opacity-85 z-20" />
                      <OptimizedImage
                        src={m2.imageUrl}
                        alt={m2.imageAlt}
                        aspectRatio="4/5"
                        animation="zoom-hover"
                        cornerAccents={true}
                        curtainReveal={true}
                        className="w-full"
                      />
                    </div>
                  </TiltCard>
                </div>

                <div className="md:col-span-6 space-y-6 order-1 md:order-2">
                  <div className="flex items-center gap-3">
                    <span className="font-serif text-3xl text-[#D8C5A5] italic">{m2.number}</span>
                    <span className="text-xs uppercase tracking-widest text-[#8C867E]">{m2.date}</span>
                  </div>
                  <h3 className="font-serif text-3xl sm:text-4xl text-[#20201E] leading-snug">
                    {m2.title}
                  </h3>
                  <p className="text-sm uppercase tracking-wider text-[#9BA595] font-medium">
                    {m2.subtitle}
                  </p>
                  <p className="text-[#6F6A63] text-base font-light leading-relaxed">
                    {m2.story}
                  </p>
                  {m2.quote && (
                    <blockquote className="font-serif italic text-xl md:text-2xl text-[#20201E] font-light leading-relaxed pt-2">
                      {m2.quote}
                    </blockquote>
                  )}
                </div>
              </div>
            </div>
          );
        })()}

        {/* MOMENT 3: Sunsets in Positano */}
        {(() => {
          const m3 = MOMENTS_WE_KEEP[2];
          return (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-center">
              <div className="lg:col-span-7">
                <TiltCard maxTilt={5} scale={1.02} glare={true}>
                  <div
                    className="cursor-pointer group relative overflow-hidden bg-[#EDE6DC] border border-[#E5DFD5] shadow-lg"
                    onClick={() => onImageClick && onImageClick(m3.imageUrl, m3.title)}
                  >
                    <PhotoFloralFlourish position="top-right" className="opacity-85 z-20" />
                    <OptimizedImage
                      src={m3.imageUrl}
                      alt={m3.imageAlt}
                      aspectRatio="16/9"
                      animation="zoom-hover"
                      cornerAccents={true}
                      curtainReveal={true}
                      className="w-full"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-60" />
                    <div className="absolute bottom-4 left-6 text-white text-xs uppercase tracking-widest font-sans">
                      Tyrrhenian Sea • Amalfi Coast
                    </div>
                  </div>
                </TiltCard>
              </div>

              <div className="lg:col-span-5 space-y-6">
                <div className="flex items-center gap-3">
                  <span className="font-serif text-3xl text-[#D8C5A5] italic">{m3.number}</span>
                  <span className="text-xs uppercase tracking-widest text-[#8C867E]">{m3.date}</span>
                </div>
                <h3 className="font-serif text-3xl sm:text-4xl text-[#20201E] leading-snug">
                  {m3.title}
                </h3>
                <p className="text-sm uppercase tracking-wider text-[#D8C5A5] font-medium">
                  {m3.subtitle}
                </p>
                <p className="text-[#6F6A63] text-base font-light leading-relaxed">
                  {m3.story}
                </p>
                {m3.quote && (
                  <p className="font-serif italic text-lg text-[#20201E] border-l border-[#D8C5A5] pl-4 py-1">
                    {m3.quote}
                  </p>
                )}
              </div>
            </div>
          );
        })()}

        {/* MOMENT 4: The Question */}
        {(() => {
          const m4 = MOMENTS_WE_KEEP[3];
          return (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-center">
              <div className="lg:col-span-5 space-y-6">
                <div className="flex items-center gap-3">
                  <span className="font-serif text-3xl text-[#D8C5A5] italic">{m4.number}</span>
                  <span className="text-xs uppercase tracking-widest text-[#8C867E]">{m4.date}</span>
                </div>
                <h3 className="font-serif text-3xl sm:text-4xl text-[#20201E] leading-snug">
                  {m4.title}
                </h3>
                <p className="text-sm uppercase tracking-wider text-[#B98F91] font-medium">
                  {m4.subtitle}
                </p>
                <p className="text-[#6F6A63] text-base font-light leading-relaxed">
                  {m4.story}
                </p>
                {m4.quote && (
                  <p className="font-serif text-2xl text-[#20201E] italic pt-2">
                    {m4.quote}
                  </p>
                )}
              </div>

              <div className="lg:col-span-7">
                <TiltCard maxTilt={5} scale={1.02} glare={true}>
                  <div
                    className="cursor-pointer group relative overflow-hidden bg-[#EDE6DC] border border-[#E5DFD5] shadow-xl"
                    onClick={() => onImageClick && onImageClick(m4.imageUrl, m4.title)}
                  >
                    <PhotoFloralFlourish position="top-right" className="opacity-85 z-20" />
                    <OptimizedImage
                      src={m4.imageUrl}
                      alt={m4.imageAlt}
                      aspectRatio="16/10"
                      animation="zoom-hover"
                      cornerAccents={true}
                      curtainReveal={true}
                      className="w-full"
                    />
                    <div className="p-4 bg-[#F8F5F0] border-t border-[#E5DFD5] flex items-center justify-between text-xs text-[#8C867E]">
                      <span className="uppercase tracking-widest font-semibold text-[#B98F91]">Heirloom Setting</span>
                      <span className="font-serif italic text-sm text-[#20201E]">August 29, 2026</span>
                    </div>
                  </div>
                </TiltCard>
              </div>
            </div>
          );
        })()}

        {/* MOMENT 5: The Beginning of Forever */}
        {(() => {
          const m5 = MOMENTS_WE_KEEP[4];
          return (
            <div className="border-t border-[#E5DFD5] pt-16">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                <div className="lg:col-span-6 space-y-4">
                  <span className="text-xs uppercase tracking-[0.24em] text-[#8C867E]">
                    {m5.number} / Looking Forward
                  </span>
                  <h3 className="font-serif text-3xl sm:text-4xl text-[#20201E]">
                    {m5.title}
                  </h3>
                  <p className="text-[#6F6A63] text-base font-light leading-relaxed">
                    {m5.story}
                  </p>
                  {m5.quote && (
                    <blockquote className="font-serif italic text-xl text-[#20201E] pt-2">
                      {m5.quote}
                    </blockquote>
                  )}
                </div>

                <div className="lg:col-span-6">
                  <TiltCard maxTilt={5} scale={1.02} glare={true}>
                    <div
                      className="cursor-pointer group overflow-hidden border border-[#E5DFD5] shadow-lg relative"
                      onClick={() => onImageClick && onImageClick(m5.imageUrl, m5.title)}
                    >
                      <PhotoFloralFlourish position="top-left" className="opacity-85 z-20" />
                      <OptimizedImage
                        src={m5.imageUrl}
                        alt={m5.imageAlt}
                        aspectRatio="16/9"
                        animation="zoom-hover"
                        cornerAccents={true}
                        curtainReveal={true}
                        className="w-full"
                      />
                    </div>
                  </TiltCard>
                </div>
              </div>
            </div>
          );
        })()}
      </div>
    </section>
  );
};
