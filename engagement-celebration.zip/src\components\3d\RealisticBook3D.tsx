import React, { useState, useRef, useEffect, useCallback } from 'react';
import { ChevronLeft, ChevronRight, BookOpen, Sparkles, Eye, Camera, MapPin } from 'lucide-react';
import { PhotoFloralFlourish } from '../common/FloralDecorations';

export interface BookPlate {
  id: string;
  title: string;
  subtitle?: string;
  category?: string;
  imageUrl: string;
  date?: string;
  location?: string;
  description?: string;
  plateNumber?: string;
}

interface RealisticBook3DProps {
  plates: BookPlate[];
  onImageClick?: (imageUrl: string, title: string) => void;
  className?: string;
}

export const RealisticBook3D: React.FC<RealisticBook3DProps> = ({
  plates,
  onImageClick,
  className = '',
}) => {
  // Current spread index (spread 0 = plates[0], spread 1 = plates[1], etc.)
  const [spreadIndex, setSpreadIndex] = useState(0);
  const [turnDirection, setTurnDirection] = useState<'next' | 'prev' | null>(null);
  const [turnProgress, setTurnProgress] = useState(0); // 0 to 1
  const [isHoveringCorner, setIsHoveringCorner] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);

  const animFrameRef = useRef<number | null>(null);
  const isAnimatingRef = useRef(false);
  const dragStartXRef = useRef<number | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);

  const totalSpreads = plates.length;
  const currentPlate = plates[spreadIndex] || plates[0];
  const nextPlate = plates[spreadIndex + 1] || null;
  const prevPlate = plates[spreadIndex - 1] || null;

  // Realistic synthetic paper rustle sound using Web Audio noise burst
  const playPageTurnSound = useCallback(() => {
    if (!soundEnabled) return;
    try {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!audioCtxRef.current) {
        audioCtxRef.current = new AudioCtx();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }

      const sampleRate = ctx.sampleRate;
      const duration = 0.38;
      const bufferSize = sampleRate * duration;
      const buffer = ctx.createBuffer(1, bufferSize, sampleRate);
      const data = buffer.getChannelData(0);

      // Filtered noise with paper friction texture
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        const envelope = Math.sin((i / bufferSize) * Math.PI);
        data[i] = white * envelope * 0.18;
      }

      const noiseNode = ctx.createBufferSource();
      noiseNode.buffer = buffer;

      // Lowpass filter that opens and closes like fluttering paper
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(450, ctx.currentTime);
      filter.frequency.exponentialRampToValueAtTime(1400, ctx.currentTime + 0.15);
      filter.frequency.exponentialRampToValueAtTime(300, ctx.currentTime + duration);

      const gainNode = ctx.createGain();
      gainNode.gain.setValueAtTime(0.01, ctx.currentTime);
      gainNode.gain.linearRampToValueAtTime(0.25, ctx.currentTime + 0.08);
      gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);

      noiseNode.connect(filter);
      filter.connect(gainNode);
      gainNode.connect(ctx.destination);

      noiseNode.start();
    } catch {
      // Audio autoplay policy fallback
    }
  }, [soundEnabled]);

  // Turn to Next Page with realistic ease-in-out rotation
  const triggerTurnNext = useCallback(() => {
    if (isAnimatingRef.current || spreadIndex >= totalSpreads - 1) return;
    isAnimatingRef.current = true;
    setTurnDirection('next');
    playPageTurnSound();

    const duration = 650; // ms
    const startTime = performance.now();

    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const rawProgress = Math.min(elapsed / duration, 1);
      // Smooth cubic easing for physical paper resistance
      const eased =
        rawProgress < 0.5
          ? 4 * rawProgress * rawProgress * rawProgress
          : 1 - Math.pow(-2 * rawProgress + 2, 3) / 2;

      setTurnProgress(eased);

      if (rawProgress < 1) {
        animFrameRef.current = requestAnimationFrame(animate);
      } else {
        setSpreadIndex((prev) => prev + 1);
        setTurnDirection(null);
        setTurnProgress(0);
        isAnimatingRef.current = false;
      }
    };

    animFrameRef.current = requestAnimationFrame(animate);
  }, [spreadIndex, totalSpreads, playPageTurnSound]);

  // Turn to Previous Page
  const triggerTurnPrev = useCallback(() => {
    if (isAnimatingRef.current || spreadIndex <= 0) return;
    isAnimatingRef.current = true;
    setTurnDirection('prev');
    playPageTurnSound();

    const duration = 650;
    const startTime = performance.now();

    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const rawProgress = Math.min(elapsed / duration, 1);
      const eased =
        rawProgress < 0.5
          ? 4 * rawProgress * rawProgress * rawProgress
          : 1 - Math.pow(-2 * rawProgress + 2, 3) / 2;

      setTurnProgress(eased);

      if (rawProgress < 1) {
        animFrameRef.current = requestAnimationFrame(animate);
      } else {
        setSpreadIndex((prev) => prev - 1);
        setTurnDirection(null);
        setTurnProgress(0);
        isAnimatingRef.current = false;
      }
    };

    animFrameRef.current = requestAnimationFrame(animate);
  }, [spreadIndex, playPageTurnSound]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') triggerTurnNext();
      if (e.key === 'ArrowLeft') triggerTurnPrev();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [triggerTurnNext, triggerTurnPrev]);

  // Touch / Drag detection
  const handlePointerDown = (e: React.PointerEvent) => {
    dragStartXRef.current = e.clientX;
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (dragStartXRef.current === null) return;
    const deltaX = e.clientX - dragStartXRef.current;
    if (deltaX < -50) triggerTurnNext();
    else if (deltaX > 50) triggerTurnPrev();
    dragStartXRef.current = null;
  };

  // Rotation angles for turning leaf:
  // Turning NEXT: Right page lifts from 0deg and flips to -180deg (left page)
  const nextLeafAngle = turnDirection === 'next' ? -180 * turnProgress : 0;
  // Turning PREV: Left page lifts from 0deg and flips to 180deg (right page)
  const prevLeafAngle = turnDirection === 'prev' ? 180 * turnProgress : 0;

  // Shadow intensities that rise as page is vertical (progress near 0.5)
  const shadowIntensity = Math.sin(turnProgress * Math.PI) * 0.45;

  return (
    <div
      className={`relative w-full max-w-5xl mx-auto py-6 select-none ${className}`}
      onPointerDown={handlePointerDown}
      onPointerUp={handlePointerUp}
    >
      {/* 3D BOOK STAGE WITH PERSPECTIVE */}
      <div
        className="relative mx-auto flex items-center justify-center p-2 sm:p-6"
        style={{ perspective: '2200px' }}
      >
        {/* OUTER HARDCOVER LEATHER BASE & SPINE */}
        <div className="relative w-full max-w-4xl bg-[#1C1B19] p-3 sm:p-5 rounded-lg shadow-[0_35px_80px_rgba(0,0,0,0.42)] border border-[#D8C5A5]/50">
          
          {/* Gold Embossed Edge Trim */}
          <div className="absolute inset-x-5 top-2 h-[1px] bg-gradient-to-r from-transparent via-[#D8C5A5]/70 to-transparent" />
          <div className="absolute inset-x-5 bottom-2 h-[1px] bg-gradient-to-r from-transparent via-[#D8C5A5]/70 to-transparent" />
          
          {/* Book Bookmark Silk Ribbon */}
          <div 
            className="absolute top-0 right-1/4 w-4 h-12 bg-[#B98F91] shadow-md z-40 rounded-b-sm pointer-events-none transform -translate-y-2 opacity-90"
            style={{
              clipPath: 'polygon(0 0, 100% 0, 100% 85%, 50% 100%, 0 85%)',
            }}
          />

          {/* TWO-PAGE SPREAD CONTAINER */}
          <div
            className="relative grid grid-cols-1 md:grid-cols-2 bg-[#FAF8F5] border border-[#E5DFD5] rounded-xs min-h-[480px] sm:min-h-[530px]"
            style={{ transformStyle: 'preserve-3d' }}
          >
            {/* CENTRAL GUTTER / SPINE REALISTIC CREASE & DEPTH SHADOW */}
            <div className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 w-10 pointer-events-none hidden md:block z-30 bg-gradient-to-r from-black/25 via-black/40 to-black/25 opacity-70" />
            <div className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 w-[1.5px] bg-[#D8C5A5] pointer-events-none hidden md:block z-30 shadow-xs" />

            {/* ============================================================
                1. FIXED LEFT BASE PAGE
                Shows current spread (or previous plate if turning)
               ============================================================ */}
            <div className="p-6 sm:p-10 md:pr-12 flex flex-col justify-between border-b md:border-b-0 md:border-r border-[#E5DFD5] relative overflow-hidden bg-[#FAF8F5]">
              {/* Parchment Paper Fiber Grain Texture */}
              <div className="absolute inset-0 opacity-[0.03] bg-[radial-gradient(#000_1px,transparent_1px)] [background-size:12px_12px] pointer-events-none" />

              {/* Underlying dynamic shadow cast when right page lands on left */}
              {turnDirection === 'next' && (
                <div
                  className="absolute inset-0 pointer-events-none z-20 transition-opacity bg-gradient-to-l from-black/50 via-black/20 to-transparent"
                  style={{ opacity: turnProgress > 0.5 ? shadowIntensity : 0 }}
                />
              )}

              {/* Left Page Content */}
              <div className="space-y-4 relative z-10">
                {/* Header Meta */}
                <div className="flex items-center justify-between border-b border-[#E5DFD5] pb-3">
                  <span className="text-[10px] uppercase tracking-[0.24em] text-[#8C867E] font-mono">
                    Plate {currentPlate.plateNumber || String(spreadIndex + 1).padStart(2, '0')}
                  </span>
                  <span className="font-serif italic text-xs text-[#B98F91] tracking-wider">
                    {currentPlate.category ? currentPlate.category.toUpperCase() : 'MEMOIR'}
                  </span>
                </div>

                {/* Badge & Title */}
                <div className="pt-2">
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#B98F91]/10 text-[#B98F91] text-[10px] uppercase tracking-wider font-semibold">
                    <Sparkles className="w-2.5 h-2.5" />
                    <span>Archival Curation</span>
                  </span>
                  <h3 className="font-serif text-2xl sm:text-3xl text-[#20201E] font-normal mt-2 leading-tight">
                    {currentPlate.title}
                  </h3>
                  {currentPlate.subtitle && (
                    <p className="font-serif italic text-sm text-[#8C867E] mt-1">
                      {currentPlate.subtitle}
                    </p>
                  )}
                </div>

                {/* Narrative Excerpt / Description */}
                <p className="text-[#6F6A63] text-xs sm:text-sm font-light leading-relaxed pt-1">
                  {currentPlate.description ||
                    'A timeless testament to shared laughter, stolen glances, and a love story written across continents. Handcrafted into this archival monograph.'}
                </p>

                {/* Meta details */}
                <div className="pt-3 space-y-1.5 text-xs text-[#8C867E]">
                  {currentPlate.date && (
                    <div className="flex items-center gap-2">
                      <Camera className="w-3.5 h-3.5 text-[#D8C5A5]" />
                      <span className="font-sans uppercase tracking-wider text-[11px]">
                        {currentPlate.date}
                      </span>
                    </div>
                  )}
                  {currentPlate.location && (
                    <div className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-[#889883]" />
                      <span className="font-sans tracking-wide">{currentPlate.location}</span>
                    </div>
                  )}
                </div>

                {/* Archival Gold Foil Emboss Badge */}
                <div className="pt-3">
                  <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#F5EFE7] border border-[#D8C5A5]/60 rounded-xs text-[9px] uppercase tracking-widest text-[#6F6A63]">
                    <span className="text-[#B98F91]">✦</span>
                    <span>35mm Silver Halide • Natural Light</span>
                  </div>
                </div>
              </div>

              {/* Left Page Footer */}
              <div className="pt-6 border-t border-[#E5DFD5]/80 flex items-center justify-between text-xs text-[#8C867E] relative z-10">
                <span className="font-serif italic text-xs">Amelia &amp; Daniel</span>
                <span className="font-mono text-[10px]">p. {spreadIndex * 2 + 1}</span>
              </div>
            </div>

            {/* ============================================================
                2. FIXED RIGHT BASE PAGE
                Shows upcoming plate when turning NEXT, or current plate
               ============================================================ */}
            <div className="p-6 sm:p-10 md:pl-12 flex flex-col justify-between bg-[#F8F5F0] relative overflow-hidden">
              {/* Underlying dynamic shadow cast when turning backward */}
              {turnDirection === 'prev' && (
                <div
                  className="absolute inset-0 pointer-events-none z-20 transition-opacity bg-gradient-to-r from-black/50 via-black/20 to-transparent"
                  style={{ opacity: turnProgress < 0.5 ? shadowIntensity : 0 }}
                />
              )}

              {/* Underneath plate content (visible when the top page flips over) */}
              {(() => {
                const displayPlate = turnDirection === 'next' && nextPlate ? nextPlate : currentPlate;
                return (
                  <>
                    <div className="flex-1 flex flex-col items-center justify-center relative">
                      {/* Mounted Photograph on heavy archival matting */}
                      <div
                        onClick={() =>
                          onImageClick && onImageClick(displayPlate.imageUrl, displayPlate.title)
                        }
                        className="relative group cursor-pointer w-full max-w-[340px] aspect-[4/3] sm:aspect-[16/11] bg-white p-2.5 sm:p-3 border border-[#D8C5A5] shadow-lg transition-transform duration-300 hover:scale-[1.02]"
                      >
                        <PhotoFloralFlourish position="top-right" className="opacity-80" />

                        <div className="relative w-full h-full overflow-hidden bg-[#EDE6DC]">
                          <img
                            src={displayPlate.imageUrl}
                            alt={displayPlate.title}
                            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                          />

                          {/* Hover Overlay */}
                          <div className="absolute inset-0 bg-[#20201E]/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                            <span className="px-3 py-1 bg-white/95 text-[#20201E] text-[10px] uppercase tracking-widest font-sans border border-[#D8C5A5] flex items-center gap-1 shadow-sm">
                              <Eye className="w-3 h-3 text-[#B98F91]" />
                              <span>Inspect Archival High-Res</span>
                            </span>
                          </div>
                        </div>

                        {/* Hand-written Polaroid Caption */}
                        <div className="pt-2 text-center">
                          <span className="font-serif italic text-xs text-[#20201E]">
                            {displayPlate.title}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Right Page Footer */}
                    <div className="pt-6 border-t border-[#E5DFD5]/80 flex items-center justify-between text-xs text-[#8C867E]">
                      <span className="text-[10px] uppercase tracking-widest font-sans">
                        Archival Photographic Plate
                      </span>
                      <span className="font-mono text-[10px]">p. {spreadIndex * 2 + 2}</span>
                    </div>
                  </>
                );
              })()}

              {/* INTERACTIVE CORNER DOG-EAR CURL HINT */}
              {spreadIndex < totalSpreads - 1 && !turnDirection && (
                <div
                  onMouseEnter={() => setIsHoveringCorner(true)}
                  onMouseLeave={() => setIsHoveringCorner(false)}
                  onClick={triggerTurnNext}
                  className="absolute bottom-0 right-0 w-16 h-16 cursor-pointer z-40 group flex items-end justify-end p-1"
                  title="Click to Turn Page"
                >
                  {/* Curled Corner Triangle with Realistic 3D Paper Shadow */}
                  <div
                    className={`w-12 h-12 transition-all duration-300 transform origin-bottom-right ${
                      isHoveringCorner
                        ? 'scale-115 rotate-[-8deg] shadow-[-6px_-6px_12px_rgba(0,0,0,0.18)]'
                        : 'scale-90 hover:scale-100 shadow-[-3px_-3px_8px_rgba(0,0,0,0.1)]'
                    }`}
                    style={{
                      clipPath: 'polygon(100% 0, 0 100%, 100% 100%)',
                      background: 'linear-gradient(135deg, #FAF8F5 50%, #D8C5A5 100%)',
                      borderLeft: '1px solid #D8C5A5',
                      borderTop: '1px solid #D8C5A5',
                    }}
                  />
                  <span className="absolute bottom-1 right-1 text-[8px] font-mono uppercase text-[#8C867E] opacity-70 group-hover:opacity-100">
                    Turn ⤶
                  </span>
                </div>
              )}
            </div>

            {/* ============================================================
                3. ULTRA-REALISTIC 3D TURNING LEAF (Active when turning forward)
                Flips from right side (0deg) to left side (-180deg)
               ============================================================ */}
            {turnDirection === 'next' && (
              <div
                className="absolute top-0 bottom-0 right-0 w-1/2 z-50 pointer-events-none"
                style={{
                  transformOrigin: 'left center',
                  transform: `rotateY(${nextLeafAngle}deg)`,
                  transformStyle: 'preserve-3d',
                  transition: 'none',
                }}
              >
                {/* FRONT FACE (Original right page that lifts and curls forward) */}
                <div
                  className="absolute inset-0 p-6 sm:p-10 md:pl-12 flex flex-col justify-between bg-[#F8F5F0] border-l border-[#E5DFD5] shadow-2xl"
                  style={{
                    backfaceVisibility: 'hidden',
                    transform: 'rotateY(0deg)',
                  }}
                >
                  {/* Moving Curvature Shine Highlight across paper */}
                  <div
                    className="absolute inset-0 pointer-events-none"
                    style={{
                      background: `linear-gradient(${90 + turnProgress * 90}deg, rgba(0,0,0,${
                        0.25 * Math.sin(turnProgress * Math.PI)
                      }) 0%, rgba(255,255,255,${
                        0.45 * Math.sin(turnProgress * Math.PI)
                      }) 40%, rgba(0,0,0,${0.3 * Math.sin(turnProgress * Math.PI)}) 100%)`,
                    }}
                  />

                  {/* Content of the front lifting page */}
                  <div className="flex-1 flex flex-col items-center justify-center">
                    <div className="w-full max-w-[340px] aspect-[4/3] sm:aspect-[16/11] bg-white p-2.5 sm:p-3 border border-[#D8C5A5] shadow-md">
                      <div className="relative w-full h-full overflow-hidden bg-[#EDE6DC]">
                        <img
                          src={currentPlate.imageUrl}
                          alt={currentPlate.title}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="pt-2 text-center font-serif italic text-xs text-[#20201E]">
                        {currentPlate.title}
                      </div>
                    </div>
                  </div>

                  <div className="pt-6 border-t border-[#E5DFD5]/80 flex items-center justify-between text-xs text-[#8C867E]">
                    <span className="text-[10px] uppercase tracking-widest font-sans">
                      Archival Photographic Plate
                    </span>
                    <span className="font-mono text-[10px]">p. {spreadIndex * 2 + 2}</span>
                  </div>
                </div>

                {/* BACK FACE (Upcoming left page that lands on the left stack) */}
                {nextPlate && (
                  <div
                    className="absolute inset-0 p-6 sm:p-10 md:pr-12 flex flex-col justify-between bg-[#FAF8F5] border-r border-[#E5DFD5] shadow-2xl"
                    style={{
                      backfaceVisibility: 'hidden',
                      transform: 'rotateY(180deg)',
                    }}
                  >
                    {/* Reverse Curvature Shading */}
                    <div
                      className="absolute inset-0 pointer-events-none"
                      style={{
                        background: `linear-gradient(${270 - turnProgress * 90}deg, rgba(0,0,0,${
                          0.25 * Math.sin(turnProgress * Math.PI)
                        }) 0%, rgba(255,255,255,${
                          0.4 * Math.sin(turnProgress * Math.PI)
                        }) 40%, rgba(0,0,0,${0.2 * Math.sin(turnProgress * Math.PI)}) 100%)`,
                      }}
                    />

                    {/* Left narrative content of the next plate */}
                    <div className="space-y-4 relative z-10">
                      <div className="flex items-center justify-between border-b border-[#E5DFD5] pb-3">
                        <span className="text-[10px] uppercase tracking-[0.24em] text-[#8C867E] font-mono">
                          Plate {nextPlate.plateNumber || String(spreadIndex + 2).padStart(2, '0')}
                        </span>
                        <span className="font-serif italic text-xs text-[#B98F91] tracking-wider">
                          {nextPlate.category ? nextPlate.category.toUpperCase() : 'MEMOIR'}
                        </span>
                      </div>

                      <div className="pt-2">
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#B98F91]/10 text-[#B98F91] text-[10px] uppercase tracking-wider font-semibold">
                          <Sparkles className="w-2.5 h-2.5" />
                          <span>Archival Curation</span>
                        </span>
                        <h3 className="font-serif text-2xl sm:text-3xl text-[#20201E] font-normal mt-2 leading-tight">
                          {nextPlate.title}
                        </h3>
                      </div>

                      <p className="text-[#6F6A63] text-xs sm:text-sm font-light leading-relaxed pt-1">
                        {nextPlate.description ||
                          'Captured in pristine cinematic clarity. Every delicate glance and shared breath woven into an enduring heirloom.'}
                      </p>
                    </div>

                    <div className="pt-6 border-t border-[#E5DFD5]/80 flex items-center justify-between text-xs text-[#8C867E]">
                      <span className="font-serif italic text-xs">Amelia &amp; Daniel</span>
                      <span className="font-mono text-[10px]">p. {spreadIndex * 2 + 3}</span>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* ============================================================
                4. REVERSE 3D TURNING LEAF (Active when turning backward)
                Flips from left side (-180deg) to right side (0deg)
               ============================================================ */}
            {turnDirection === 'prev' && prevPlate && (
              <div
                className="absolute top-0 bottom-0 left-0 w-1/2 z-50 pointer-events-none"
                style={{
                  transformOrigin: 'right center',
                  transform: `rotateY(${prevLeafAngle}deg)`,
                  transformStyle: 'preserve-3d',
                  transition: 'none',
                }}
              >
                {/* FRONT FACE of reverse turn */}
                <div
                  className="absolute inset-0 p-6 sm:p-10 md:pr-12 flex flex-col justify-between bg-[#FAF8F5] border-r border-[#E5DFD5] shadow-2xl"
                  style={{
                    backfaceVisibility: 'hidden',
                    transform: 'rotateY(0deg)',
                  }}
                >
                  <div className="space-y-4 relative z-10">
                    <span className="text-[10px] uppercase tracking-[0.24em] text-[#8C867E] font-mono">
                      Returning to previous chapter...
                    </span>
                    <h3 className="font-serif text-2xl text-[#20201E]">{currentPlate.title}</h3>
                  </div>
                </div>

                {/* BACK FACE of reverse turn (previous photo returning) */}
                <div
                  className="absolute inset-0 p-6 sm:p-10 md:pl-12 flex flex-col justify-between bg-[#F8F5F0] border-l border-[#E5DFD5] shadow-2xl"
                  style={{
                    backfaceVisibility: 'hidden',
                    transform: 'rotateY(180deg)',
                  }}
                >
                  <div className="flex-1 flex flex-col items-center justify-center">
                    <div className="w-full max-w-[340px] aspect-[4/3] sm:aspect-[16/11] bg-white p-2.5 sm:p-3 border border-[#D8C5A5] shadow-md">
                      <div className="relative w-full h-full overflow-hidden bg-[#EDE6DC]">
                        <img
                          src={prevPlate.imageUrl}
                          alt={prevPlate.title}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 3D PHOTOBOOK NAVIGATION & SOUND CONTROLS */}
      <div className="flex flex-wrap items-center justify-between gap-4 max-w-4xl mx-auto px-4 mt-6">
        {/* Previous Page Button */}
        <button
          onClick={triggerTurnPrev}
          disabled={spreadIndex === 0 || isAnimatingRef.current}
          className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-xs border text-xs uppercase tracking-widest font-medium transition-all cursor-pointer ${
            spreadIndex === 0
              ? 'opacity-35 border-[#E5DFD5] text-[#8C867E] cursor-not-allowed'
              : 'border-[#D8C5A5] bg-[#FAF8F5] text-[#20201E] hover:bg-[#20201E] hover:text-[#FAF8F5] shadow-xs active:scale-95'
          }`}
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Turn Previous</span>
        </button>

        {/* Spread Chapter Tracker & Audio Toggle */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-xs text-[#8C867E] font-mono">
            <BookOpen className="w-4 h-4 text-[#B98F91]" />
            <span>
              Spread {spreadIndex + 1} of {totalSpreads}
            </span>
          </div>

          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className={`text-[10px] uppercase tracking-wider px-2.5 py-1 rounded-full border transition-colors cursor-pointer ${
              soundEnabled
                ? 'bg-[#B98F91]/10 text-[#B98F91] border-[#B98F91]/30'
                : 'text-[#8C867E] border-[#E5DFD5]'
            }`}
            title="Toggle realistic paper rustle sound"
          >
            {soundEnabled ? '🔊 Paper Audio ON' : '🔈 Audio Muted'}
          </button>
        </div>

        {/* Next Page Button */}
        <button
          onClick={triggerTurnNext}
          disabled={spreadIndex >= totalSpreads - 1 || isAnimatingRef.current}
          className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-xs border text-xs uppercase tracking-widest font-medium transition-all cursor-pointer ${
            spreadIndex >= totalSpreads - 1
              ? 'opacity-35 border-[#E5DFD5] text-[#8C867E] cursor-not-allowed'
              : 'border-[#D8C5A5] bg-[#FAF8F5] text-[#20201E] hover:bg-[#20201E] hover:text-[#FAF8F5] shadow-xs active:scale-95'
          }`}
        >
          <span>Turn Next Page</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      <p className="text-center text-[11px] text-[#8C867E] font-light mt-3 tracking-wider">
        Drag across pages or click corner curl to experience authentic 3D page turn physics • Arrow keys supported
      </p>
    </div>
  );
};
