import React, { useState } from 'react';
import { RSVP_META } from './rsvpData';
import { TiltCard } from '../../components/common/TiltCard';
import { MonogramCrest } from '../../components/common/MonogramCrest';
import { Check, Send, Sparkles, Printer, Calendar, MapPin } from 'lucide-react';
import { CalligraphyFlourish } from '../../components/animations/CalligraphyFlourish';

interface RsvpFormData {
  fullName: string;
  email: string;
  phone: string;
  attendance: 'accept' | 'decline' | null;
  guestCount: number;
  guestNames: string;
  dietaryRestrictions: string[];
  dietaryOther: string;
  message: string;
}

export const RsvpSection: React.FC = () => {
  const [formData, setFormData] = useState<RsvpFormData>({
    fullName: '',
    email: '',
    phone: '',
    attendance: 'accept',
    guestCount: 1,
    guestNames: '',
    dietaryRestrictions: [],
    dietaryOther: '',
    message: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleDietaryToggle = (option: string) => {
    setFormData((prev) => {
      const exists = prev.dietaryRestrictions.includes(option);
      if (option === 'None / No restrictions') {
        return {
          ...prev,
          dietaryRestrictions: exists ? [] : ['None / No restrictions'],
        };
      }
      const filtered = prev.dietaryRestrictions.filter(
        (item) => item !== 'None / No restrictions'
      );
      return {
        ...prev,
        dietaryRestrictions: exists
          ? filtered.filter((item) => item !== option)
          : [...filtered, option],
      };
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!formData.fullName.trim()) {
      setErrorMessage('Please enter your full name.');
      return;
    }
    if (!formData.email.trim() || !formData.email.includes('@')) {
      setErrorMessage('Please enter a valid email address.');
      return;
    }
    if (!formData.attendance) {
      setErrorMessage('Please specify your attendance.');
      return;
    }

    setIsSubmitting(true);

    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 800);
  };

  const handleReset = () => {
    setIsSubmitted(false);
    setFormData({
      fullName: '',
      email: '',
      phone: '',
      attendance: 'accept',
      guestCount: 1,
      guestNames: '',
      dietaryRestrictions: [],
      dietaryOther: '',
      message: '',
    });
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <section id="rsvp" className="py-24 md:py-36 px-6 md:px-12 bg-[#F8F5F0] border-t border-[#E5DFD5]/60 animate-fade-in select-none">
      <div className="max-w-3xl mx-auto">
        {/* Section Header */}
        <div className="text-center space-y-4 mb-14 md:mb-18">
          <span className="text-[11px] tracking-[0.26em] uppercase text-[#B98F91] font-semibold">
            {RSVP_META.sectionNumber}
          </span>
          <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl text-[#20201E] font-normal tracking-tight">
            {RSVP_META.heading}
          </h2>
          <p className="text-sm md:text-base text-[#6F6A63] font-light leading-relaxed max-w-lg mx-auto">
            Please let us know if you can join us by{' '}
            <strong className="font-medium text-[#20201E]">
              {RSVP_META.deadline}
            </strong>
            .
          </p>
          <div className="w-12 h-[1px] bg-[#D8C5A5] mx-auto mt-4" />
        </div>

        {/* Confirmation Success View: 3D Embossed Banquet Pass */}
        {isSubmitted ? (
          <div className="space-y-8 animate-fade-in">
            {/* 3D Interactive Ticket Pass */}
            <TiltCard maxRotation={9} scale={1.03} className="max-w-xl mx-auto">
              <div className="relative bg-[#FFFDF9] border-2 border-[#D8C5A5] p-6 sm:p-10 shadow-[0_20px_50px_rgba(32,32,30,0.12)] overflow-hidden">
                {/* Gold Foil Shimmer Sheen Accent */}
                <div className="absolute top-0 right-0 w-48 h-48 bg-gradient-to-bl from-[#D8C5A5]/25 to-transparent pointer-events-none" />

                {/* Ticket Header */}
                <div className="flex items-center justify-between border-b border-[#D8C5A5] pb-4">
                  <div className="flex items-center gap-3">
                    <MonogramCrest size="sm" variant="gold" />
                    <div>
                      <span className="text-[9px] uppercase tracking-[0.28em] text-[#8C867E] block font-mono">
                        HONORED GUEST PASS
                      </span>
                      <h4 className="font-serif text-xl sm:text-2xl text-[#20201E]">
                        Amelia & Daniel
                      </h4>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] uppercase tracking-wider text-[#B98F91] font-mono block">
                      NO. #AD-2026
                    </span>
                    <span className="text-[9px] text-[#8C867E] font-mono">CONFIRMED</span>
                  </div>
                </div>

                {/* Ticket Body */}
                <div className="py-6 space-y-4">
                  <div>
                    <span className="text-[10px] uppercase tracking-widest text-[#8C867E] block">
                      Guest Name
                    </span>
                    <p className="font-serif text-2xl sm:text-3xl text-[#20201E] font-medium">
                      {formData.fullName}
                    </p>
                    <CalligraphyFlourish variant="heart-swash" className="w-16 h-8 mx-auto my-1 opacity-80" />
                  </div>

                  <div className="grid grid-cols-2 gap-4 pt-2 border-t border-[#E5DFD5]">
                    <div>
                      <span className="text-[9px] uppercase tracking-wider text-[#8C867E] block">
                        Attendance
                      </span>
                      <p className="font-serif text-base text-[#20201E] flex items-center gap-1.5 pt-0.5">
                        <Check className="w-3.5 h-3.5 text-[#9BA595]" />
                        <span>{formData.attendance === 'accept' ? 'Joyfully Attending' : 'Regretfully Declining'}</span>
                      </p>
                    </div>

                    <div>
                      <span className="text-[9px] uppercase tracking-wider text-[#8C867E] block">
                        Reserved Seats
                      </span>
                      <p className="font-serif text-base text-[#20201E] pt-0.5">
                        {formData.attendance === 'accept' ? `${formData.guestCount} Guest(s)` : 'N/A'}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-1 pt-2 border-t border-[#E5DFD5] text-xs text-[#6F6A63]">
                    <div className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-[#B98F91]" />
                      <span>{RSVP_META.celebrationDateDisplay} • 5:00 PM EST</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-[#9BA595]" />
                      <span>The Glasshouse Conservatory • Stone Hill Estate, NY</span>
                    </div>
                  </div>
                </div>

                {/* Ticket Stub Perforated Divider */}
                <div className="border-t-2 border-dashed border-[#D8C5A5] pt-4 flex items-center justify-between text-xs font-mono text-[#8C867E]">
                  <span>VALET: COMPLIMENTARY</span>
                  <span>ESTATE GATE A</span>
                  <Sparkles className="w-4 h-4 text-[#B98F91]" />
                </div>

                {/* VINTAGE EMBOSSED POSTAL CANCELLATION STAMP */}
                <div 
                  className="absolute bottom-10 right-8 pointer-events-none transform rotate-[-12deg] border-2 border-[#B98F91] rounded-full w-28 h-28 flex flex-col items-center justify-center text-center p-2 opacity-90 shadow-sm animate-pulse hidden sm:flex"
                  style={{
                    color: '#B98F91',
                  }}
                >
                  <div className="w-full h-full rounded-full border border-dashed border-[#B98F91] flex flex-col items-center justify-center p-1">
                    <span className="text-[7.5px] uppercase tracking-widest font-mono">AIRMAIL RSVP</span>
                    <span className="text-[10px] font-mono font-bold tracking-wider my-0.5">OCTOBER 2026</span>
                    <span className="text-[7px] uppercase tracking-widest font-mono">HUDSON VALLEY • NY</span>
                    <div className="w-8 h-[1px] bg-[#B98F91] my-0.5" />
                    <span className="text-[8px] font-script">With Love ✦</span>
                  </div>
                </div>
              </div>
            </TiltCard>

            {/* Post-Submit Action Buttons */}
            <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
              <button
                onClick={handlePrint}
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#20201E] text-[#F8F5F0] text-xs uppercase tracking-[0.16em] font-medium hover:bg-[#3A3935] transition-colors cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5 text-[#D8C5A5]" />
                <span>Save / Print Pass</span>
              </button>

              <button
                onClick={handleReset}
                className="px-5 py-2.5 border border-[#D8C5A5] text-[#20201E] text-xs uppercase tracking-[0.16em] font-medium hover:bg-[#F2ECE4] transition-colors cursor-pointer"
              >
                Submit Another Response
              </button>
            </div>
          </div>
        ) : (
          /* Form Card */
          <form
            onSubmit={handleSubmit}
            className="p-8 md:p-12 bg-[#FAF8F5] border border-[#E5DFD5] shadow-[0_8px_30px_rgba(32,32,30,0.03)] space-y-8"
          >
            {errorMessage && (
              <div className="p-3 bg-[#B98F91]/15 border border-[#B98F91] text-xs text-[#20201E] font-medium">
                {errorMessage}
              </div>
            )}

            {/* Attendance Choice Buttons */}
            <div className="space-y-3">
              <label className="block text-xs uppercase tracking-[0.18em] text-[#20201E] font-medium">
                Will you be attending? *
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, attendance: 'accept' })}
                  className={`p-4 border text-left flex items-center justify-between transition-all duration-200 cursor-pointer ${
                    formData.attendance === 'accept'
                      ? 'border-[#20201E] bg-[#F2ECE4] shadow-sm'
                      : 'border-[#E5DFD5] bg-[#F8F5F0] hover:border-[#D8C5A5]'
                  }`}
                >
                  <div>
                    <span className="font-serif text-lg text-[#20201E] block">
                      Joyfully Accept
                    </span>
                    <span className="text-xs text-[#6F6A63] font-light">
                      I will attend with joy
                    </span>
                  </div>
                  <div
                    className={`w-5 h-5 rounded-full border flex items-center justify-center ${
                      formData.attendance === 'accept'
                        ? 'border-[#20201E] bg-[#20201E] text-white'
                        : 'border-[#E5DFD5]'
                    }`}
                  >
                    {formData.attendance === 'accept' && <Check className="w-3 h-3" />}
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, attendance: 'decline' })}
                  className={`p-4 border text-left flex items-center justify-between transition-all duration-200 cursor-pointer ${
                    formData.attendance === 'decline'
                      ? 'border-[#20201E] bg-[#F2ECE4] shadow-sm'
                      : 'border-[#E5DFD5] bg-[#F8F5F0] hover:border-[#D8C5A5]'
                  }`}
                >
                  <div>
                    <span className="font-serif text-lg text-[#20201E] block">
                      Regretfully Decline
                    </span>
                    <span className="text-xs text-[#6F6A63] font-light">
                      Celebrating from afar
                    </span>
                  </div>
                  <div
                    className={`w-5 h-5 rounded-full border flex items-center justify-center ${
                      formData.attendance === 'decline'
                        ? 'border-[#20201E] bg-[#20201E] text-white'
                        : 'border-[#E5DFD5]'
                    }`}
                  >
                    {formData.attendance === 'decline' && <Check className="w-3 h-3" />}
                  </div>
                </button>
              </div>
            </div>

            {/* Name, Email, Phone */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="space-y-1.5 sm:col-span-2">
                <label className="block text-xs uppercase tracking-[0.16em] text-[#6F6A63]">
                  Your Full Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Clara Harrington"
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  className="w-full px-4 py-3 bg-[#F8F5F0] border border-[#E5DFD5] text-[#20201E] text-sm focus:outline-none focus:border-[#20201E] transition-colors"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs uppercase tracking-[0.16em] text-[#6F6A63]">
                  Email Address *
                </label>
                <input
                  type="email"
                  required
                  placeholder="clara@example.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-4 py-3 bg-[#F8F5F0] border border-[#E5DFD5] text-[#20201E] text-sm focus:outline-none focus:border-[#20201E] transition-colors"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs uppercase tracking-[0.16em] text-[#6F6A63]">
                  Phone Number
                </label>
                <input
                  type="tel"
                  placeholder="+1 (555) 000-0000"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full px-4 py-3 bg-[#F8F5F0] border border-[#E5DFD5] text-[#20201E] text-sm focus:outline-none focus:border-[#20201E] transition-colors"
                />
              </div>
            </div>

            {/* Guest Count */}
            {formData.attendance === 'accept' && (
              <div className="space-y-6 pt-2 border-t border-[#E5DFD5]">
                <div className="space-y-2">
                  <label className="block text-xs uppercase tracking-[0.16em] text-[#6F6A63]">
                    Number of Guests Attending (including yourself)
                  </label>
                  <div className="flex items-center gap-3">
                    {[1, 2, 3, 4].map((count) => (
                      <button
                        key={count}
                        type="button"
                        onClick={() => setFormData({ ...formData, guestCount: count })}
                        className={`w-12 h-11 border text-sm font-medium transition-all cursor-pointer ${
                          formData.guestCount === count
                            ? 'bg-[#20201E] text-[#F8F5F0] border-[#20201E]'
                            : 'bg-[#F8F5F0] text-[#6F6A63] border-[#E5DFD5] hover:border-[#D8C5A5]'
                        }`}
                      >
                        {count}
                      </button>
                    ))}
                  </div>
                </div>

                {formData.guestCount > 1 && (
                  <div className="space-y-1.5 animate-fade-in">
                    <label className="block text-xs uppercase tracking-[0.16em] text-[#6F6A63]">
                      Accompanying Guest Name(s)
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Julian Vance"
                      value={formData.guestNames}
                      onChange={(e) =>
                        setFormData({ ...formData, guestNames: e.target.value })
                      }
                      className="w-full px-4 py-3 bg-[#F8F5F0] border border-[#E5DFD5] text-[#20201E] text-sm focus:outline-none focus:border-[#20201E] transition-colors"
                    />
                  </div>
                )}

                {/* Dietary Requirements */}
                <div className="space-y-2 pt-2">
                  <label className="block text-xs uppercase tracking-[0.16em] text-[#6F6A63]">
                    Dietary Preferences
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                    {RSVP_META.dietaryOptions.map((option) => {
                      const isSelected = formData.dietaryRestrictions.includes(option);
                      return (
                        <button
                          key={option}
                          type="button"
                          onClick={() => handleDietaryToggle(option)}
                          className={`p-2.5 text-xs text-left border flex items-center justify-between transition-colors cursor-pointer ${
                            isSelected
                              ? 'border-[#20201E] bg-[#F2ECE4] text-[#20201E] font-medium'
                              : 'border-[#E5DFD5] bg-[#F8F5F0] text-[#6F6A63] hover:border-[#D8C5A5]'
                          }`}
                        >
                          <span className="truncate">{option}</span>
                          {isSelected && <Check className="w-3 h-3 text-[#B98F91] shrink-0" />}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* Message / Well Wishes */}
            <div className="space-y-1.5 pt-2 border-t border-[#E5DFD5]">
              <label className="block text-xs uppercase tracking-[0.16em] text-[#6F6A63]">
                Warm Wishes or Song Request
              </label>
              <textarea
                rows={3}
                placeholder="Share a heartfelt message, memory, or song to play on the dance floor..."
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                className="w-full px-4 py-3 bg-[#F8F5F0] border border-[#E5DFD5] text-[#20201E] text-sm focus:outline-none focus:border-[#20201E] transition-colors resize-none"
              />
            </div>

            {/* Submit Button */}
            <div className="pt-4">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-4 bg-[#20201E] text-[#F8F5F0] uppercase text-xs tracking-[0.24em] font-medium hover:bg-[#383733] transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-70 shadow-sm"
              >
                {isSubmitting ? (
                  <span>Generating Honored Guest Pass...</span>
                ) : (
                  <>
                    <span>Confirm Response & Generate Pass</span>
                    <Send className="w-3.5 h-3.5 text-[#D8C5A5]" />
                  </>
                )}
              </button>

              <p className="text-center text-[11px] text-[#8C867E] font-light mt-3">
                Need to amend an existing RSVP later? Reach out to{' '}
                <a
                  href={`mailto:${RSVP_META.email}`}
                  className="underline hover:text-[#20201E]"
                >
                  {RSVP_META.email}
                </a>
              </p>
            </div>
          </form>
        )}
      </div>
    </section>
  );
};
