import React, { useState, useEffect } from 'react';
import { Volume2, VolumeX, Menu, X, Heart, Layers } from 'lucide-react';
import { COUPLE_DATA } from '../../sections/home/homeData';
import { ambientAudio } from '../../utils/audioPlayer';

export type SectionKey =
  | 'cover'
  | 'home'
  | 'story'
  | 'moments'
  | 'gallery'
  | 'event'
  | 'guide'
  | 'soundtrack'
  | 'wishing-well'
  | 'toasts'
  | 'rsvp';

interface NavbarProps {
  activeSection: SectionKey;
  onNavigate: (sectionKey: SectionKey) => void;
  showAllSections: boolean;
  onToggleShowAll: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeSection,
  onNavigate,
  showAllSections,
  onToggleShowAll,
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isPlayingMusic, setIsPlayingMusic] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMusic = () => {
    const playing = ambientAudio.toggle();
    setIsPlayingMusic(playing);
  };

  const navLinks: { label: string; key: SectionKey }[] = [
    { label: 'Cover', key: 'cover' },
    { label: 'Home', key: 'home' },
    { label: 'Our Story', key: 'story' },
    { label: 'Moments', key: 'moments' },
    { label: 'Gallery', key: 'gallery' },
    { label: 'The Event', key: 'event' },
    { label: 'RSVP', key: 'rsvp' },
  ];

  const handleNavClick = (key: SectionKey) => {
    onNavigate(key);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled
            ? 'bg-[#F8F5F0]/95 backdrop-blur-md py-3.5 border-b border-[#E5DFD5]/80 shadow-[0_4px_20px_rgba(32,32,30,0.02)]'
            : 'bg-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 md:px-12 flex items-center justify-between">
          {/* Logo / Monogram */}
          <button
            onClick={() => handleNavClick('home')}
            className="group flex items-center gap-2.5 text-[#20201E] text-left cursor-pointer bg-transparent border-none p-0"
          >
            <span className="font-serif text-2xl md:text-3xl tracking-wide font-normal">
              {COUPLE_DATA.brideFirst}{' '}
              <span className="text-[#B98F91] italic font-serif">&</span>{' '}
              {COUPLE_DATA.groomFirst}
            </span>
          </button>

          {/* Desktop Nav Links */}
          <nav className="hidden xl:flex items-center gap-5 2xl:gap-7 text-[12px] tracking-[0.14em] uppercase text-[#6F6A63] font-medium">
            {navLinks.map((link) => {
              const isActive = activeSection === link.key && !showAllSections;

              return (
                <button
                  key={link.key}
                  onClick={() => handleNavClick(link.key)}
                  className={`relative py-1 transition-colors duration-200 cursor-pointer bg-transparent border-none p-0 text-inherit ${
                    isActive
                      ? 'text-[#20201E] font-semibold after:w-full'
                      : 'hover:text-[#20201E] after:w-0'
                  } after:content-[''] after:absolute after:bottom-0 after:left-0 after:h-[1px] after:bg-[#B98F91] hover:after:w-full after:transition-all after:duration-300`}
                >
                  {link.label}
                </button>
              );
            })}
          </nav>

          {/* Right Action Controls: Audio + View Mode + RSVP */}
          <div className="hidden sm:flex items-center gap-3">
            {/* View Mode Toggle: Section View vs All Sections */}
            <button
              onClick={onToggleShowAll}
              title={showAllSections ? 'Switch to Section by Section view' : 'Scroll all sections continuously'}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] tracking-wider uppercase transition-all duration-300 cursor-pointer ${
                showAllSections
                  ? 'border-[#20201E] text-[#20201E] bg-[#EAE2D7]'
                  : 'border-[#E5DFD5] text-[#6F6A63] hover:border-[#D8C5A5]'
              }`}
            >
              <Layers className="w-3.5 h-3.5 text-[#B98F91]" />
              <span className="hidden md:inline">{showAllSections ? 'Full Feed' : 'Sections'}</span>
            </button>

            {/* Ambient Sound Button */}
            <button
              onClick={toggleMusic}
              aria-label={isPlayingMusic ? 'Mute ambient sound' : 'Play ambient music'}
              title={isPlayingMusic ? 'Mute ambient sound' : 'Play ambient sound'}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-full border text-xs tracking-wider uppercase transition-all duration-300 cursor-pointer ${
                isPlayingMusic
                  ? 'border-[#B98F91] text-[#20201E] bg-[#B98F91]/10'
                  : 'border-[#E5DFD5] text-[#6F6A63] hover:text-[#20201E] hover:border-[#D8C5A5]'
              }`}
            >
              {isPlayingMusic ? (
                <>
                  <Volume2 className="w-3.5 h-3.5 text-[#B98F91]" />
                  <span className="text-[11px] font-sans">Music</span>
                  <div className="flex items-center gap-0.5 ml-0.5">
                    <span className="w-0.5 h-2.5 bg-[#B98F91] animate-pulse" />
                    <span className="w-0.5 h-3.5 bg-[#B98F91] animate-pulse delay-75" />
                    <span className="w-0.5 h-2 bg-[#B98F91] animate-pulse delay-150" />
                  </div>
                </>
              ) : (
                <>
                  <VolumeX className="w-3.5 h-3.5 text-[#8C867E]" />
                  <span className="text-[11px] font-sans">Sound</span>
                </>
              )}
            </button>

            {/* Quick RSVP Button */}
            <button
              onClick={() => handleNavClick('rsvp')}
              className="px-5 py-2 text-xs uppercase tracking-[0.16em] font-medium bg-[#20201E] text-[#F8F5F0] rounded-none hover:bg-[#383733] transition-all duration-300 shadow-sm flex items-center gap-1.5 cursor-pointer"
            >
              <span>RSVP</span>
              <Heart className="w-3 h-3 text-[#B98F91] fill-[#B98F91]" />
            </button>
          </div>

          {/* Mobile Right Controls */}
          <div className="flex xl:hidden items-center gap-2">
            <button
              onClick={toggleMusic}
              aria-label="Toggle ambient music"
              className="p-2 text-[#6F6A63] border border-[#E5DFD5] rounded-full sm:hidden"
            >
              {isPlayingMusic ? (
                <Volume2 className="w-4 h-4 text-[#B98F91]" />
              ) : (
                <VolumeX className="w-4 h-4" />
              )}
            </button>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label={mobileMenuOpen ? 'Close Menu' : 'Open Menu'}
              className="p-2 text-[#20201E] cursor-pointer"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Overlay */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-30 bg-[#F8F5F0] pt-24 px-8 flex flex-col justify-between pb-12 animate-fade-in xl:hidden overflow-y-auto">
          <div className="flex flex-col space-y-3 pt-2">
            <span className="text-xs uppercase tracking-[0.2em] text-[#8C867E]">
              Sections
            </span>
            {navLinks.map((link) => {
              const isActive = activeSection === link.key && !showAllSections;

              return (
                <button
                  key={link.key}
                  onClick={() => handleNavClick(link.key)}
                  className={`font-serif text-2xl text-left py-1.5 border-b border-[#E5DFD5]/50 flex items-center justify-between cursor-pointer transition-colors ${
                    isActive ? 'text-[#B98F91] font-medium' : 'text-[#20201E] hover:text-[#B98F91]'
                  }`}
                >
                  <span>{link.label}</span>
                  <span className="text-xs font-sans tracking-widest text-[#8C867E]">→</span>
                </button>
              );
            })}
          </div>

          <div className="pt-6 border-t border-[#E5DFD5] flex flex-col gap-3">
            <button
              onClick={() => {
                onToggleShowAll();
                setMobileMenuOpen(false);
              }}
              className="w-full text-center py-2.5 border border-[#D8C5A5] text-[#20201E] uppercase text-[11px] tracking-wider"
            >
              {showAllSections ? 'Switch to Section by Section' : 'Show All Sections Together'}
            </button>

            <button
              onClick={() => handleNavClick('rsvp')}
              className="w-full text-center py-3.5 bg-[#20201E] text-[#F8F5F0] uppercase text-xs tracking-[0.2em] font-medium"
            >
              Join the Celebration • RSVP
            </button>
          </div>
        </div>
      )}
    </>
  );
};
