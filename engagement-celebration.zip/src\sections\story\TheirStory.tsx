import React, { useState } from 'react';
import { STORY_MILESTONES, STORY_META } from './storyData';
import { OptimizedImage } from '../../components/common/OptimizedImage';
import { Calendar, MapPin, BookOpen, Layers } from 'lucide-react';
import { TiltCard } from '../../components/common/TiltCard';
import { BotanicalVine, RosePetal, PhotoFloralFlourish } from '../../components/common/FloralDecorations';
import { RealisticBook3D, type BookPlate } from '../../components/3d/RealisticBook3D';
import { ConstellationMap } from '../../components/animations/ConstellationMap';

interface TheirStoryProps {
  onImageClick?: (imageUrl: string, title: string) => void;
}

export const TheirStory: React.FC<TheirStoryProps> = ({ onImageClick }) => {
  const [storyViewMode, setStoryViewMode] = useState<'book' | 'timeline'>('book');

  const storyPlates: BookPlate[] = STORY_MILESTONES.map((m, idx) => ({
    id: m.id,
    title: m.title,
    subtitle: `${m.date} • ${m.year}`,
    category: m.tag,
    imageUrl: m.imageUrl,
    date: m.date,
    location: m.location,
    description: m.description,
    plateNumber: String(idx + 1).padStart(2, '0'),
  }));

  return (
    <section id="story" className="py-24 md:py-36 px-6 md:px-12 bg-[#FAF8F5] relative overflow-hidden animate-fade-in">
      {/* Botanical Corner Vines & Drifting Petals */}
      <BotanicalVine position="top-left" size="lg" opacity={0.65} />
      <BotanicalVine position="top-right" size="lg" opacity={0.6} />
      <BotanicalVine position="bottom-left" size="md" opacity={0.5} />
      <BotanicalVine position="bottom-right" size="md" opacity={0.5} />

      <div className="absolute top-36 left-8 pointer-events-none">
        <RosePetal variant={1} rotate={-15} scale={1} />
      </div>
      <div className="absolute top-64 right-10 pointer-events-none">
        <RosePetal variant={2} rotate={35} scale={0.9} />
      </div>
      <div className="absolute bottom-48 left-12 pointer-events-none">
        <RosePetal variant={3} rotate={10} scale={0.85} />
      </div>
      <div className="absolute bottom-28 right-14 pointer-events-none">
        <RosePetal variant={1} rotate={-30} scale={0.9} />
      </div>
      <div className="max-w-5xl mx-auto">
        {/* Section Header */}
        <div className="text-center space-y-4 mb-16 md:mb-20">
          <span className="text-[11px] tracking-[0.26em] uppercase text-[#B98F91] font-semibold">
            {STORY_META.sectionNumber}
          </span>
          <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl text-[#20201E] font-normal tracking-tight">
            {STORY_META.heading}
          </h2>
          <p className="max-w-xl mx-auto text-sm md:text-base text-[#6F6A63] font-light leading-relaxed">
            {STORY_META.subheading}
          </p>
          <div className="w-12 h-[1px] bg-[#D8C5A5] mx-auto mt-6" />

          {/* Mode Switcher */}
          <div className="flex items-center justify-center pt-6">
            <div className="p-1 bg-[#FAF8F5] border border-[#D8C5A5] rounded-full shadow-xs inline-flex items-center gap-1">
              <button
                onClick={() => setStoryViewMode('book')}
                className={`px-4 py-1.5 rounded-full text-[11px] uppercase tracking-widest font-sans transition-all cursor-pointer flex items-center gap-1.5 ${
                  storyViewMode === 'book'
                    ? 'bg-[#20201E] text-white shadow-xs font-medium'
                    : 'text-[#6F6A63] hover:text-[#20201E]'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5 text-[#D8C5A5]" />
                <span>3D Keepsake Album</span>
              </button>
              <button
                onClick={() => setStoryViewMode('timeline')}
                className={`px-4 py-1.5 rounded-full text-[11px] uppercase tracking-widest font-sans transition-all cursor-pointer flex items-center gap-1.5 ${
                  storyViewMode === 'timeline'
                    ? 'bg-[#20201E] text-white shadow-xs font-medium'
                    : 'text-[#6F6A63] hover:text-[#20201E]'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Timeline Chronicle</span>
              </button>
            </div>
          </div>
        </div>

        {storyViewMode === 'book' ? (
          <RealisticBook3D plates={storyPlates} onImageClick={onImageClick} />
        ) : (
          /* Vertical Timeline Progression */
          <div className="relative animate-fade-in">
          {/* Subtle central vertical line */}
          <div className="absolute left-4 md:left-1/2 top-4 bottom-4 w-[1px] bg-[#E5DFD5] -translate-x-1/2 hidden md:block" />
          <div className="absolute left-6 top-4 bottom-4 w-[1px] bg-[#E5DFD5] md:hidden" />

          <div className="space-y-16 md:space-y-28">
            {STORY_MILESTONES.map((milestone, idx) => {
              const isEven = idx % 2 === 0;

              return (
                <div
                  key={milestone.id}
                  className={`relative flex flex-col md:flex-row items-center gap-8 md:gap-16 ${
                    isEven ? 'md:flex-row-reverse' : ''
                  }`}
                >
                  {/* Central Node Dot on timeline */}
                  <div className="absolute left-6 md:left-1/2 top-0 md:top-8 -translate-x-1/2 w-4 h-4 rounded-full border-2 border-[#FAF8F5] bg-[#B98F91] z-10 shadow-sm" />

                  {/* Left / Right Content Box */}
                  <div className="w-full md:w-1/2 pl-12 md:pl-0">
                    <div
                      className={`space-y-4 ${
                        isEven ? 'md:text-left md:pl-10' : 'md:text-right md:pr-10'
                      }`}
                    >
                      {/* Meta tag & date */}
                      <div
                        className={`flex flex-wrap items-center gap-2 text-xs text-[#8C867E] ${
                          isEven ? 'md:justify-start' : 'md:justify-end'
                        }`}
                      >
                        <span className="inline-flex items-center gap-1 font-medium text-[#B98F91] bg-[#B98F91]/10 px-2 py-0.5 rounded-full text-[11px] tracking-wider uppercase">
                          {milestone.tag}
                        </span>
                        <span className="inline-flex items-center gap-1 text-[11px] uppercase tracking-wider text-[#6F6A63]">
                          <Calendar className="w-3 h-3 text-[#D8C5A5]" />
                          {milestone.date}
                        </span>
                      </div>

                      {/* Milestone Title */}
                      <h3 className="font-serif text-2xl md:text-3xl text-[#20201E] font-normal leading-snug">
                        {milestone.title}
                      </h3>

                      {/* Narrative Text */}
                      <p className="text-[#6F6A63] text-sm md:text-base font-light leading-relaxed">
                        {milestone.description}
                      </p>

                      {/* Location indicator */}
                      <div
                        className={`inline-flex items-center gap-1.5 text-xs text-[#8C867E] ${
                          isEven ? 'md:justify-start' : 'md:justify-end'
                        }`}
                      >
                        <MapPin className="w-3 h-3 text-[#9BA595]" />
                        <span>{milestone.location}</span>
                      </div>
                    </div>
                  </div>

                  {/* Image Card Box with 3D Tilt & Specular Sheen */}
                  <div className="w-full md:w-1/2 pl-12 md:pl-0">
                    <TiltCard maxTilt={5} scale={1.02} glare={true} className={isEven ? 'md:mr-10' : 'md:ml-10'}>
                      <div
                        onClick={() => onImageClick && onImageClick(milestone.imageUrl, milestone.title)}
                        className="group relative overflow-hidden bg-[#EDE6DC] border border-[#E5DFD5] shadow-[0_10px_25px_rgba(32,32,30,0.05)] cursor-pointer"
                      >
                        <PhotoFloralFlourish position={isEven ? "top-left" : "top-right"} className="opacity-85 z-20" />
                        <OptimizedImage
                          src={milestone.imageUrl}
                          alt={milestone.imageAlt}
                          aspectRatio="16/10"
                          animation="zoom-hover"
                          cornerAccents={true}
                          curtainReveal={true}
                          className="w-full"
                          objectFit="cover"
                        />
                        <div className="absolute inset-0 bg-[#20201E]/0 group-hover:bg-[#20201E]/25 transition-colors duration-300 flex items-center justify-center">
                          <span className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 px-3.5 py-1.5 bg-[#F8F5F0]/95 backdrop-blur-sm text-[10px] uppercase tracking-widest text-[#20201E] font-medium shadow-sm rounded-xs border border-[#E5DFD5]">
                            View Archival Photograph
                          </span>
                        </div>
                      </div>
                    </TiltCard>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
        )}

        {/* Celestial Constellation of Love Map */}
        <ConstellationMap className="mt-20 md:mt-28" />
      </div>
    </section>
  );
};
