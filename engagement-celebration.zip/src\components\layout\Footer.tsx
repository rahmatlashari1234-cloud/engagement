import { COUPLE_DATA, HOME_DATE } from '../../sections/home/homeData';
import { ArrowUp, Heart } from 'lucide-react';
import type { SectionKey } from './Navbar';

interface FooterProps {
  onNavigate?: (sectionKey: SectionKey) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navLinks: { label: string; sectionKey: SectionKey }[] = [
    { label: 'Home', sectionKey: 'home' },
    { label: 'Our Story', sectionKey: 'story' },
    { label: 'Moments', sectionKey: 'moments' },
    { label: 'Gallery', sectionKey: 'gallery' },
    { label: 'The Event', sectionKey: 'event' },
    { label: 'Guide', sectionKey: 'guide' },
    { label: 'Soundtrack', sectionKey: 'soundtrack' },
    { label: 'Honeymoon Fund', sectionKey: 'wishing-well' },
    { label: 'Toasts', sectionKey: 'toasts' },
    { label: 'RSVP', sectionKey: 'rsvp' },
  ];

  const handleLinkClick = (e: React.MouseEvent, sectionKey: SectionKey) => {
    e.preventDefault();
    if (onNavigate) {
      onNavigate(sectionKey);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-[#181716] text-[#A69F93] py-16 px-6 md:px-12 border-t border-white/10">
      <div className="max-w-6xl mx-auto flex flex-col items-center text-center space-y-10">
        {/* Monogram / Couple Name */}
        <div className="space-y-2">
          <span className="font-serif italic text-3xl sm:text-4xl text-[#F8F5F0]">
            {COUPLE_DATA.brideFirst} & {COUPLE_DATA.groomFirst}
          </span>
          <p className="text-xs uppercase tracking-[0.22em] text-[#D8C5A5] font-sans">
            Engagement Celebration • {HOME_DATE.display}
          </p>
        </div>

        {/* Small Navigation Links */}
        <nav className="flex flex-wrap items-center justify-center gap-6 text-xs uppercase tracking-[0.16em] text-[#A69F93]">
          {navLinks.map((link) => (
            <button
              key={link.label}
              onClick={(e) => handleLinkClick(e, link.sectionKey)}
              className="hover:text-[#F8F5F0] transition-colors cursor-pointer bg-transparent border-none p-0 text-inherit"
            >
              {link.label}
            </button>
          ))}
        </nav>

        {/* Scroll To Top Button */}
        <button
          onClick={scrollToTop}
          className="group inline-flex items-center gap-2 text-xs uppercase tracking-widest text-[#D8C5A5] hover:text-[#F8F5F0] transition-colors cursor-pointer"
          aria-label="Back to top of page"
        >
          <span>Return to Top</span>
          <ArrowUp className="w-3.5 h-3.5 group-hover:-translate-y-1 transition-transform" />
        </button>

        {/* Divider */}
        <div className="w-16 h-[1px] bg-white/10" />

        {/* Bottom Credits & Copyright */}
        <div className="space-y-2 text-xs text-[#7A746B] font-light">
          <p className="flex items-center justify-center gap-1.5">
            <span>Made with love for our family and friends.</span>
            <Heart className="w-3 h-3 text-[#B98F91] fill-[#B98F91]" />
          </p>
          <p className="text-[11px] text-[#5C564E]">
            © 2026 {COUPLE_DATA.brideFull} & {COUPLE_DATA.groomFull}. All rights reserved.
          </p>
          <p className="text-[10px] text-[#4F4A43] pt-1">
            Section-isolated architectural data design with co-located photography and story modules.
          </p>
        </div>
      </div>
    </footer>
  );
};
