import React from 'react';

interface FloralDividerProps {
  className?: string;
  variant?: 'diamond' | 'botanical' | 'minimal' | 'ring';
}

export const FloralDivider: React.FC<FloralDividerProps> = ({
  className = '',
  variant = 'minimal',
}) => {
  return (
    <div className={`flex items-center justify-center gap-3 my-8 text-[#D8C5A5] ${className}`}>
      <div className="h-[1px] w-12 md:w-20 bg-[#E5DFD5]" />
      
      {variant === 'minimal' && (
        <span className="w-1.5 h-1.5 rounded-full bg-[#D8C5A5]" />
      )}

      {variant === 'diamond' && (
        <div className="w-2 h-2 rotate-45 border border-[#B98F91] bg-[#F8F5F0]" />
      )}

      {variant === 'ring' && (
        <div className="flex items-center gap-1">
          <div className="w-2.5 h-2.5 rounded-full border border-[#D8C5A5]" />
          <div className="w-2.5 h-2.5 rounded-full border border-[#B98F91] -ml-1.5" />
        </div>
      )}

      {variant === 'botanical' && (
        <svg
          className="w-4 h-4 text-[#9BA595]"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M12 2a7 7 0 0 0-7 7c0 5 7 13 7 13s7-8 7-13a7 7 0 0 0-7-7z" opacity="0.3" />
          <circle cx="12" cy="9" r="2.5" />
        </svg>
      )}

      <div className="h-[1px] w-12 md:w-20 bg-[#E5DFD5]" />
    </div>
  );
};
