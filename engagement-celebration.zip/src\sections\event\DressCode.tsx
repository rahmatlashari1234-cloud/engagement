import React from 'react';
import { DRESS_CODE_DATA } from './eventData';
import { Sparkles, Info } from 'lucide-react';

export const DressCode: React.FC = () => {
  return (
    <section className="py-20 md:py-28 px-6 md:px-12 bg-[#F2ECE4] border-t border-[#E5DFD5]">
      <div className="max-w-4xl mx-auto text-center space-y-8">
        {/* Section Label */}
        <div className="inline-flex items-center gap-2">
          <Sparkles className="w-3.5 h-3.5 text-[#B98F91]" />
          <span className="text-[11px] uppercase tracking-[0.26em] text-[#6F6A63] font-semibold">
            Attire Inspiration
          </span>
        </div>

        <div className="space-y-3">
          <h3 className="font-serif text-3xl sm:text-4xl md:text-5xl text-[#20201E] font-normal tracking-tight">
            {DRESS_CODE_DATA.title}
          </h3>
          <p className="font-serif italic text-xl md:text-2xl text-[#6F6A63]">
            {DRESS_CODE_DATA.subtitle}
          </p>
        </div>

        <p className="max-w-2xl mx-auto text-sm md:text-base text-[#6F6A63] font-light leading-relaxed">
          {DRESS_CODE_DATA.description}
        </p>

        {/* Color Palette Inspiration Swatches */}
        <div className="pt-4">
          <span className="text-xs uppercase tracking-[0.2em] text-[#8C867E] block mb-4">
            Suggested Palette Shades
          </span>

          <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-6">
            {DRESS_CODE_DATA.palette.map((swatch, idx) => (
              <div key={idx} className="flex flex-col items-center gap-2 group">
                <div
                  className="w-12 h-12 rounded-full shadow-inner transition-transform group-hover:scale-110 duration-300"
                  style={{
                    backgroundColor: swatch.hex,
                    border: `1px solid ${swatch.border}`,
                  }}
                  title={swatch.name}
                />
                <span className="text-[11px] font-sans text-[#6F6A63] tracking-wider">
                  {swatch.name}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Footwear & Venue advisory note */}
        <div className="max-w-xl mx-auto p-4 bg-[#FAF8F5] border border-[#E5DFD5] text-left flex items-start gap-3 mt-6">
          <Info className="w-4 h-4 text-[#B98F91] shrink-0 mt-0.5" />
          <p className="text-xs text-[#6F6A63] leading-relaxed">
            {DRESS_CODE_DATA.footwearNote}
          </p>
        </div>
      </div>
    </section>
  );
};
