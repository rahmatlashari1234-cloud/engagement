import React, { useState } from 'react';
import { GALLERY_ITEMS } from '../../data/engagementContent';
import { OptimizedImage } from '../common/OptimizedImage';
import { LightboxModal } from '../modals/LightboxModal';
import { Eye } from 'lucide-react';

export const PhotoGallery: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<'all' | 'couple' | 'proposal' | 'details' | 'candid'>('all');
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);

  const categories = [
    { id: 'all', label: 'All Photographs' },
    { id: 'couple', label: 'Editorial Portraits' },
    { id: 'proposal', label: 'The Proposal' },
    { id: 'details', label: 'Heirloom & Details' },
    { id: 'candid', label: 'Candid Moments' },
  ] as const;

  const filteredItems = activeCategory === 'all'
    ? GALLERY_ITEMS
    : GALLERY_ITEMS.filter((item) => item.category === activeCategory);

  const handleOpenLightbox = (index: number) => {
    setCurrentIndex(index);
    setLightboxOpen(true);
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev === 0 ? filteredItems.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev === filteredItems.length - 1 ? 0 : prev + 1));
  };

  return (
    <section id="gallery" className="py-24 md:py-36 px-6 md:px-12 bg-[#F8F5F0]">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center space-y-4 mb-14 md:mb-20">
          <span className="text-[11px] tracking-[0.26em] uppercase text-[#B98F91] font-semibold">
            03 / Visual Poetry
          </span>
          <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl text-[#20201E] font-normal tracking-tight">
            Moments in Stillness
          </h2>
          <p className="max-w-xl mx-auto text-sm md:text-base text-[#6F6A63] font-light leading-relaxed">
            An intimate collection of memories captured across Hudson Valley, Positano, and the quiet spaces between.
          </p>

          {/* Category Filter Pills */}
          <div className="flex flex-wrap items-center justify-center gap-2 pt-6">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`px-4 py-2 text-xs uppercase tracking-[0.16em] transition-all duration-300 font-medium ${
                  activeCategory === cat.id
                    ? 'bg-[#20201E] text-[#F8F5F0] shadow-sm'
                    : 'bg-[#F2ECE4] text-[#6F6A63] hover:text-[#20201E] hover:bg-[#EAE2D7]'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Asymmetrical Editorial Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8 items-start">
          {filteredItems.map((item, idx) => {
            // Determine aspect ratio dynamically based on item configuration to produce intentional asymmetry
            let aspectClass = 'aspect-[4/5]';
            if (item.aspect === 'wide') aspectClass = 'aspect-[16/10]';
            if (item.aspect === 'square') aspectClass = 'aspect-square';

            return (
              <div
                key={item.id}
                onClick={() => handleOpenLightbox(idx)}
                className="group cursor-pointer relative overflow-hidden bg-[#EDE6DC] border border-[#E5DFD5] shadow-[0_4px_20px_rgba(32,32,30,0.03)] transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_12px_30px_rgba(32,32,30,0.08)]"
              >
                <div className={`w-full overflow-hidden ${aspectClass}`}>
                  <OptimizedImage
                    src={item.imageUrl}
                    alt={item.title}
                    className="w-full h-full group-hover:scale-104 transition-transform duration-700 ease-out"
                    objectFit="cover"
                  />
                </div>

                {/* Refined editorial caption overlay on hover */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#20201E]/75 via-[#20201E]/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6 text-white">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-[10px] tracking-[0.2em] uppercase text-[#D8C5A5] font-sans block mb-1">
                        {item.category}
                      </span>
                      <h4 className="font-serif text-xl font-normal leading-snug">
                        {item.title}
                      </h4>
                      <p className="text-xs text-white/80 font-light mt-1 line-clamp-1">
                        {item.caption}
                      </p>
                    </div>

                    <div className="p-2 rounded-full bg-white/20 backdrop-blur-sm self-end">
                      <Eye className="w-4 h-4 text-white" />
                    </div>
                  </div>
                </div>

                {/* Subtle base caption card for mobile accessibility and non-hover */}
                <div className="p-3.5 bg-[#FAF8F5] border-t border-[#E5DFD5]/60 flex items-center justify-between text-xs">
                  <span className="font-serif text-sm text-[#20201E]">{item.title}</span>
                  <span className="text-[10px] uppercase tracking-wider text-[#8C867E]">
                    {item.location || 'Editorial'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footnote note */}
        <p className="text-center text-xs text-[#8C867E] font-light mt-12 tracking-wider">
          Click any photograph to view high resolution imagery • Use arrow keys to navigate
        </p>
      </div>

      {/* Lightbox Modal */}
      <LightboxModal
        isOpen={lightboxOpen}
        currentIndex={currentIndex}
        items={filteredItems}
        onClose={() => setLightboxOpen(false)}
        onPrev={handlePrev}
        onNext={handleNext}
      />
    </section>
  );
};
