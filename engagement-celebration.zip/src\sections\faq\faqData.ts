export interface FaqItem {
  question: string;
  answer: string;
  category: string;
}

export const FAQ_META = {
  sectionNumber: "Guest Inquiries",
  heading: "Frequently Asked Questions",
  subheading: "Everything you need to know about our engagement celebration, logistics, and celebration etiquette.",
  coordinatorEmail: "celebration@ameliaanddaniel.com",
};

export const GUEST_FAQS: FaqItem[] = [
  {
    category: "Celebration",
    question: "Can I bring a plus-one?",
    answer: "Due to the intimate greenhouse capacity of the Glasshouse Conservatory, plus-ones are designated specifically on your formal invitation envelope and RSVP form. If your RSVP indicates 'Amelia Montgomery & Guest', you are warmly invited to bring a companion!"
  },
  {
    category: "Celebration",
    question: "Are children invited to the celebration?",
    answer: "While we adore your little ones, our engagement celebration will be an adults-only evening to allow all guests, including parents, an unhurried night of relaxation and revelry."
  },
  {
    category: "Ceremony",
    question: "What is your photography policy during the ceremony?",
    answer: "We kindly request an 'unplugged' ceremony. We invite you to be fully present with us as we exchange vows and blessings. Our professional editorial photographer and cinematographer will capture every moment, which we will joyfully share with you afterward! During cocktail hour and the evening reception, photographs are warmly welcomed."
  },
  {
    category: "Attire & Weather",
    question: "What will the weather be like in Hudson Valley in November?",
    answer: "Hudson Valley autumns are brisk and romantic, typically averaging 50°F (10°C) during late afternoon and dipping to 38°F (3°C) at night. The Conservatory is climate-controlled and heated with radiant floors and glass ceilings, but we recommend bringing a chic coat or wrap for the outdoor arrivals and garden terrace stroll."
  },
  {
    category: "Logistics",
    question: "Will transportation be provided from hotels?",
    answer: "Yes! Executive shuttles will depart from The Beekman Arms Hotel in Rhinebeck at 4:15 PM and 4:35 PM, returning continuously from 9:30 PM until midnight. Complimentary valet parking is also provided on-site for those driving directly."
  },
  {
    category: "Dietary",
    question: "How are dietary allergies and preferences accommodated?",
    answer: "Our culinary team from Stone Hill Estate crafts a bespoke seasonal three-course dinner. Vegetarian, vegan, gluten-free, dairy-free, and nut-allergy options will be provided seamlessly. Please ensure you indicate your dietary needs on the RSVP form."
  }
];
