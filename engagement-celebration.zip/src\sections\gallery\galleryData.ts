export interface GalleryItem {
  id: string;
  title: string;
  category: 'all' | 'couple' | 'proposal' | 'details' | 'candid';
  imageUrl: string;
  caption: string;
  aspect: 'tall' | 'wide' | 'square';
  location?: string;
}

export interface FeaturedPhoto {
  id: string;
  title: string;
  subtitle: string;
  location: string;
  imageUrl: string;
  category: 'couple' | 'details' | 'proposal';
}

export const GALLERY_META = {
  sectionNumber: "03 / Visual Poetry",
  headingPrefix: "THE GALLERY:",
  headingAccent: "cherished moments",
  quote: "A love story in every capture.",
  subheading: "An intimate collection of memories captured across Hudson Valley, Positano, and the quiet spaces between.",
};

export const FEATURED_TRIPTYCH: FeaturedPhoto[] = [
  {
    id: "ft-1",
    title: "The First Kiss",
    subtitle: "Playfair Display",
    location: "Meadow Arch • Falling Petals",
    imageUrl: "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=1200&q=85",
    category: "couple",
  },
  {
    id: "ft-2",
    title: "Elegant Reception",
    subtitle: "Lato",
    location: "Conservatory • Dusty Rose Centerpieces",
    imageUrl: "https://images.unsplash.com/photo-1519225421980-715cb0215aed?auto=format&fit=crop&w=1200&q=85",
    category: "details",
  },
  {
    id: "ft-3",
    title: "Our Hearts Entwined",
    subtitle: "Lato",
    location: "The Proposal • She Said Yes",
    imageUrl: "/images/engagement-ring-reveal.png",
    category: "proposal",
  },
];

export const GALLERY_CATEGORIES = [
  { id: 'all', label: 'All Photographs' },
  { id: 'couple', label: 'Editorial Portraits' },
  { id: 'proposal', label: 'The Proposal' },
  { id: 'details', label: 'Heirloom & Details' },
  { id: 'candid', label: 'Candid Moments' },
] as const;

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: "g0",
    title: "The Proposal — She Said Yes",
    category: "proposal",
    imageUrl: "/images/engagement-ring-reveal.png",
    caption: "The diamond ring catching the golden afternoon light — the moment our forever began.",
    aspect: "tall",
    location: "Golden Meadow"
  },
  {
    id: "g1",
    title: "Golden Hour Embrace",
    category: "couple",
    imageUrl: "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=1400&q=85",
    caption: "The golden warmth of late summer on the estate grounds.",
    aspect: "tall",
    location: "Hudson Valley, NY"
  },
  {
    id: "g2",
    title: "The Heirloom Diamond Ring",
    category: "details",
    imageUrl: "https://images.unsplash.com/photo-1605100804763-247f67b3557e?auto=format&fit=crop&w=1200&q=85",
    caption: "Hand-set antique oval diamond with delicate botanical band.",
    aspect: "square",
    location: "Positano, Italy"
  },
  {
    id: "g3",
    title: "The Glasshouse Conservatory",
    category: "details",
    imageUrl: "https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=1400&q=85",
    caption: "Our celebration venue bathed in natural conservatory light.",
    aspect: "wide",
    location: "Stone Hill Estate"
  },
  {
    id: "g4",
    title: "Intimate Whisper",
    category: "couple",
    imageUrl: "https://images.unsplash.com/photo-1583939003579-730e3918a45a?auto=format&fit=crop&w=1200&q=85",
    caption: "Quiet glances between chapters.",
    aspect: "tall",
    location: "Long Island Sound"
  },
  {
    id: "g5",
    title: "Dusty Rose & Garden Florals",
    category: "details",
    imageUrl: "https://images.unsplash.com/photo-1519225421980-715cb0215aed?auto=format&fit=crop&w=1200&q=85",
    caption: "Heirloom garden roses and eucalyptus foliage for our celebration.",
    aspect: "square",
    location: "Floral Studio"
  },
  {
    id: "g6",
    title: "A Toast to Forever",
    category: "candid",
    imageUrl: "https://images.unsplash.com/photo-1526047932273-341f2a7631f9?auto=format&fit=crop&w=1200&q=85",
    caption: "Vintage champagne flutes raised in intimate celebration.",
    aspect: "square",
    location: "Private Terrace"
  },
  {
    id: "g7",
    title: "Wildflower Walk",
    category: "couple",
    imageUrl: "https://images.unsplash.com/photo-1522673607200-164d1b6ce486?auto=format&fit=crop&w=1200&q=85",
    caption: "Walking hand in hand through the late autumn meadows.",
    aspect: "wide",
    location: "Catskill Foothills"
  },
  {
    id: "g8",
    title: "Candlelit Tablescape",
    category: "details",
    imageUrl: "https://images.unsplash.com/photo-1469371670807-013ccf25f16a?auto=format&fit=crop&w=1400&q=85",
    caption: "Linen, taper candles, and warm ceramics for our evening dinner.",
    aspect: "wide",
    location: "Conservatory Atrium"
  },
  {
    id: "g9",
    title: "Sunset Horizon",
    category: "proposal",
    imageUrl: "https://images.unsplash.com/photo-1470240731273-7821a6eeb6bd?auto=format&fit=crop&w=1400&q=85",
    caption: "The cliffside horizon moments after she said yes.",
    aspect: "tall",
    location: "Positano Balcony"
  },
  {
    id: "g10",
    title: "Laughter With Loved Ones",
    category: "candid",
    imageUrl: "https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&w=1400&q=85",
    caption: "Pure unscripted laughter with family upon sharing the news.",
    aspect: "wide",
    location: "Family Dinner"
  },
  {
    id: "g11",
    title: "The Hand We Hold",
    category: "proposal",
    imageUrl: "https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=1200&q=85",
    caption: "Clasping hands overlooking the sea, promised forever.",
    aspect: "tall",
    location: "Amalfi Coast"
  },
  {
    id: "g12",
    title: "Tender Light",
    category: "couple",
    imageUrl: "https://images.unsplash.com/photo-1537633552985-df8429e8048b?auto=format&fit=crop&w=1200&q=85",
    caption: "Soft morning light in our sunlit living room.",
    aspect: "square",
    location: "Our Loft"
  }
];
