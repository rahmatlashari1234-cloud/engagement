// Elegant ambient audio generator using Web Audio API
// Generates a soft, romantic, warm acoustic chord progression with natural decay
class AmbientAudioController {
  private ctx: AudioContext | null = null;
  private isPlaying: boolean = false;
  private timer: number | null = null;
  private masterGain: GainNode | null = null;

  private notes = [
    // F# minor9, E maj7, D maj9, A maj chords frequencies (tender, warm, cinematic)
    [220.00, 277.18, 329.63, 440.00], // A3, C#4, E4, A4
    [185.00, 220.00, 277.18, 370.00], // F#3, A3, C#4, F#4
    [146.83, 220.00, 277.18, 329.63], // D3, A3, C#4, E4
    [164.81, 246.94, 293.66, 329.63], // E3, B3, D4, E4
  ];
  private chordIndex = 0;

  private initContext() {
    if (!this.ctx) {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioContextClass();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(0.08, this.ctx.currentTime); // very soft & non-intrusive
      this.masterGain.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  private playGentleChord() {
    if (!this.ctx || !this.masterGain || !this.isPlaying) return;

    const chord = this.notes[this.chordIndex];
    this.chordIndex = (this.chordIndex + 1) % this.notes.length;
    const now = this.ctx.currentTime;

    chord.forEach((freq, i) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      
      // Soft sine + gentle triangle for warm Rhodes/acoustic piano character
      osc.type = i === 0 ? 'sine' : 'triangle';
      osc.frequency.setValueAtTime(freq, now + i * 0.15);

      // Low pass filter for warmth
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(800, now);

      gain.gain.setValueAtTime(0.0001, now + i * 0.15);
      gain.gain.exponentialRampToValueAtTime(0.04, now + i * 0.15 + 0.1);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.15 + 3.8);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain);

      osc.start(now + i * 0.15);
      osc.stop(now + i * 0.15 + 4.0);
    });
  }

  public toggle(): boolean {
    if (this.isPlaying) {
      this.stop();
      return false;
    } else {
      this.start();
      return true;
    }
  }

  public start() {
    this.initContext();
    this.isPlaying = true;
    this.playGentleChord();
    this.timer = window.setInterval(() => {
      if (this.isPlaying) {
        this.playGentleChord();
      }
    }, 4500);
  }

  public stop() {
    this.isPlaying = false;
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  public getStatus(): boolean {
    return this.isPlaying;
  }
}

export const ambientAudio = new AmbientAudioController();
