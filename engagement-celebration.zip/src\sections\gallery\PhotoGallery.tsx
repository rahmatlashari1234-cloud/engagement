import React, { useState } from 'react';
import {
  GALLERY_ITEMS,
  GALLERY_CATEGORIES,
  GALLERY_META,
  FEATURED_TRIPTYCH,
} from './galleryData';
import type { FeaturedPhoto, GalleryItem } from './galleryData';
import { OptimizedImage } from '../../components/common/OptimizedImage';
import { LightboxModal } from '../../components/modals/LightboxModal';
import { Eye, ChevronDown, ChevronUp, Sparkles, Rotate3d, LayoutGrid, BookOpen } from 'lucide-react';
import { TiltCard } from '../../components/common/TiltCard';
import { CurvedCylinderGallery } from '../../components/3d/CurvedCylinderGallery';
import { GoldFoilGlare } from '../../components/3d/GoldFoilGlare';
import { RealisticBook3D, type BookPlate } from '../../components/3d/RealisticBook3D';
import { LensPrismEffect } from '../../components/animations/LensPrismEffect';

export const PhotoGallery: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<'all' | 'couple' | 'proposal' | 'details' | 'candid'>('all');
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [lightboxList, setLightboxList] = useState<GalleryItem[]>(GALLERY_ITEMS);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showAllMoments, setShowAllMoments] = useState(false);
  const [viewLayout, setViewLayout] = useState<'3d-book' | '3d-cylinder' | 'editorial-grid'>('3d-book');

  const filteredItems =
    activeCategory === 'all'
      ? GALLERY_ITEMS
      : GALLERY_ITEMS.filter((item) => item.category === activeCategory);

  const bookPlates: BookPlate[] = filteredItems.map((item, idx) => ({
    id: item.id,
    title: item.title,
    subtitle: item.caption,
    category: item.category,
    imageUrl: item.imageUrl,
    location: item.location,
    date: 'October 2026',
    description: `Archival photographic plate ${idx + 1}. Captured on 35mm lens with cinematic natural lighting.`,
    plateNumber: String(idx + 1).padStart(2, '0'),
  }));

  const handleOpenLightbox = (index: number, items: GalleryItem[] = filteredItems) => {
    setLightboxList(items);
    setCurrentIndex(index);
    setLightboxOpen(true);
  };

  const handleOpenFeatured = (_featured: FeaturedPhoto, idx: number) => {
    // Map featured items to GalleryItem shape
    const featuredAsGallery: GalleryItem[] = FEATURED_TRIPTYCH.map((f) => ({
      id: f.id,
      title: f.title,
      category: f.category,
      imageUrl: f.imageUrl,
      caption: f.location,
      aspect: 'tall',
      location: f.location,
    }));
    handleOpenLightbox(idx, featuredAsGallery);
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev === 0 ? lightboxList.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev === lightboxList.length - 1 ? 0 : prev + 1));
  };

  return (
    <section
      id="gallery"
      className="py-20 md:py-32 px-6 md:px-12 bg-[#FAF8F5] relative overflow-hidden selection:bg-[#B98F91]/20 select-none-text"
    >
      {/* =========================================================================
          BOTANICAL & FLORAL DECORATIVE ELEMENTS (Delicate vines & scattered petals)
         ========================================================================= */}
      
      {/* Top-Left Botanical Leaf Vine */}
      <div className="absolute top-0 left-0 w-44 sm:w-64 md:w-80 h-auto pointer-events-none opacity-85 z-0 select-none">
        <svg
          viewBox="0 0 320 260"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full text-[#7B8B77]"
        >
          {/* Main Stem */}
          <path
            d="M -10 -10 C 60 40 120 70 190 120 C 240 160 270 200 290 260"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinecap="round"
            className="opacity-60"
          />
          {/* Secondary Delicate Branch */}
          <path
            d="M 60 40 C 110 30 160 50 200 80"
            stroke="currentColor"
            strokeWidth="1.2"
            strokeLinecap="round"
            className="opacity-50"
          />
          <path
            d="M 120 70 C 150 110 170 150 190 190"
            stroke="currentColor"
            strokeWidth="1.1"
            strokeLinecap="round"
            className="opacity-45"
          />

          {/* Leaf Clusters (Soft Olive & Sage Watercolor Gradients) */}
          <g fill="#889883" className="opacity-75">
            <path d="M 80 45 C 85 25 110 20 115 35 C 110 50 90 55 80 45 Z" />
            <path d="M 140 78 C 155 60 180 65 178 85 C 165 95 145 92 140 78 Z" />
            <path d="M 195 125 C 220 115 240 130 235 148 C 215 155 200 142 195 125 Z" />
            <path d="M 245 180 C 270 175 285 195 275 212 C 255 215 245 198 245 180 Z" />
            <path d="M 40 22 C 35 5 55 -5 68 8 C 65 24 50 30 40 22 Z" />
            <path d="M 160 52 C 180 40 200 48 198 62 C 182 70 168 62 160 52 Z" />
            <path d="M 170 160 C 160 180 175 200 190 195 C 195 178 185 165 170 160 Z" />
          </g>

          {/* Soft Champagne Gold Floral Accent Buds */}
          <g fill="#D8C5A5" className="opacity-90">
            <circle cx="118" cy="36" r="3.5" />
            <circle cx="180" cy="86" r="4" />
            <circle cx="236" cy="149" r="3" />
            <circle cx="277" cy="214" r="4.5" />
            <circle cx="200" cy="63" r="3" />
          </g>
        </svg>
      </div>

      {/* Top-Right Botanical Branch */}
      <div className="absolute top-0 right-0 w-36 sm:w-56 md:w-72 h-auto pointer-events-none opacity-80 z-0 select-none transform scale-x-[-1]">
        <svg
          viewBox="0 0 300 240"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full text-[#7B8B77]"
        >
          <path
            d="M -10 -10 C 50 30 110 60 170 100 C 220 140 250 180 270 240"
            stroke="currentColor"
            strokeWidth="1.5"
            strokeLinecap="round"
            className="opacity-55"
          />
          <g fill="#889883" className="opacity-70">
            <path d="M 70 38 C 75 18 100 15 105 28 C 100 42 80 48 70 38 Z" />
            <path d="M 130 68 C 145 52 170 56 168 74 C 155 84 135 80 130 68 Z" />
            <path d="M 185 110 C 210 102 228 116 223 132 C 205 138 190 126 185 110 Z" />
          </g>
          <g fill="#D8C5A5" className="opacity-85">
            <circle cx="107" cy="29" r="3.5" />
            <circle cx="170" cy="75" r="3.5" />
          </g>
        </svg>
      </div>

      {/* Bottom-Left & Bottom-Right Botanical Leaves */}
      <div className="absolute bottom-0 left-0 w-36 sm:w-52 h-auto pointer-events-none opacity-70 z-0 select-none transform scale-y-[-1]">
        <svg viewBox="0 0 260 200" fill="none" className="w-full h-full text-[#7B8B77]">
          <path d="M -5 -5 C 40 30 90 60 150 90 C 200 120 230 160 250 200" stroke="currentColor" strokeWidth="1.4" className="opacity-45" />
          <g fill="#889883" className="opacity-65">
            <path d="M 60 30 C 65 15 88 12 92 24 C 88 38 70 42 60 30 Z" />
            <path d="M 120 60 C 135 48 155 52 152 68 C 140 76 125 72 120 60 Z" />
          </g>
        </svg>
      </div>

      <div className="absolute bottom-0 right-0 w-44 sm:w-64 h-auto pointer-events-none opacity-80 z-0 select-none transform scale-[-1]">
        <svg viewBox="0 0 280 220" fill="none" className="w-full h-full text-[#7B8B77]">
          <path d="M -10 -10 C 60 35 120 65 180 110 C 225 150 250 190 270 240" stroke="currentColor" strokeWidth="1.5" className="opacity-55" />
          <g fill="#889883" className="opacity-75">
            <path d="M 80 40 C 85 20 110 18 115 32 C 108 45 90 50 80 40 Z" />
            <path d="M 140 72 C 158 55 180 60 178 78 C 162 88 145 84 140 72 Z" />
          </g>
          <g fill="#D8C5A5" className="opacity-80">
            <circle cx="117" cy="33" r="3.5" />
            <circle cx="180" cy="79" r="3.5" />
          </g>
        </svg>
      </div>

      {/* Scattered Soft Rose Petals (Organic Watercolor Gradients with Delicate Shadows) */}
      <div className="absolute top-28 left-8 sm:left-14 pointer-events-none z-10 transform -rotate-12">
        <svg width="24" height="34" viewBox="0 0 24 34" fill="none" className="drop-shadow-[0_4px_6px_rgba(185,143,145,0.22)]">
          <path
            d="M 12 2 C 20 8 23 20 17 29 C 12 36 4 31 2 24 C -1 15 5 4 12 2 Z"
            fill="url(#petal-grad-1)"
          />
          <defs>
            <linearGradient id="petal-grad-1" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#EBC6C8" />
              <stop offset="60%" stopColor="#D89D9F" />
              <stop offset="100%" stopColor="#B98F91" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      <div className="absolute top-44 right-10 sm:right-16 pointer-events-none z-10 transform rotate-45">
        <svg width="20" height="28" viewBox="0 0 20 28" fill="none" className="drop-shadow-[0_4px_6px_rgba(185,143,145,0.22)]">
          <path
            d="M 10 2 C 17 6 19 16 14 24 C 10 29 3 25 2 20 C 0 12 4 4 10 2 Z"
            fill="url(#petal-grad-2)"
          />
          <defs>
            <linearGradient id="petal-grad-2" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#F2D5D6" />
              <stop offset="70%" stopColor="#DC9E9F" />
              <stop offset="100%" stopColor="#C48C8F" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      <div className="absolute top-[52%] left-6 sm:left-12 pointer-events-none z-10 transform rotate-18">
        <svg width="18" height="26" viewBox="0 0 18 26" fill="none" className="drop-shadow-[0_3px_5px_rgba(185,143,145,0.2)]">
          <path d="M 9 2 C 15 6 17 15 13 22 C 9 27 3 24 2 18 C 0 11 4 4 9 2 Z" fill="#D89D9F" fillOpacity="0.85" />
        </svg>
      </div>

      <div className="absolute bottom-32 right-12 sm:right-20 pointer-events-none z-10 transform -rotate-30">
        <svg width="22" height="30" viewBox="0 0 22 30" fill="none" className="drop-shadow-[0_4px_6px_rgba(185,143,145,0.2)]">
          <path
            d="M 11 2 C 18 7 21 17 15 25 C 11 31 3 27 2 21 C -1 13 4 4 11 2 Z"
            fill="url(#petal-grad-1)"
          />
        </svg>
      </div>

      <div className="absolute bottom-20 left-16 sm:left-24 pointer-events-none z-10 transform rotate-60">
        <svg width="16" height="22" viewBox="0 0 16 22" fill="none" className="drop-shadow-[0_2px_4px_rgba(185,143,145,0.2)]">
          <path d="M 8 2 C 13 5 15 13 11 19 C 8 23 2 20 1 15 C 0 10 3 3 8 2 Z" fill="#E2A6A8" fillOpacity="0.9" />
        </svg>
      </div>

      {/* =========================================================================
          MAIN GALLERY CONTENT CONTAINER
         ========================================================================= */}
      <div className="max-w-6xl mx-auto relative z-10">
        
        {/* Monogram Seal Badge Header with 3D Gold Foil Sheen */}
        <div className="flex flex-col items-center justify-center mb-6">
          <GoldFoilGlare intensity={1.2}>
            <div className="w-12 h-12 rounded-full border border-[#D8C5A5] flex items-center justify-center bg-[#FAF8F5] shadow-xs relative">
              <div className="w-10 h-10 rounded-full border border-[#D8C5A5]/60 flex items-center justify-center">
                <span className="font-serif text-xs text-[#20201E] tracking-widest font-normal">
                  A &amp; D
                </span>
              </div>
              <Sparkles className="w-2.5 h-2.5 text-[#D8C5A5] absolute -top-1 -right-1" />
            </div>
          </GoldFoilGlare>
        </div>

        {/* Minimalist Serif Typography Header */}
        <div className="text-center space-y-3 mb-8 md:mb-10">
          <span className="text-[10px] uppercase tracking-[0.28em] text-[#8C867E] font-medium block">
            {GALLERY_META.sectionNumber}
          </span>
          <h2 className="font-serif text-3xl sm:text-5xl md:text-6xl text-[#20201E] font-normal tracking-tight">
            <span>{GALLERY_META.headingPrefix} </span>
            <span className="italic font-serif font-normal text-[#B98F91]">
              {GALLERY_META.headingAccent}
            </span>
          </h2>
          <p className="max-w-lg mx-auto text-xs sm:text-sm text-[#6F6A63] font-light leading-relaxed">
            {GALLERY_META.subheading}
          </p>
        </div>

        {/* 3D Photobook vs 3D Spatial Cylinder vs Editorial Grid Switcher */}
        <div className="flex items-center justify-center gap-2 mb-10 z-20 relative">
          <div className="p-1 bg-[#FAF8F5] border border-[#D8C5A5] rounded-full shadow-xs inline-flex items-center gap-1">
            <button
              onClick={() => setViewLayout('3d-book')}
              className={`px-4 py-1.5 rounded-full text-[11px] uppercase tracking-widest font-sans transition-all cursor-pointer flex items-center gap-1.5 ${
                viewLayout === '3d-book'
                  ? 'bg-[#20201E] text-white shadow-xs font-medium'
                  : 'text-[#6F6A63] hover:text-[#20201E]'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5 text-[#D8C5A5]" />
              <span>3D Real-Turn Photobook</span>
            </button>
            <button
              onClick={() => setViewLayout('3d-cylinder')}
              className={`px-4 py-1.5 rounded-full text-[11px] uppercase tracking-widest font-sans transition-all cursor-pointer flex items-center gap-1.5 ${
                viewLayout === '3d-cylinder'
                  ? 'bg-[#20201E] text-white shadow-xs font-medium'
                  : 'text-[#6F6A63] hover:text-[#20201E]'
              }`}
            >
              <Rotate3d className="w-3.5 h-3.5 text-[#D8C5A5]" />
              <span>3D Spatial Cylinder</span>
            </button>
            <button
              onClick={() => setViewLayout('editorial-grid')}
              className={`px-4 py-1.5 rounded-full text-[11px] uppercase tracking-widest font-sans transition-all cursor-pointer flex items-center gap-1.5 ${
                viewLayout === 'editorial-grid'
                  ? 'bg-[#20201E] text-white shadow-xs font-medium'
                  : 'text-[#6F6A63] hover:text-[#20201E]'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span>Editorial Grid</span>
            </button>
          </div>
        </div>

        {/* VIEW 1: 3D REAL-TURN PHOTOBOOK (Authentic Page Peel & Turn Physics) */}
        {viewLayout === '3d-book' ? (
          <div className="mb-14">
            {/* Category Filter Pills for Book View */}
            <div className="flex flex-wrap items-center justify-center gap-2 mb-6">
              {GALLERY_CATEGORIES.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`px-4 py-1.5 text-xs uppercase tracking-[0.16em] transition-all duration-300 font-medium rounded-xs cursor-pointer ${
                    activeCategory === cat.id
                      ? 'bg-[#20201E] text-[#F8F5F0] shadow-xs'
                      : 'bg-[#F2ECE4] text-[#6F6A63] hover:text-[#20201E] hover:bg-[#EAE2D7]'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            <RealisticBook3D
              plates={bookPlates}
              onImageClick={(url) => {
                const idx = filteredItems.findIndex((it) => it.imageUrl === url);
                handleOpenLightbox(idx >= 0 ? idx : 0, filteredItems);
              }}
            />
          </div>
        ) : viewLayout === '3d-cylinder' ? (
          <div className="mb-14">
            {/* Category Filter Pills for 3D View */}
            <div className="flex flex-wrap items-center justify-center gap-2 mb-6">
              {GALLERY_CATEGORIES.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`px-4 py-1.5 text-xs uppercase tracking-[0.16em] transition-all duration-300 font-medium rounded-xs cursor-pointer ${
                    activeCategory === cat.id
                      ? 'bg-[#20201E] text-[#F8F5F0] shadow-xs'
                      : 'bg-[#F2ECE4] text-[#6F6A63] hover:text-[#20201E] hover:bg-[#EAE2D7]'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            <CurvedCylinderGallery
              items={filteredItems}
              onOpenLightbox={(idx) => handleOpenLightbox(idx, filteredItems)}
            />
          </div>
        ) : (
          /* VIEW 3: FLAT EDITORIAL TRIPTYCH & EXPANDABLE GRID */
          <>
            {/* FEATURED TRIPTYCH */}
            <div className="mb-14 relative">
              <div className="p-4 sm:p-6 md:p-8 bg-[#FAF8F5]/90 border border-[#D8C5A5]/60 shadow-[0_12px_36px_rgba(32,32,30,0.04)] relative">
            
            {/* 3-Column Clean Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-7 items-stretch">
              {FEATURED_TRIPTYCH.map((photo, idx) => (
                <TiltCard key={photo.id} maxTilt={3.5} scale={1.015} glare={true} className="h-full">
                  <div
                    onClick={() => handleOpenFeatured(photo, idx)}
                    className="group cursor-pointer bg-[#FFFFFF] border border-[#D8C5A5] p-3 sm:p-3.5 flex flex-col justify-between h-full shadow-[0_4px_16px_rgba(32,32,30,0.03)] hover:shadow-[0_12px_30px_rgba(32,32,30,0.08)] transition-all duration-500"
                  >
                    {/* Image Container with Inner Matting & 35mm Lens Prism Flare */}
                    <LensPrismEffect className="relative aspect-[3/4] overflow-hidden bg-[#EDE6DC] border border-[#E5DFD5]">
                      <OptimizedImage
                        src={photo.imageUrl}
                        alt={photo.title}
                        animation="zoom-hover"
                        cornerAccents={false}
                        className="w-full h-full"
                        objectFit="cover"
                      />

                      {/* Hover Specular Glare & Expand Prompt */}
                      <div className="absolute inset-0 bg-[#20201E]/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                        <div className="px-3 py-1.5 bg-[#FAF8F5]/95 text-[#20201E] text-[10px] tracking-widest uppercase font-sans border border-[#D8C5A5] shadow-sm transform scale-90 group-hover:scale-100 transition-transform duration-300 flex items-center gap-1.5">
                          <Eye className="w-3.5 h-3.5 text-[#B98F91]" />
                          <span>View Full</span>
                        </div>
                      </div>
                    </LensPrismEffect>

                    {/* Editorial Captions (Matching Reference Layout) */}
                    <div className="pt-4 pb-1 text-center space-y-1">
                      <h3 className="font-serif text-lg sm:text-xl text-[#20201E] font-normal leading-snug tracking-tight">
                        {photo.title}
                      </h3>
                      <p className="text-[11px] text-[#8C867E] font-light tracking-wide font-sans">
                        {photo.subtitle}
                      </p>
                      <p className="text-[9px] uppercase tracking-widest text-[#B98F91] font-mono pt-0.5">
                        {photo.location}
                      </p>
                    </div>
                  </div>
                </TiltCard>
              ))}
            </div>

            {/* Editorial Footer Quote & Navigation Bridge */}
            <div className="mt-8 pt-6 border-t border-[#E5DFD5]/80 flex flex-col sm:flex-row items-center justify-between gap-4">
              <p className="font-serif italic text-base sm:text-lg text-[#20201E] font-normal text-center sm:text-left">
                “{GALLERY_META.quote}”
              </p>

              <button
                onClick={() => setShowAllMoments(!showAllMoments)}
                className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.2em] font-medium text-[#20201E] hover:text-[#B98F91] transition-colors pb-1 border-b border-[#20201E] hover:border-[#B98F91] cursor-pointer"
              >
                <span>{showAllMoments ? 'Hide Extended Archive' : 'More Moments'}</span>
                {showAllMoments ? (
                  <ChevronUp className="w-3.5 h-3.5" />
                ) : (
                  <ChevronDown className="w-3.5 h-3.5" />
                )}
              </button>
            </div>
          </div>
        </div>

        {/* =========================================================================
            EXTENDED ARCHIVE / CATEGORIZED GALLERY (Toggled or Browsed)
           ========================================================================= */}
        {showAllMoments && (
          <div className="animate-fade-in pt-4 border-t border-[#D8C5A5]/40">
            {/* Category Filter Pills */}
            <div className="flex flex-wrap items-center justify-center gap-2 mb-10">
              {GALLERY_CATEGORIES.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`px-4 py-2 text-xs uppercase tracking-[0.16em] transition-all duration-300 font-medium ${
                    activeCategory === cat.id
                      ? 'bg-[#20201E] text-[#F8F5F0] shadow-xs'
                      : 'bg-[#F2ECE4] text-[#6F6A63] hover:text-[#20201E] hover:bg-[#EAE2D7]'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            {/* Full Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-7 items-start">
              {filteredItems.map((item, idx) => {
                let aspectClass = 'aspect-[4/5]';
                if (item.aspect === 'wide') aspectClass = 'aspect-[16/10]';
                if (item.aspect === 'square') aspectClass = 'aspect-square';

                return (
                  <TiltCard key={item.id} maxTilt={4} scale={1.015} glare={true}>
                    <div
                      onClick={() => handleOpenLightbox(idx, filteredItems)}
                      className="group cursor-pointer relative overflow-hidden bg-[#EDE6DC] border border-[#E5DFD5] shadow-[0_6px_20px_rgba(32,32,30,0.04)] transition-shadow duration-500 hover:shadow-[0_16px_36px_rgba(32,32,30,0.1)]"
                    >
                      <div className={`w-full overflow-hidden ${aspectClass} relative`}>
                        <OptimizedImage
                          src={item.imageUrl}
                          alt={item.title}
                          animation="zoom-hover"
                          cornerAccents={true}
                          curtainReveal={true}
                          className="w-full h-full"
                          objectFit="cover"
                        />

                        {/* Plate Number */}
                        <div className="absolute top-3 left-3 z-10 pointer-events-none">
                          <span className="px-2 py-0.5 bg-[#20201E]/40 backdrop-blur-xs text-white/90 font-mono text-[9px] tracking-widest uppercase border border-white/10">
                            Plate {String(idx + 1).padStart(2, '0')}
                          </span>
                        </div>
                      </div>

                      {/* Overlay */}
                      <div className="absolute inset-0 bg-gradient-to-t from-[#20201E]/85 via-[#20201E]/25 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6 text-white">
                        <div className="flex items-center justify-between transform transition-transform duration-300 translate-y-2 group-hover:translate-y-0">
                          <div>
                            <span className="text-[10px] tracking-[0.2em] uppercase text-[#D8C5A5] font-sans block mb-1">
                              {item.category}
                            </span>
                            <h4 className="font-serif text-xl font-normal leading-snug">
                              {item.title}
                            </h4>
                            <p className="text-xs text-white/80 font-light mt-1 line-clamp-1">
                              {item.caption}
                            </p>
                          </div>

                          <div className="p-2.5 rounded-full bg-white/20 backdrop-blur-sm self-end border border-white/20 transition-transform duration-300 group-hover:scale-110">
                            <Eye className="w-4 h-4 text-white" />
                          </div>
                        </div>
                      </div>

                      {/* Base Caption */}
                      <div className="p-3.5 bg-[#FAF8F5] border-t border-[#E5DFD5]/60 flex items-center justify-between text-xs">
                        <span className="font-serif text-sm text-[#20201E]">{item.title}</span>
                        <span className="text-[10px] uppercase tracking-wider text-[#8C867E]">
                          {item.location || 'Editorial'}
                        </span>
                      </div>
                    </div>
                  </TiltCard>
                );
              })}
            </div>

            <p className="text-center text-xs text-[#8C867E] font-light mt-10 tracking-wider">
              Click any photograph to view high resolution imagery • Use arrow keys to navigate
            </p>
          </div>
        )}
          </>
        )}
      </div>

      {/* Lightbox Modal */}
      <LightboxModal
        isOpen={lightboxOpen}
        currentIndex={currentIndex}
        items={lightboxList}
        onClose={() => setLightboxOpen(false)}
        onPrev={handlePrev}
        onNext={handleNext}
      />
    </section>
  );
};
