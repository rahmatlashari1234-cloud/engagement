import React, { useState } from 'react';
import { INITIAL_TOASTS } from '../../data/engagementContent';
import type { ToastItem } from '../../data/engagementContent';
import { Heart, MessageSquareQuote, Plus, Check, X } from 'lucide-react';

export const ToastBook: React.FC = () => {
  const [toasts, setToasts] = useState<ToastItem[]>(INITIAL_TOASTS);
  const [modalOpen, setModalOpen] = useState(false);
  const [authorName, setAuthorName] = useState('');
  const [relationship, setRelationship] = useState('');
  const [message, setMessage] = useState('');
  const [submittedToast, setSubmittedToast] = useState(false);

  const handleSubmitToast = (e: React.FormEvent) => {
    e.preventDefault();
    if (!authorName.trim() || !message.trim()) return;

    const newToast: ToastItem = {
      id: `toast-${Date.now()}`,
      author: authorName.trim(),
      relationship: relationship.trim() || 'Cherished Friend',
      message: message.trim(),
      date: 'Just now',
    };

    setToasts([newToast, ...toasts]);
    setSubmittedToast(true);

    setTimeout(() => {
      setAuthorName('');
      setRelationship('');
      setMessage('');
      setSubmittedToast(false);
      setModalOpen(false);
    }, 1800);
  };

  return (
    <section id="toasts" className="py-24 md:py-36 px-6 md:px-12 bg-[#FAF8F5] border-t border-[#E5DFD5]/80">
      <div className="max-w-6xl mx-auto space-y-16">
        {/* Section Header */}
        <div className="text-center space-y-4 max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-2">
            <MessageSquareQuote className="w-3.5 h-3.5 text-[#B98F91]" />
            <span className="text-[11px] uppercase tracking-[0.28em] text-[#6F6A63] font-semibold">
              Words of Love & Wisdom
            </span>
          </div>
          <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl text-[#20201E] font-normal tracking-tight">
            The Digital Toast Book
          </h2>
          <p className="text-sm md:text-base text-[#6F6A63] font-light leading-relaxed">
            Read heartfelt toasts and memories from our loved ones, or leave your own blessing for our journey ahead.
          </p>

          <div className="pt-2">
            <button
              onClick={() => setModalOpen(true)}
              className="inline-flex items-center gap-2 px-6 py-3 bg-[#20201E] text-[#F8F5F0] text-xs uppercase tracking-[0.18em] font-medium hover:bg-[#383733] transition-colors shadow-sm"
            >
              <Plus className="w-3.5 h-3.5 text-[#D8C5A5]" />
              <span>Leave a Toast for Amelia & Daniel</span>
            </button>
          </div>
        </div>

        {/* Staggered Masonry Board of Toasts */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
          {toasts.map((item, idx) => {
            const isOffset = idx % 2 === 1;

            return (
              <div
                key={item.id}
                className={`p-8 bg-[#F8F5F0] border border-[#E5DFD5] shadow-[0_6px_25px_rgba(32,32,30,0.02)] space-y-4 relative group hover:border-[#D8C5A5] transition-colors ${
                  isOffset ? 'md:mt-8' : ''
                }`}
              >
                <div className="flex items-center justify-between border-b border-[#E5DFD5]/70 pb-3">
                  <div>
                    <h4 className="font-serif text-xl text-[#20201E]">
                      {item.author}
                    </h4>
                    <span className="text-[11px] text-[#B98F91] uppercase tracking-wider font-sans block">
                      {item.relationship}
                    </span>
                  </div>

                  <span className="text-[10px] text-[#8C867E] uppercase tracking-widest font-mono">
                    {item.date}
                  </span>
                </div>

                <p className="text-sm text-[#6F6A63] font-light leading-relaxed italic font-serif text-base pt-1">
                  “{item.message}”
                </p>

                <div className="pt-2 flex items-center justify-end text-[#D8C5A5]">
                  <Heart className="w-3.5 h-3.5 fill-current opacity-40 group-hover:opacity-100 transition-opacity" />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Leave a Toast Modal */}
      {modalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-[#161514]/75 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in"
          onClick={() => setModalOpen(false)}
        >
          <div
            className="bg-[#F8F5F0] border border-[#E5DFD5] max-w-lg w-full p-8 shadow-2xl relative space-y-6"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setModalOpen(false)}
              aria-label="Close"
              className="absolute top-4 right-4 p-1.5 text-[#6F6A63] hover:text-[#20201E]"
            >
              <X className="w-5 h-5" />
            </button>

            {submittedToast ? (
              <div className="text-center py-8 space-y-3 animate-fade-in">
                <div className="w-12 h-12 rounded-full bg-[#9BA595]/20 text-[#9BA595] flex items-center justify-center mx-auto">
                  <Check className="w-6 h-6" />
                </div>
                <h4 className="font-serif text-2xl text-[#20201E]">Toast Published!</h4>
                <p className="text-xs text-[#6F6A63]">
                  Your warm words have been added to the celebration book with love.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmitToast} className="space-y-4">
                <div className="space-y-1">
                  <span className="text-[10px] uppercase tracking-wider text-[#B98F91] font-medium">
                    Guest Keepsake
                  </span>
                  <h3 className="font-serif text-3xl text-[#20201E]">
                    Write a Toast
                  </h3>
                  <p className="text-xs text-[#6F6A63]">
                    Share a memory, piece of advice, or blessing for Amelia & Daniel.
                  </p>
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] uppercase tracking-wider text-[#6F6A63] block">
                    Your Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Aunt Victoria & Uncle Henry"
                    value={authorName}
                    onChange={(e) => setAuthorName(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-[#E5DFD5] text-sm text-[#20201E] focus:outline-none focus:border-[#20201E]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] uppercase tracking-wider text-[#6F6A63] block">
                    Relationship to the Couple
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. University Roommate, Cousin, Family Friend"
                    value={relationship}
                    onChange={(e) => setRelationship(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-[#E5DFD5] text-sm text-[#20201E] focus:outline-none focus:border-[#20201E]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] uppercase tracking-wider text-[#6F6A63] block">
                    Your Heartfelt Toast *
                  </label>
                  <textarea
                    rows={4}
                    required
                    placeholder="Write your blessing, favorite story, or congratulations..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-[#E5DFD5] text-sm text-[#20201E] focus:outline-none focus:border-[#20201E] resize-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 bg-[#20201E] text-[#F8F5F0] text-xs uppercase tracking-[0.2em] font-medium hover:bg-[#383733] transition-colors mt-2"
                >
                  Publish Toast
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </section>
  );
};
