export const RSVP_META = {
  sectionNumber: "06 / Kindly Respond",
  heading: "We’d Love to Celebrate With You",
  deadline: "October 20, 2026",
  email: "celebration@ameliaanddaniel.com",
  celebrationDateDisplay: "Saturday, November 14, 2026",
  dietaryOptions: [
    'None / No restrictions',
    'Vegetarian',
    'Vegan',
    'Gluten-Free',
    'Dairy-Free',
    'Nut Allergy',
  ],
};
