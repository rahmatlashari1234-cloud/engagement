export interface MomentItem {
  id: string;
  number: string;
  title: string;
  subtitle: string;
  story: string;
  date: string;
  imageUrl: string;
  imageAlt: string;
  quote?: string;
}

export const MOMENTS_META = {
  sectionNumber: "04 / Intimate Chronicles",
  heading: "Moments We Keep",
  subheading: "The small, quiet milestones that anchor our journey and hold our greatest joy.",
};

export const MOMENTS_WE_KEEP: MomentItem[] = [
  {
    id: "moment-1",
    number: "01",
    title: "That First Hello",
    subtitle: "A rainy Tuesday in Manhattan",
    story: "We both reached for the same vintage hardcover at the Strand Bookstore before realizing we had also ordered the exact same cortado ten minutes earlier. What began as an apologetic laugh became the beginning of every tomorrow.",
    date: "Autumn 2021",
    imageUrl: "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=1200&q=85",
    imageAlt: "The first hello",
    quote: "“You didn’t just enter my life; you gave it context.”"
  },
  {
    id: "moment-2",
    number: "02",
    title: "The Day Everything Changed",
    subtitle: "A silent morning at Montauk Point",
    story: "Watching the Atlantic horizon wrap in dense morning mist, wrapped in a single wool blanket. Without uttering a word, we both understood that whatever the world brought next, we would meet it as one.",
    date: "Spring 2023",
    imageUrl: "https://images.unsplash.com/photo-1583939003579-730e3918a45a?auto=format&fit=crop&w=1200&q=85",
    imageAlt: "Montauk Point morning",
    quote: "“In your quiet, I found the certainty I had searched for my whole life.”"
  },
  {
    id: "moment-3",
    number: "03",
    title: "Sunsets in Positano",
    subtitle: "Overlooking the Tyrrhenian Sea",
    story: "Warm breezes carrying the scent of rosemary and lemon trees. We spent hours watching small wooden fishing boats return to the shore as the cliffside villas lit up like amber constellations.",
    date: "Summer 2026",
    imageUrl: "https://images.unsplash.com/photo-1470240731273-7821a6eeb6bd?auto=format&fit=crop&w=1200&q=85",
    imageAlt: "Sunset over the coastline",
    quote: "“Time stood completely still, and the world belonged solely to us.”"
  },
  {
    id: "moment-4",
    number: "04",
    title: "The Question",
    subtitle: "August 29, 2026 • Golden Hour",
    story: "With a custom antique oval ring crafted from his grandmother's heirloom gold, Daniel asked for a lifetime together. The tears that followed were sweeter than any speech either of us could have rehearsed.",
    date: "August 2026",
    imageUrl: "https://images.unsplash.com/photo-1605100804763-247f67b3557e?auto=format&fit=crop&w=1200&q=85",
    imageAlt: "The ring and proposal moment",
    quote: "“Yes, a million times yes.”"
  },
  {
    id: "moment-5",
    number: "05",
    title: "The Beginning of Forever",
    subtitle: "The promise we carry forward",
    story: "Here we stand: grounded by gratitude, surrounded by family, and ready to walk together through every season that life brings. The past was beautiful, but our story has only just begun.",
    date: "November 2026",
    imageUrl: "https://images.unsplash.com/photo-1522673607200-164d1b6ce486?auto=format&fit=crop&w=1200&q=85",
    imageAlt: "Walking together into forever",
    quote: "“To love and to be loved is to feel the sun from both sides.”"
  }
];
