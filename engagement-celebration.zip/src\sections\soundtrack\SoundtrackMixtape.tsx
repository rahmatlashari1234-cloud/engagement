import React, { useState } from 'react';
import { SOUNDTRACK_TRACKS, SOUNDTRACK_META } from './soundtrackData';
import { Play, Pause, Disc, ExternalLink, Music2, Sparkles } from 'lucide-react';
import { ambientAudio } from '../../utils/audioPlayer';

export const SoundtrackMixtape: React.FC = () => {
  const [selectedTrack, setSelectedTrack] = useState(SOUNDTRACK_TRACKS[0]);
  const [isPlaying, setIsPlaying] = useState(false);

  const handlePlayToggle = (track: typeof SOUNDTRACK_TRACKS[0]) => {
    setSelectedTrack(track);
    const nowPlaying = ambientAudio.toggle();
    setIsPlaying(nowPlaying);
  };

  return (
    <section id="soundtrack" className="py-24 md:py-36 px-6 md:px-12 bg-[#FAF8F5] border-t border-[#E5DFD5]/80 overflow-hidden animate-fade-in select-none">
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <div className="text-center space-y-3 mb-16 md:mb-20">
          <div className="inline-flex items-center gap-2">
            <Music2 className="w-3.5 h-3.5 text-[#B98F91]" />
            <span className="text-[11px] uppercase tracking-[0.28em] text-[#6F6A63] font-semibold">
              3D Turntable Experience
            </span>
          </div>
          <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl text-[#20201E] font-normal tracking-tight">
            {SOUNDTRACK_META.heading}
          </h2>
          <p className="text-sm md:text-base text-[#6F6A63] font-light max-w-xl mx-auto">
            {SOUNDTRACK_META.subheading}
          </p>
        </div>

        {/* 3D Vinyl Player Deck & Tracklist Grid */}
        <div className="bg-[#F8F5F0] border border-[#E5DFD5] shadow-[0_20px_50px_rgba(32,32,30,0.06)] grid grid-cols-1 lg:grid-cols-12 items-stretch overflow-hidden">
          
          {/* Left Column: 3D Turntable Plinth Deck */}
          <div className="lg:col-span-6 p-8 sm:p-12 bg-[#1A1918] text-white flex flex-col justify-between relative overflow-hidden">
            {/* Ambient Warm Backlight */}
            <div className="absolute top-0 right-0 w-80 h-80 bg-[#B98F91]/15 rounded-full blur-3xl pointer-events-none" />

            {/* Turntable Brand Badge */}
            <div className="flex items-center justify-between relative z-10 border-b border-white/10 pb-4">
              <div>
                <span className="text-[10px] uppercase tracking-[0.26em] text-[#D8C5A5] block">
                  Hi-Fi Audiophile Deck • 33 ⅓ RPM
                </span>
                <h3 className="font-serif text-2xl sm:text-3xl font-light text-[#FAF8F5]">
                  Amelia & Daniel
                </h3>
              </div>

              <div className="flex items-center gap-2 text-xs text-[#D8C5A5]">
                <Sparkles className="w-3.5 h-3.5" />
                <span className="font-mono text-[11px]">STEREO</span>
              </div>
            </div>

            {/* Turntable Platter & 3D Tonearm Stage */}
            <div className="my-10 relative flex items-center justify-center min-h-[260px] sm:min-h-[300px]">
              
              {/* Platter Base Ring */}
              <div className="w-56 h-56 sm:w-64 sm:h-64 rounded-full bg-[#262422] border-4 border-[#33302C] shadow-2xl flex items-center justify-center relative">
                
                {/* Vinyl Record */}
                <div
                  className={`w-52 h-52 sm:w-60 sm:h-60 rounded-full bg-[#121110] border-2 border-[#22201D] shadow-inner flex items-center justify-center relative transition-transform duration-700 ${
                    isPlaying ? 'animate-spin-slow' : ''
                  }`}
                >
                  {/* Concentric Vinyl Grooves with metallic light refraction */}
                  <div className="w-44 h-44 rounded-full border border-white/5" />
                  <div className="w-36 h-36 rounded-full border border-white/5" />
                  <div className="w-28 h-28 rounded-full border border-white/10" />
                  <div className="w-20 h-20 rounded-full border border-white/5" />

                  {/* Vinyl Specular Light Angle Sheen */}
                  <div
                    className="absolute inset-0 rounded-full pointer-events-none opacity-20"
                    style={{
                      background: 'conic-gradient(from 45deg, transparent 0deg, rgba(255,255,255,0.4) 45deg, transparent 90deg, transparent 180deg, rgba(255,255,255,0.4) 225deg, transparent 270deg)',
                    }}
                  />

                  {/* Center Paper Label */}
                  <div className="w-18 h-18 rounded-full bg-[#B98F91] border-2 border-[#D8C5A5] flex flex-col items-center justify-center text-center p-1 shadow-md z-10">
                    <span className="font-serif italic text-white text-xs font-semibold leading-tight">
                      A & D
                    </span>
                    <span className="text-[7px] uppercase tracking-widest text-[#FAF8F5]/80 font-mono">
                      AUTUMN '26
                    </span>
                    <div className="w-2 h-2 rounded-full bg-[#121110] mt-1 shadow-inner" />
                  </div>
                </div>
              </div>

              {/* 3D Brass Metallic Tonearm with Pivot Action */}
              <div className="absolute top-2 right-4 sm:right-8 z-20 pointer-events-none">
                {/* Arm Pivot Base */}
                <div className="w-8 h-8 rounded-full bg-[#3D3731] border-2 border-[#D8C5A5] shadow-lg flex items-center justify-center relative">
                  <div className="w-3 h-3 rounded-full bg-[#D8C5A5]" />
                </div>

                {/* Metallic Tonearm Wand */}
                <div
                  className="w-1.5 h-36 sm:h-44 bg-gradient-to-b from-[#D8C5A5] via-[#C5AE8A] to-[#8C7A5E] shadow-xl origin-top transition-transform duration-700 ease-out"
                  style={{
                    transform: isPlaying ? 'rotate(26deg) translateY(-2px)' : 'rotate(0deg)',
                    marginLeft: '13px',
                    marginTop: '-2px',
                    borderRadius: '2px',
                  }}
                >
                  {/* Cartridge Head & Stylus Needle */}
                  <div className="absolute bottom-0 -left-1.5 w-4 h-6 bg-[#20201E] border border-[#D8C5A5] shadow-md flex items-center justify-center">
                    <div className="w-1 h-1 bg-[#B98F91] rounded-full" />
                  </div>
                </div>
              </div>
            </div>

            {/* Currently Playing Track Controls & Live Visualizer */}
            <div className="pt-4 border-t border-white/10 relative z-10 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-serif text-xl sm:text-2xl text-[#FAF8F5]">
                    {selectedTrack.title}
                  </h4>
                  <p className="text-xs text-[#D8C5A5] font-light">
                    {selectedTrack.artist} • {selectedTrack.year}
                  </p>
                </div>

                {/* Big Circular Play Button */}
                <button
                  onClick={() => handlePlayToggle(selectedTrack)}
                  aria-label={isPlaying ? 'Pause turntable' : 'Play turntable'}
                  className="w-12 h-12 rounded-full bg-[#FAF8F5] text-[#20201E] flex items-center justify-center hover:scale-108 transition-transform cursor-pointer shadow-lg"
                >
                  {isPlaying ? (
                    <Pause className="w-5 h-5 fill-[#20201E]" />
                  ) : (
                    <Play className="w-5 h-5 fill-[#20201E] ml-0.5" />
                  )}
                </button>
              </div>

              {/* Dynamic Soundwave Equalizer */}
              {isPlaying && (
                <div className="flex items-center gap-1 pt-1">
                  <span className="text-[10px] uppercase tracking-widest text-[#D8C5A5] mr-2 font-mono">
                    PLAYING
                  </span>
                  {[40, 75, 50, 90, 60, 30, 80, 55, 95, 45, 70, 85].map((h, i) => (
                    <div
                      key={i}
                      className="w-1 bg-[#B98F91] rounded-full animate-pulse"
                      style={{
                        height: `${h * 0.22}px`,
                        animationDelay: `${i * 90}ms`,
                      }}
                    />
                  ))}
                </div>
              )}

              <p className="text-xs text-white/70 italic font-light pt-1">
                “{selectedTrack.note}”
              </p>
            </div>
          </div>

          {/* Right Column: Tracklist & Spotify Link */}
          <div className="lg:col-span-6 p-8 sm:p-12 flex flex-col justify-between space-y-8">
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-[#E5DFD5]">
                <span className="text-xs uppercase tracking-[0.2em] text-[#8C867E]">
                  Select Track to Spin
                </span>
                <span className="text-xs text-[#8C867E] font-mono">
                  {SOUNDTRACK_TRACKS.length} Tracks
                </span>
              </div>

              <div className="space-y-3">
                {SOUNDTRACK_TRACKS.map((track, idx) => {
                  const isCurrent = selectedTrack.id === track.id;

                  return (
                    <div
                      key={track.id}
                      onClick={() => handlePlayToggle(track)}
                      className={`p-4 border transition-all cursor-pointer flex items-center justify-between group ${
                        isCurrent
                          ? 'border-[#B98F91] bg-[#F2ECE4] shadow-sm translate-x-1'
                          : 'border-[#E5DFD5] bg-[#FAF8F5] hover:border-[#D8C5A5]'
                      }`}
                    >
                      <div className="flex items-center gap-4">
                        <span className="font-serif text-lg text-[#8C867E] w-6">
                          0{idx + 1}
                        </span>
                        <div>
                          <h4 className="font-serif text-lg text-[#20201E] group-hover:text-[#B98F91] transition-colors leading-tight">
                            {track.title}
                          </h4>
                          <span className="text-xs text-[#6F6A63] font-light">
                            {track.artist}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-4 text-xs text-[#8C867E]">
                        <span className="font-mono hidden sm:inline">{track.duration}</span>
                        <div
                          className={`w-8 h-8 rounded-full border flex items-center justify-center transition-colors ${
                            isCurrent && isPlaying
                              ? 'border-[#B98F91] bg-[#B98F91] text-white shadow-sm'
                              : 'border-[#E5DFD5] group-hover:border-[#20201E]'
                          }`}
                        >
                          {isCurrent && isPlaying ? (
                            <Disc className="w-4 h-4 animate-spin-slow" />
                          ) : (
                            <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="pt-6 border-t border-[#E5DFD5] flex flex-wrap items-center justify-between gap-4">
              <span className="text-xs text-[#6F6A63] font-light">
                Listen to the full engagement playlist on Spotify
              </span>
              <a
                href={SOUNDTRACK_META.spotifyUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.16em] text-[#20201E] font-medium hover:text-[#B98F91] transition-colors"
              >
                <span>Open Spotify Playlist</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
