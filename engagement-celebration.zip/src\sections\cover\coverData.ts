export interface CoverContent {
  recipient: string;
  dedicationText: string;
  tapPrompt: string;
  tagline: string;
  letter: {
    salutation: string;
    subtitle: string;
    bodyParagraph1: string;
    bodyParagraph2: string;
    eventDate: string;
    eventVenue: string;
    signoff: string;
    signatures: string;
  };
}

export const COVER_DEFAULT_DATA: CoverContent = {
  recipient: "Amelia",
  dedicationText: "For My Amelia",
  tapPrompt: "Tap to open your surprise",
  tagline: "A PRIVATE CELEBRATION INVITATION",
  letter: {
    salutation: "To My Dearest Amelia,",
    subtitle: "The Beginning of Our Forever",
    bodyParagraph1: "From the quiet moment our paths first crossed, every step has led to this certainty. You bring warmth to every morning, laughter to every adventure, and a gentle grace that makes anywhere feel like home.",
    bodyParagraph2: "Together with our cherished families, I am overjoyed to celebrate our engagement and welcome this brand-new chapter of love, devotion, and forever.",
    eventDate: "Saturday, November 14, 2026",
    eventVenue: "Stone Hill Estate • Hudson Valley, New York",
    signoff: "With all my love & whole heart,",
    signatures: "Forever & Always"
  }
};
