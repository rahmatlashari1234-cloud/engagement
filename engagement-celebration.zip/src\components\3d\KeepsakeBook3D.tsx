import React, { useState } from 'react';
import { STORY_MILESTONES, type Milestone } from '../../sections/story/storyData';
import { OptimizedImage } from '../common/OptimizedImage';
import { ChevronLeft, ChevronRight, BookOpen, Calendar, MapPin, Sparkles, Eye } from 'lucide-react';
import { PhotoFloralFlourish } from '../common/FloralDecorations';

interface KeepsakeBook3DProps {
  onImageClick?: (imageUrl: string, title: string) => void;
  className?: string;
}

export const KeepsakeBook3D: React.FC<KeepsakeBook3DProps> = ({
  onImageClick,
  className = '',
}) => {
  const [currentPage, setCurrentPage] = useState(0);
  const [isFlipping, setIsFlipping] = useState(false);
  const [flipDirection, setFlipDirection] = useState<'next' | 'prev'>('next');

  const totalPages = STORY_MILESTONES.length;
  const currentMilestone: Milestone = STORY_MILESTONES[currentPage];

  const handleNextPage = () => {
    if (currentPage >= totalPages - 1 || isFlipping) return;
    setFlipDirection('next');
    setIsFlipping(true);
    setTimeout(() => {
      setCurrentPage((prev) => prev + 1);
      setIsFlipping(false);
    }, 450);
  };

  const handlePrevPage = () => {
    if (currentPage <= 0 || isFlipping) return;
    setFlipDirection('prev');
    setIsFlipping(true);
    setTimeout(() => {
      setCurrentPage((prev) => prev - 1);
      setIsFlipping(false);
    }, 450);
  };

  return (
    <div className={`w-full max-w-5xl mx-auto py-10 select-none ${className}`}>
      {/* 3D Perspective Book Stage */}
      <div
        className="relative mx-auto flex items-center justify-center p-3 sm:p-6"
        style={{ perspective: '2000px' }}
      >
        {/* Outer Hardcover Shadow & Edge Spine */}
        <div className="relative w-full max-w-4xl bg-[#1C1B19] p-3 sm:p-5 rounded-md shadow-[0_30px_70px_rgba(0,0,0,0.35)] border border-[#D8C5A5]/40">
          
          {/* Gold Stamped Book Edge Trim */}
          <div className="absolute inset-x-4 top-1.5 h-[1px] bg-gradient-to-r from-transparent via-[#D8C5A5]/60 to-transparent" />
          <div className="absolute inset-x-4 bottom-1.5 h-[1px] bg-gradient-to-r from-transparent via-[#D8C5A5]/60 to-transparent" />

          {/* OPEN TWO-PAGE SPREAD (Left & Right Pages) */}
          <div 
            className={`grid grid-cols-1 md:grid-cols-2 bg-[#FAF8F5] border border-[#E5DFD5] relative overflow-hidden rounded-xs min-h-[460px] sm:min-h-[500px] transition-all duration-300 ${
              isFlipping
                ? flipDirection === 'next'
                  ? 'opacity-80 scale-[0.99] [transform:rotateY(-3deg)]'
                  : 'opacity-80 scale-[0.99] [transform:rotateY(3deg)]'
                : 'opacity-100 scale-100 [transform:rotateY(0deg)]'
            }`}
          >
            
            {/* Center Spine Depth Shadow */}
            <div className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 w-8 pointer-events-none hidden md:block z-30 bg-gradient-to-r from-black/15 via-black/25 to-black/15 opacity-60" />
            <div className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 w-[1px] bg-[#D8C5A5]/80 pointer-events-none hidden md:block z-30" />

            {/* LEFT PAGE: Narrative & Archival Notes */}
            <div className="p-6 sm:p-10 md:pr-12 flex flex-col justify-between border-b md:border-b-0 md:border-r border-[#E5DFD5] relative">
              {/* Parchment Watermark */}
              <div className="space-y-4 relative z-10">
                <div className="flex items-center justify-between border-b border-[#E5DFD5] pb-3">
                  <span className="text-[10px] uppercase tracking-[0.24em] text-[#8C867E] font-mono">
                    Chapter {String(currentPage + 1).padStart(2, '0')} of {String(totalPages).padStart(2, '0')}
                  </span>
                  <span className="font-serif italic text-xs text-[#B98F91]">
                    {currentMilestone.year}
                  </span>
                </div>

                <div className="pt-2">
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#B98F91]/10 text-[#B98F91] text-[10px] uppercase tracking-wider font-semibold">
                    <Sparkles className="w-2.5 h-2.5" />
                    <span>{currentMilestone.tag}</span>
                  </span>
                  <h3 className="font-serif text-2xl sm:text-3xl text-[#20201E] font-normal mt-2 leading-tight">
                    {currentMilestone.title}
                  </h3>
                </div>

                <p className="text-[#6F6A63] text-sm sm:text-base font-light leading-relaxed">
                  {currentMilestone.description}
                </p>

                <div className="pt-2 space-y-1.5 text-xs text-[#8C867E]">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-3.5 h-3.5 text-[#D8C5A5]" />
                    <span className="font-sans uppercase tracking-wider text-[11px]">{currentMilestone.date}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5 text-[#889883]" />
                    <span className="font-sans tracking-wide">{currentMilestone.location}</span>
                  </div>
                </div>
              </div>

              {/* Left Page Footer */}
              <div className="pt-6 border-t border-[#E5DFD5]/80 flex items-center justify-between text-xs text-[#8C867E]">
                <span className="font-serif italic text-xs">Amelia &amp; Daniel</span>
                <span className="font-mono text-[10px]">p. {currentPage * 2 + 1}</span>
              </div>
            </div>

            {/* RIGHT PAGE: Archival Photograph Mounted with Corner Tabs */}
            <div className="p-6 sm:p-10 md:pl-12 flex flex-col justify-between bg-[#F8F5F0] relative">
              <div className="flex-1 flex flex-col items-center justify-center relative">
                {/* Mounted Photo Card with 3D Specular Border */}
                <div
                  onClick={() => onImageClick && onImageClick(currentMilestone.imageUrl, currentMilestone.title)}
                  className="relative group cursor-pointer w-full max-w-[340px] aspect-[4/3] sm:aspect-[16/11] bg-white p-2.5 sm:p-3 border border-[#D8C5A5] shadow-lg transition-transform duration-300 hover:scale-[1.02]"
                >
                  <PhotoFloralFlourish position="top-right" className="opacity-80" />
                  
                  <div className="relative w-full h-full overflow-hidden bg-[#EDE6DC]">
                    <OptimizedImage
                      src={currentMilestone.imageUrl}
                      alt={currentMilestone.imageAlt}
                      className="w-full h-full"
                      objectFit="cover"
                    />

                    {/* Expand overlay */}
                    <div className="absolute inset-0 bg-[#20201E]/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <span className="px-3 py-1 bg-white/95 text-[#20201E] text-[10px] uppercase tracking-widest font-sans border border-[#D8C5A5] flex items-center gap-1 shadow-sm">
                        <Eye className="w-3 h-3 text-[#B98F91]" />
                        <span>Inspect</span>
                      </span>
                    </div>
                  </div>

                  {/* Polaroid handwritten caption */}
                  <div className="pt-2 text-center">
                    <span className="font-serif italic text-xs text-[#20201E]">
                      {currentMilestone.title}
                    </span>
                  </div>
                </div>
              </div>

              {/* Right Page Footer */}
              <div className="pt-6 border-t border-[#E5DFD5]/80 flex items-center justify-between text-xs text-[#8C867E]">
                <span className="text-[10px] uppercase tracking-widest font-sans">Photographic Plate</span>
                <span className="font-mono text-[10px]">p. {currentPage * 2 + 2}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 3D Page Turn Controls */}
      <div className="flex items-center justify-center gap-6 mt-6">
        <button
          onClick={handlePrevPage}
          disabled={currentPage === 0}
          className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-xs border text-xs uppercase tracking-widest font-medium transition-all cursor-pointer ${
            currentPage === 0
              ? 'opacity-40 border-[#E5DFD5] text-[#8C867E] cursor-not-allowed'
              : 'border-[#D8C5A5] bg-[#FAF8F5] text-[#20201E] hover:bg-[#20201E] hover:text-[#FAF8F5]'
          }`}
        >
          <ChevronLeft className="w-3.5 h-3.5" />
          <span>Previous Page</span>
        </button>

        <div className="flex items-center gap-1.5 text-xs text-[#8C867E] font-mono">
          <BookOpen className="w-3.5 h-3.5 text-[#B98F91]" />
          <span>{currentPage + 1} / {totalPages}</span>
        </div>

        <button
          onClick={handleNextPage}
          disabled={currentPage === totalPages - 1}
          className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-xs border text-xs uppercase tracking-widest font-medium transition-all cursor-pointer ${
            currentPage === totalPages - 1
              ? 'opacity-40 border-[#E5DFD5] text-[#8C867E] cursor-not-allowed'
              : 'border-[#D8C5A5] bg-[#FAF8F5] text-[#20201E] hover:bg-[#20201E] hover:text-[#FAF8F5]'
          }`}
        >
          <span>Next Page</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
