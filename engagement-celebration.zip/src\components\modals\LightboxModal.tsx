import React, { useEffect, useCallback } from 'react';
import { X, ChevronLeft, ChevronRight, MapPin } from 'lucide-react';
import type { GalleryItem } from '../../data/engagementContent';
import { SilkVeilReveal } from '../animations/SilkVeilReveal';
import { LensPrismEffect } from '../animations/LensPrismEffect';

interface LightboxModalProps {
  isOpen: boolean;
  currentIndex: number;
  items: GalleryItem[];
  onClose: () => void;
  onPrev: () => void;
  onNext: () => void;
}

export const LightboxModal: React.FC<LightboxModalProps> = ({
  isOpen,
  currentIndex,
  items,
  onClose,
  onPrev,
  onNext,
}) => {
  const currentItem = items[currentIndex];

  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      if (!isOpen) return;
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowLeft') onPrev();
      if (e.key === 'ArrowRight') onNext();
    },
    [isOpen, onClose, onPrev, onNext]
  );

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    } else {
      document.body.style.overflow = 'unset';
    }

    return () => {
      document.body.style.overflow = 'unset';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, handleKeyDown]);

  if (!isOpen || !currentItem) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Image Lightbox"
      className="fixed inset-0 z-50 bg-[#161514]/94 backdrop-blur-md flex items-center justify-center p-4 md:p-8 animate-fade-in select-none"
      onClick={onClose}
    >
      {/* Top Controls Bar */}
      <div
        className="absolute top-0 left-0 right-0 p-6 flex items-center justify-between z-10 text-white/80"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-3">
          <span className="font-serif italic text-base text-[#D8C5A5]">
            Amelia & Daniel
          </span>
          <span className="text-white/30">•</span>
          <span className="text-xs uppercase tracking-widest text-white/60 font-sans">
            Photo {currentIndex + 1} of {items.length}
          </span>
        </div>

        <button
          onClick={onClose}
          aria-label="Close Lightbox"
          className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Prev Button */}
      <button
        onClick={(e) => {
          e.stopPropagation();
          onPrev();
        }}
        aria-label="Previous photograph"
        className="absolute left-4 md:left-8 top-1/2 -translate-y-1/2 p-3 rounded-full bg-black/40 hover:bg-black/70 text-white transition-all z-20 group"
      >
        <ChevronLeft className="w-6 h-6 group-hover:-translate-x-0.5 transition-transform" />
      </button>

      {/* Next Button */}
      <button
        onClick={(e) => {
          e.stopPropagation();
          onNext();
        }}
        aria-label="Next photograph"
        className="absolute right-4 md:right-8 top-1/2 -translate-y-1/2 p-3 rounded-full bg-black/40 hover:bg-black/70 text-white transition-all z-20 group"
      >
        <ChevronRight className="w-6 h-6 group-hover:translate-x-0.5 transition-transform" />
      </button>

      {/* Image Content Container */}
      <div
        className="max-w-5xl max-h-[85vh] flex flex-col items-center justify-center"
        onClick={(e) => e.stopPropagation()}
      >
        <SilkVeilReveal isOpen={isOpen} className="max-h-[75vh]">
          <LensPrismEffect className="relative overflow-hidden bg-black/50 border border-white/10 shadow-2xl max-h-[75vh] group">
            <img
              key={currentItem.id || currentItem.imageUrl}
              src={currentItem.imageUrl}
              alt={currentItem.title}
              className="max-h-[75vh] max-w-full w-auto object-contain transition-all duration-500 animate-fade-in"
            />
            {/* Subtle Corner Exhibition Marks */}
            <div className="absolute top-3 left-3 w-3 h-3 border-t border-l border-white/40 pointer-events-none" />
            <div className="absolute top-3 right-3 w-3 h-3 border-t border-r border-white/40 pointer-events-none" />
            <div className="absolute bottom-3 left-3 w-3 h-3 border-b border-l border-white/40 pointer-events-none" />
            <div className="absolute bottom-3 right-3 w-3 h-3 border-b border-r border-white/40 pointer-events-none" />
          </LensPrismEffect>
        </SilkVeilReveal>

        {/* Caption & Location metadata */}
        <div className="mt-4 text-center text-white/90 max-w-xl">
          <h4 className="font-serif text-xl sm:text-2xl font-light text-[#FAF8F5]">
            {currentItem.title}
          </h4>
          <p className="text-xs sm:text-sm text-white/70 font-light mt-1">
            {currentItem.caption}
          </p>
          {currentItem.location && (
            <div className="inline-flex items-center gap-1.5 mt-2 text-[11px] text-[#D8C5A5] uppercase tracking-wider">
              <MapPin className="w-3 h-3 text-[#B98F91]" />
              <span>{currentItem.location}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
