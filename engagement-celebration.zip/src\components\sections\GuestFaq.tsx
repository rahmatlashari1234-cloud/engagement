import React, { useState } from 'react';
import { GUEST_FAQS } from '../../data/engagementContent';
import { ChevronDown, HelpCircle } from 'lucide-react';

export const GuestFaq: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleAccordion = (idx: number) => {
    setOpenIndex(openIndex === idx ? null : idx);
  };

  return (
    <section className="py-24 md:py-36 px-6 md:px-12 bg-[#FAF8F5] border-t border-[#E5DFD5]/80">
      <div className="max-w-4xl mx-auto space-y-16">
        {/* Section Header */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-2">
            <HelpCircle className="w-3.5 h-3.5 text-[#B98F91]" />
            <span className="text-[11px] uppercase tracking-[0.28em] text-[#6F6A63] font-semibold">
              Guest Inquiries
            </span>
          </div>
          <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl text-[#20201E] font-normal tracking-tight">
            Frequently Asked Questions
          </h2>
          <p className="text-sm md:text-base text-[#6F6A63] font-light max-w-lg mx-auto">
            Everything you need to know about our engagement celebration, logistics, and celebration etiquette.
          </p>
        </div>

        {/* Hairline Minimalist Accordion */}
        <div className="divide-y divide-[#E5DFD5] border-y border-[#E5DFD5]">
          {GUEST_FAQS.map((faq, idx) => {
            const isOpen = openIndex === idx;

            return (
              <div key={idx} className="transition-colors">
                <button
                  onClick={() => toggleAccordion(idx)}
                  className="w-full py-6 md:py-8 flex items-center justify-between text-left group transition-all"
                  aria-expanded={isOpen}
                >
                  <div className="flex items-start md:items-center gap-4 pr-6">
                    <span className="text-xs uppercase tracking-widest text-[#B98F91] font-mono mt-0.5 md:mt-0">
                      0{idx + 1}
                    </span>
                    <h3 className="font-serif text-xl sm:text-2xl text-[#20201E] group-hover:text-[#B98F91] transition-colors">
                      {faq.question}
                    </h3>
                  </div>

                  <div
                    className={`w-7 h-7 rounded-full border border-[#E5DFD5] flex items-center justify-center shrink-0 transition-transform duration-300 ${
                      isOpen ? 'rotate-180 bg-[#20201E] text-white border-[#20201E]' : 'group-hover:border-[#20201E]'
                    }`}
                  >
                    <ChevronDown className="w-3.5 h-3.5" />
                  </div>
                </button>

                {isOpen && (
                  <div className="pb-8 pl-9 md:pl-10 text-xs sm:text-sm text-[#6F6A63] font-light leading-relaxed max-w-2xl animate-fade-in">
                    <p>{faq.answer}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="text-center pt-2">
          <p className="text-xs text-[#8C867E]">
            Have a question not listed here? Email our celebration coordinator at{' '}
            <a
              href="mailto:celebration@ameliaanddaniel.com"
              className="text-[#20201E] underline hover:text-[#B98F91]"
            >
              celebration@ameliaanddaniel.com
            </a>
          </p>
        </div>
      </div>
    </section>
  );
};
