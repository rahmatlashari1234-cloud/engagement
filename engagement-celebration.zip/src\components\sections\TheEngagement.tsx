import React from 'react';
import { SITE_CONFIG } from '../../data/engagementContent';
import { OptimizedImage } from '../common/OptimizedImage';
import { Sparkles, Heart } from 'lucide-react';

interface TheEngagementProps {
  onImageClick?: (imageUrl: string, title: string) => void;
}

export const TheEngagement: React.FC<TheEngagementProps> = ({ onImageClick }) => {
  return (
    <section className="py-24 md:py-36 px-6 md:px-12 bg-[#F8F5F0] relative overflow-hidden border-t border-[#E5DFD5]/60">
      <div className="max-w-6xl mx-auto">
        {/* Subtle decorative top ornament */}
        <div className="flex items-center justify-center gap-2 mb-6 text-[#B98F91]">
          <span className="w-8 h-[1px] bg-[#E5DFD5]" />
          <Sparkles className="w-3.5 h-3.5 text-[#B98F91]" />
          <span className="w-8 h-[1px] bg-[#E5DFD5]" />
        </div>

        {/* Section Heading */}
        <div className="text-center space-y-4 max-w-3xl mx-auto mb-16 md:mb-24">
          <span className="text-xs uppercase tracking-[0.28em] text-[#8C867E] font-medium">
            The Moment That Changed Everything
          </span>
          <h2 className="font-serif text-5xl sm:text-6xl md:text-7xl text-[#20201E] font-normal tracking-tight">
            {SITE_CONFIG.editorial.engagementSectionHeading}
          </h2>
          
          <div className="py-2 inline-flex items-center gap-3 px-5 py-1.5 border border-[#D8C5A5] bg-[#FAF8F5]">
            <Heart className="w-3 h-3 text-[#B98F91] fill-[#B98F91]" />
            <span className="font-serif text-lg md:text-xl text-[#20201E] tracking-wide">
              {SITE_CONFIG.celebrationDate.engagementDate}
            </span>
            <span className="text-[#8C867E] text-xs uppercase tracking-widest font-sans">
              • {SITE_CONFIG.celebrationDate.engagementLocation}
            </span>
          </div>

          <p className="text-[#6F6A63] text-base md:text-lg font-light leading-relaxed pt-2">
            {SITE_CONFIG.editorial.engagementNarrative}
          </p>
        </div>

        {/* Refined Asymmetric 3-Photo Editorial Composition */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-stretch">
          {/* Main Large Centerpiece Photo */}
          <div
            onClick={() =>
              onImageClick &&
              onImageClick(
                'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=1400&q=85',
                'The Proposal in Positano'
              )
            }
            className="md:col-span-7 relative group cursor-pointer overflow-hidden bg-[#EDE6DC] border border-[#E5DFD5] shadow-[0_12px_30px_rgba(32,32,30,0.05)]"
          >
            <OptimizedImage
              src="https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=1400&q=85"
              alt="Hands held with engagement ring"
              aspectRatio="4/3"
              className="w-full h-full group-hover:scale-102 transition-transform duration-700 ease-out"
              objectFit="cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#20201E]/60 via-transparent to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />
            <div className="absolute bottom-6 left-6 text-white">
              <span className="text-[10px] uppercase tracking-[0.2em] text-[#D8C5A5] font-sans block mb-1">
                The Vow
              </span>
              <p className="font-serif text-2xl md:text-3xl font-light">
                “With every breath, yes.”
              </p>
            </div>
          </div>

          {/* Right Column with 2 Stacked Detail Photos */}
          <div className="md:col-span-5 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-1 gap-6">
            {/* Top Detail: Heirloom Ring Close-up */}
            <div
              onClick={() =>
                onImageClick &&
                onImageClick(
                  'https://images.unsplash.com/photo-1605100804763-247f67b3557e?auto=format&fit=crop&w=1200&q=85',
                  'The Antique Oval Diamond Ring'
                )
              }
              className="relative group cursor-pointer overflow-hidden bg-[#EDE6DC] border border-[#E5DFD5] shadow-[0_8px_20px_rgba(32,32,30,0.04)]"
            >
              <OptimizedImage
                src="https://images.unsplash.com/photo-1605100804763-247f67b3557e?auto=format&fit=crop&w=1200&q=85"
                alt="Heirloom antique diamond ring"
                aspectRatio="16/10"
                className="w-full group-hover:scale-102 transition-transform duration-700 ease-out"
                objectFit="cover"
              />
              <div className="p-4 bg-[#FAF8F5] border-t border-[#E5DFD5] flex items-center justify-between">
                <div>
                  <span className="text-[10px] uppercase tracking-widest text-[#8C867E] block">
                    The Ring
                  </span>
                  <span className="font-serif text-base text-[#20201E]">
                    Antique Oval Diamond
                  </span>
                </div>
                <span className="text-xs text-[#B98F91] font-serif italic">
                  Crafted 1948
                </span>
              </div>
            </div>

            {/* Bottom Detail: Intimate Embrace */}
            <div
              onClick={() =>
                onImageClick &&
                onImageClick(
                  'https://images.unsplash.com/photo-1583939003579-730e3918a45a?auto=format&fit=crop&w=1200&q=85',
                  'Quiet embrace at dusk'
                )
              }
              className="relative group cursor-pointer overflow-hidden bg-[#EDE6DC] border border-[#E5DFD5] shadow-[0_8px_20px_rgba(32,32,30,0.04)]"
            >
              <OptimizedImage
                src="https://images.unsplash.com/photo-1583939003579-730e3918a45a?auto=format&fit=crop&w=1200&q=85"
                alt="Intimate tender couple portrait"
                aspectRatio="16/10"
                className="w-full group-hover:scale-102 transition-transform duration-700 ease-out"
                objectFit="cover"
              />
              <div className="p-4 bg-[#FAF8F5] border-t border-[#E5DFD5] flex items-center justify-between">
                <div>
                  <span className="text-[10px] uppercase tracking-widest text-[#8C867E] block">
                    The Atmosphere
                  </span>
                  <span className="font-serif text-base text-[#20201E]">
                    Cliffside Twilight
                  </span>
                </div>
                <span className="text-xs text-[#9BA595] font-serif italic">
                  Positano
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
