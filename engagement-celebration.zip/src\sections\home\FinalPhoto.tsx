import React from 'react';
import { COUPLE_DATA, HOME_DATE } from './homeData';
import { OptimizedImage } from '../../components/common/OptimizedImage';
import { BotanicalVine, RosePetal } from '../../components/common/FloralDecorations';

export const FinalPhoto: React.FC = () => {
  return (
    <section className="relative w-full h-[70vh] sm:h-[80vh] md:h-[90vh] overflow-hidden bg-[#1F1E1C]">
      {/* Botanical Corner Vines & Drifting Petals Framing Photo */}
      <BotanicalVine position="top-left" size="lg" opacity={0.5} />
      <BotanicalVine position="top-right" size="lg" opacity={0.5} />
      <div className="absolute top-24 left-10 pointer-events-none z-10">
        <RosePetal variant={1} rotate={-25} scale={1} />
      </div>
      <div className="absolute top-36 right-12 pointer-events-none z-10">
        <RosePetal variant={2} rotate={35} scale={0.9} />
      </div>
      {/* Cinematic Full-bleed Photograph with Ken Burns Ambient Motion */}
      <OptimizedImage
        src="https://images.unsplash.com/photo-1470240731273-7821a6eeb6bd?auto=format&fit=crop&w=2200&q=85"
        alt="Amelia and Daniel sunset horizon portrait"
        animation="ken-burns"
        curtainReveal={true}
        className="w-full h-full"
        objectFit="cover"
        objectPosition="center 60%"
      />

      {/* Gentle Editorial Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-[#1F1E1C]/80 via-transparent to-[#1F1E1C]/30 pointer-events-none" />

      {/* Minimal Centered Overlay Text */}
      <div className="absolute inset-0 flex flex-col items-center justify-end pb-16 md:pb-24 px-6 text-center text-white pointer-events-none">
        <span className="text-[11px] sm:text-xs uppercase tracking-[0.3em] text-[#D8C5A5] mb-3 font-sans">
          Forever Begins
        </span>
        <h2 className="font-serif text-4xl sm:text-6xl md:text-7xl font-normal tracking-tight text-[#F8F5F0]">
          {COUPLE_DATA.brideFirst}{' '}
          <span className="font-serif italic text-[#B98F91]">&</span>{' '}
          {COUPLE_DATA.groomFirst}
        </h2>
        <p className="mt-3 text-xs sm:text-sm uppercase tracking-[0.2em] text-white/80 font-sans font-light">
          {HOME_DATE.display}
        </p>
      </div>
    </section>
  );
};
