export interface HoneymoonItem {
  id: string;
  title: string;
  destination: string;
  description: string;
  amount: string;
  imageUrl: string;
  tag: string;
}

export const WISHING_WELL_META = {
  sectionNumber: "Wishing Well & Experiences",
  heading: "The Honeymoon Fund",
  subheading: "Your presence at our celebration is the greatest gift of all. If you wish to honor our engagement with a blessing, we invite you to contribute toward shared memories on our upcoming adventures in Japan and Italy.",
  envelopeNote: "A physical wishing well envelope box will also be available on the evening of the celebration.",
};

export const HONEYMOON_EXPERIENCES: HoneymoonItem[] = [
  {
    id: "gift-1",
    title: "Kyoto Heritage Ryokan & Onsen Stay",
    destination: "Kyoto, Japan",
    description: "Two nights in a tranquil wooden ryokan in the Arashiyama bamboo forest with traditional multi-course kaiseki dinner.",
    amount: "$350",
    imageUrl: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=800&q=80",
    tag: "Honeymoon Escape"
  },
  {
    id: "gift-2",
    title: "Cliffside Dinner Overlooking Ravello",
    destination: "Amalfi Coast, Italy",
    description: "An intimate candlelit dinner among terraced lemon groves and sea breezes where we reminisce about our proposal.",
    amount: "$220",
    imageUrl: "https://images.unsplash.com/photo-1533105079780-92b9be482077?auto=format&fit=crop&w=800&q=80",
    tag: "Romantic Evening"
  },
  {
    id: "gift-3",
    title: "Artisanal Ceramic Workshop",
    destination: "Tokyo, Japan",
    description: "A private pottery masterclass learning centuries-old wheel throwing to create handcrafted heirloom dinnerware for our home.",
    amount: "$175",
    imageUrl: "https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?auto=format&fit=crop&w=800&q=80",
    tag: "Shared Craft"
  },
  {
    id: "gift-4",
    title: "Tuscan Organic Vineyard Reserve Tasting",
    destination: "Val d'Orcia, Tuscany",
    description: "Walking century-old olive groves, tasting barrel-aged Brunello di Montalcino, and dining at a farmhouse table.",
    amount: "$190",
    imageUrl: "https://images.unsplash.com/photo-1506377247377-2a5b3b417ebb?auto=format&fit=crop&w=800&q=80",
    tag: "Harvest & Wine"
  }
];
