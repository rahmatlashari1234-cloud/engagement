import React from 'react';
import { COUPLE_DATA, HOME_DATE, HOME_EDITORIAL } from './homeData';
import { OptimizedImage } from '../../components/common/OptimizedImage';
import { ArrowDown } from 'lucide-react';
import { BotanicalVine, RosePetal, PhotoFloralFlourish } from '../../components/common/FloralDecorations';
import { CalligraphyFlourish } from '../../components/animations/CalligraphyFlourish';
import { LensPrismEffect } from '../../components/animations/LensPrismEffect';

export const Hero: React.FC = () => {
  const scrollToNext = () => {
    const nextSection = document.getElementById('invitation-suite');
    if (nextSection) {
      nextSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="hero"
      className="relative min-h-screen flex flex-col justify-between pt-28 md:pt-36 pb-12 px-6 md:px-12 bg-[#F8F5F0] overflow-hidden animate-fade-in"
    >
      {/* Botanical Floral Corner Vines & Petals */}
      <BotanicalVine position="top-left" size="lg" opacity={0.65} />
      <BotanicalVine position="top-right" size="lg" opacity={0.6} />
      <BotanicalVine position="bottom-left" size="md" opacity={0.5} />
      <BotanicalVine position="bottom-right" size="md" opacity={0.5} />

      {/* Scattered Petals */}
      <div className="absolute top-40 left-6 sm:left-12 pointer-events-none">
        <RosePetal variant={1} rotate={-15} scale={1} />
      </div>
      <div className="absolute top-52 right-8 sm:right-16 pointer-events-none">
        <RosePetal variant={2} rotate={35} scale={0.9} />
      </div>
      <div className="absolute bottom-36 left-10 pointer-events-none">
        <RosePetal variant={3} rotate={20} scale={0.85} />
      </div>
      <div className="absolute bottom-28 right-12 pointer-events-none">
        <RosePetal variant={1} rotate={-30} scale={0.95} />
      </div>
      {/* Editorial Content Header */}
      <div className="max-w-5xl mx-auto w-full text-center space-y-6 pt-4 md:pt-8 z-10">
        {/* Liquid Gold Spencerian Monogram Crest */}
        <CalligraphyFlourish variant="monogram" className="w-24 h-14 mx-auto mb-1 opacity-90" />

        {/* Eyebrow Label */}
        <div className="inline-flex items-center gap-3">
          <span className="h-[1px] w-6 md:w-10 bg-[#B98F91]" />
          <span className="text-[11px] md:text-xs tracking-[0.28em] uppercase text-[#6F6A63] font-medium">
            {HOME_EDITORIAL.eyebrow}
          </span>
          <span className="h-[1px] w-6 md:w-10 bg-[#B98F91]" />
        </div>

        {/* Large Names Heading */}
        <h1 className="font-serif text-5xl sm:text-6xl md:text-8xl lg:text-9xl text-[#20201E] font-normal tracking-tight leading-[0.95]">
          <span>{COUPLE_DATA.brideFirst}</span>
          <span className="mx-3 md:mx-6 font-serif italic text-[#B98F91] font-light">
            &
          </span>
          <span>{COUPLE_DATA.groomFirst}</span>
        </h1>

        {/* Supporting Editorial Paragraph */}
        <p className="max-w-2xl mx-auto text-[#6F6A63] font-sans text-sm md:text-base leading-relaxed tracking-wide font-light">
          {HOME_EDITORIAL.heroSupporting}
        </p>

        {/* Date and Location Badge */}
        <div className="pt-2 flex flex-wrap items-center justify-center gap-2 md:gap-4 text-xs tracking-[0.16em] uppercase text-[#20201E] font-medium">
          <span>{HOME_DATE.display}</span>
          <span className="text-[#D8C5A5] hidden sm:inline">•</span>
          <span className="text-[#6F6A63]">{HOME_DATE.locationBadge}</span>
        </div>
      </div>

      {/* Main Editorial Photograph Container with 35mm Lens Prism Flare */}
      <div className="max-w-6xl mx-auto w-full my-10 md:my-14 z-10">
        <LensPrismEffect className="relative group overflow-hidden bg-[#EDE6DC] shadow-[0_24px_60px_rgba(32,32,30,0.08)] border border-[#E5DFD5]/80">
          <PhotoFloralFlourish position="top-left" className="opacity-90 z-20" />
          <PhotoFloralFlourish position="bottom-right" className="opacity-90 z-20" />
          <OptimizedImage
            src="https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=2200&q=85"
            alt="Amelia and Daniel editorial engagement portrait"
            priority={true}
            animation="ken-burns"
            cornerAccents={true}
            curtainReveal={true}
            className="w-full h-[55vh] sm:h-[65vh] md:h-[72vh]"
            objectFit="cover"
            objectPosition="50% 30%"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#20201E]/45 via-[#20201E]/10 to-transparent pointer-events-none" />

          {/* Top Right Medium Format Lens Badge */}
          <div className="absolute top-4 right-4 md:top-6 md:right-6 pointer-events-none z-10 flex items-center gap-2 px-3 py-1 bg-[#20201E]/40 backdrop-blur-md rounded-full border border-white/20 text-white/90 text-[10px] tracking-widest uppercase font-sans">
            <span className="w-1.5 h-1.5 rounded-full bg-[#D8C5A5] animate-ping" />
            <span>Medium Format 6×7</span>
          </div>

          {/* Floating Editorial Caption */}
          <div className="absolute bottom-4 left-6 md:bottom-8 md:left-10 text-white/95 pointer-events-none transform transition-transform duration-500 group-hover:translate-x-1">
            <span className="text-[10px] md:text-xs tracking-[0.24em] uppercase font-sans text-white/80 block mb-1">
              Photograph 01
            </span>
            <p className="font-serif italic text-lg md:text-2xl font-light drop-shadow-sm">
              The golden hour promise — Hudson Valley
            </p>
          </div>

          <div className="absolute bottom-4 right-6 md:bottom-8 md:right-10 text-white/80 text-[11px] tracking-widest uppercase font-sans hidden sm:block">
            {HOME_DATE.engagementDate}
          </div>
        </LensPrismEffect>
      </div>

      {/* Subtle Scroll Indicator */}
      <div className="text-center z-10 flex flex-col items-center">
        <button
          onClick={scrollToNext}
          className="group inline-flex flex-col items-center gap-2 text-[#8C867E] hover:text-[#20201E] transition-colors cursor-pointer"
          aria-label="Scroll to exploration"
        >
          <span className="text-[10px] tracking-[0.26em] uppercase font-sans">
            Explore Celebration
          </span>
          <div className="w-[1px] h-8 bg-[#D8C5A5] relative overflow-hidden group-hover:h-10 transition-all duration-300">
            <div className="w-full h-3 bg-[#20201E] animate-bounce" />
          </div>
          <ArrowDown className="w-3.5 h-3.5 text-[#8C867E] group-hover:text-[#20201E] transition-transform group-hover:translate-y-0.5" />
        </button>
      </div>
    </section>
  );
};
